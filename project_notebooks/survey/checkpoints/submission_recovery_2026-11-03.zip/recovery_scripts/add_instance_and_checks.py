from pathlib import Path
p=Path('assemble_submission.py');s=p.read_text().replace('excluded_cells.MenahelEtMi.iloc[0] == 1.725','np.isclose(excluded_cells.MenahelEtMi.iloc[0], 1.725)')
s=s.replace("assert all(len(parameters) <= 5", "parameter_defaults = {\n    'Logistic regression': {'classifier__C': 1},\n    'Random forest': {'classifier__min_samples_leaf': 1, 'classifier__max_features': 'sqrt'},\n    'Histogram boosting': {'classifier__max_leaf_nodes': 31},\n    'RBF SVC': {'classifier__C': 1},\n    'XGBoost': {'classifier__xgboost__max_depth': 6, 'classifier__xgboost__min_child_weight': 1},\n    'LightGBM': {'classifier__min_child_samples': 20},\n    'CatBoost': {'classifier__depth': 6},\n    'Small MLP': {'classifier__alpha': 0.0001},\n    'Complement NB': {'classifier__alpha': 1},\n    'Soft voting (5)': {'classifier__weights': None}}\nassert all(parameter_defaults[family][name] in values for family, (_, parameters) in model_families.items()\n           for name, values in parameters.items())\nassert all(len(parameters) <= 5")
marker="markdown('''\n## 15. בדיקות שימוש"
instance="""markdown('''
### רשומה חדשה מדגימה שימוש באנסמבל שנבחר ב-CV
כדי להראות את הממשק עבור סקר חדש, בוחרים את מועמד האנסמבל הטוב ביותר בוולידציה ומאמנים את המפרט שלו על הקודים המלאים. מפיקים פעם אחת הצעה לרשומה חדשה שנכתבה לצורך ההדגמה. אין לה קוד אמת, ולכן אין מדד דיוק. אין שימוש בקוד ענף סופי, במזהה או בתווית בזמן החיזוי. שאר בדיקות הקצה בתא הבא בודקות תקינות קלט בלבד.
''')
code('''
best_ensemble_index = main_results.loc[main_results.family.eq('Soft voting (5)'), 'mean_test_macro_f1'].idxmax()
final_ensemble = clone(model_pipeline).set_params(**search_results.params.iloc[best_ensemble_index])
final_ensemble.set_params(memory=None).fit(labeled_inputs, occupation_codes)
new_record = pd.DataFrame([{field: None for field in INPUT_FIELDS}])
new_record.loc[0, ['YeshuvAvoda', 'ShemAvoda', 'SugAvoda', 'EzoAvoda', 'TeurPeula', 'TeurTafkid']] = [
    'חיפה', 'חברת תוכנה חדשה', 'פיתוח תוכנה', 'מפתחת תוכנה', 'כתיבת קוד ובדיקת תוכנה', 'מפתחת']
new_record.loc[0, ['MaamadAvoda', 'MakorSachar', 'TeudaGvoha', 'shnotlimud', 'Gil', 'TarichHathala']] = [
    1, 1, 5, 16, 30, '2024-01-01']
new_probabilities = final_ensemble.predict_proba(prepare_model_inputs(new_record))[0]
new_order = np.argsort(-new_probabilities, kind='stable')[:3]
new_instance_prediction = pd.DataFrame({'rank': [1, 2, 3],
    'suggested_code': final_ensemble.classes_[new_order], 'uncalibrated_probability': new_probabilities[new_order]})
display(new_record)
display(new_instance_prediction)
print('Five-model ensemble configuration:', candidate_results.iloc[best_ensemble_index].to_dict())
''')

"""
s=s.replace(marker,instance+marker)
s=s.replace("'partial_predictions': partial_predictions}", "'partial_predictions': partial_predictions, 'new_instance_prediction': new_instance_prediction}")
s=s.replace("probe_predictions = final_model.predict(prepare_model_inputs(probe_records))", "for preparation in [build_preprocessor(), build_preprocessor('Cluster one-hot')]:\n    preparation.fit(prepare_model_inputs(probe_records.iloc[[0]]))\n    assert np.isfinite(preparation.transform(prepare_model_inputs(probe_records))).all()\nprobe_predictions = final_model.predict(prepare_model_inputs(probe_records))")
p.write_text(s)
p=Path('execute_inprocess.py');s=p.read_text().replace('from IPython.core.interactiveshell import InteractiveShell', 'from IPython.terminal.interactiveshell import TerminalInteractiveShell').replace('shell = InteractiveShell.instance()', 'shell = TerminalInteractiveShell.instance()');p.write_text(s)

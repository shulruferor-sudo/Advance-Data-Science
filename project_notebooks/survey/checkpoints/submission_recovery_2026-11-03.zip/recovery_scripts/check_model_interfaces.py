from pathlib import Path
import joblib,numpy as np
from sklearn.ensemble import VotingClassifier,RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
from threadpoolctl import threadpool_limits
threadpool_limits(1)
paths=list(Path('/tmp').glob('tmp*/joblib/sklearn/pipeline/_fit_transform_one/*/output.pkl'))
features,_=joblib.load(paths[0]);codes=np.array([str(1000+i%49) for i in range(len(features))])
models=[('lr',LogisticRegression(max_iter=1500)),('rf',RandomForestClassifier(n_estimators=10,n_jobs=1)),
 ('xgb',XGBClassifier(n_estimators=2,n_jobs=1)),('lgbm',LGBMClassifier(n_estimators=2,verbosity=-1,n_jobs=1)),
 ('cat',CatBoostClassifier(iterations=2,thread_count=1,verbose=False,allow_writing_files=False))]
ensemble=VotingClassifier(models,voting='soft').fit(features,codes)
assert ensemble.predict_proba(features[:3]).shape==(3,49)
assert set(ensemble.predict(features[:3])).issubset(codes)
print('All five model interfaces, target encoding, soft voting and prediction passed.')

from pathlib import Path
p=Path('assemble_submission.py')
s=p.read_text()
s=s.replace("{'scikit-learn': '1.8.0', 'openpyxl': '3.1.5'}", "{'scikit-learn': '1.8.0', 'openpyxl': '3.1.5',\n                         'xgboost': '3.0.5', 'lightgbm': '4.6.0', 'catboost': '1.2.8'}")
s=s.replace('של שתי התלויות המרכזיות','של התלויות המפורשות')
s=s.replace('from sklearn.ensemble import ExtraTreesClassifier, VotingClassifier', 'from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, VotingClassifier\nfrom xgboost import XGBClassifier\nfrom lightgbm import LGBMClassifier\nfrom catboost import CatBoostClassifier')
s=s.replace("        vectors = self.vectorizer_.transform(content)\n", "        self.scores_, self.model_, self.selected_clusters_ = [], None, 0\n        if content.empty:\n            return self\n        vectors = self.vectorizer_.transform(content)\n")
start=s.index("def build_preprocessor(path=")
end=s.index("    text_transformers = []",start)
s=s[:start]+"def build_preprocessor(path='Direct TF-IDF', normalization=None):\n"+s[end:]
s=s.replace('for field in selected_text:', 'for field in TEXT_FIELDS:').replace('selected_categories)', 'CATEGORY_FIELDS)').replace('selected_numbers)', 'NUMBER_FIELDS)')
s=s.replace("sparse_threshold=1.0", "sparse_threshold=0")
start=s.index('## 11. משווים מודלים')
end=s.index("candidate_parameters, candidate_descriptions = [], []",start)
replacement='''## 11. פרמטרים נבחרים לפי השפעתם הצפויה על המדגם
כדי לזהות איזו הנחת מודל מתאימה לייצוגים, משווים את כל המשפחות באותם עשרה קפלי אימון. ריבוי מקצועות ומעט דוגמאות לכל מקצוע מכוונים את החיפוש לרגולריזציה, גודל עלים ועומק, ולא לרשתות גדולות. כל הערכים נקבעים לפני קריאת תוצאות הבדיקה. אין הגרלה ואין הבטחה מוקדמת שאלו הערכים הטובים בעולם: זו השוואה מוגבלת ומנומקת.

| מודל | פרמטרים וערכים מפורשים | מדוע דווקא אלה |
|---|---|---|
| LogisticRegression | `C=[0.1, 1, 10]` | עשירית, ברירת המחדל ופי עשרה: טווח לוגריתמי לבדיקת רגולריזציה חזקה, בינונית וחלשה במרחב טקסט רחב |
| RandomForestClassifier | `min_samples_leaf=[1, 2, 4]`, `max_features=['sqrt', 0.5]` | עלה יחיד שומר אות נדיר אך עלול לזכור רעש. 2 ו-4 דורשים תמיכה נוספת. sqrt משווה ברירת מחדל דלילה לדגימת מחצית המאפיינים כשאותות רבים נדירים |
| HistGradientBoostingClassifier | `max_leaf_nodes=[3, 7, 15]` | תקציבי עלים קטנים ומדורגים לבדיקת אינטראקציות. `min_samples_leaf=2` קבוע כי ברירת המחדל 20 גדולה ביחס למדגם ולמקצועות הנדירים |
| SVC עם RBF | `C=[0.1, 1, 10]` | אותו טווח לוגריתמי לענישה על שגיאות. `gamma='scale'` מתאים את קנה המידה לשונות המאפיינים בתוך כל קפל |
| XGBClassifier | `max_depth=[1, 2, 3]`, `min_child_weight=[0, 1]` | גדם ועד שלוש רמות מגבילים מורכבות. 0 בודק אם סף Hessian ברירת המחדל 1 חוסם אות ממחלקות דלות. אין פירושו אפס רשומות לעלה |
| LGBMClassifier | `min_child_samples=[2, 5, 10]` | שתי דוגמאות לשימור אות נדיר מול דרישה לחמש או לעשר. ברירת המחדל 20 עלולה למנוע פיצולים שימושיים כאן. שבעה עלים מגבילים מורכבות |
| CatBoostClassifier | `depth=[2, 4, 6]` | 4, 16 ו-64 עלים לכל היותר בעצים הסימטריים: מגבלה חזקה, בינונית ועומק ברירת המחדל. שישה עלולים כבר להיות גדולים מדי למדגם |
| MLPClassifier | `alpha=[0.01, 0.1, 1]` | שלוש עוצמות L2 בטווח לוגריתמי, חזקות מברירת המחדל, להגבלת רשת בת 16 יחידות כאשר מספר המאפיינים גדול ממספר הרשומות |
| ComplementNB | `alpha=[0.1, 1, 10]` | בסיס טקסט מהיר: עשירית, Laplace=1 ורגולריזציה חזקה יותר. זהו smoothing של אומדן המסווג, נפרד מ-IDF שנותר ללא smoothing |
| הצבעה רכה של חמישה | `weights=[(1,1,1,1,1), (2,1,1,1,1), (1,2,1,1,1)]` | שוויון, הדגשת המודל הליניארי, או הדגשת היער. הרכיבים הם LR, RF, XGBoost, LightGBM ו-CatBoost, בסדר זה |

באנסמבל מפרטי הרכיבים נקבעים מראש ומשקלי ההצבעה נבחרים ב-CV. לא משתמשים בזוכים שנבחרו על כל קפלי האימון כאילו היו בחירות בלתי תלויות בתוך אותם קפלים. לכל מודל לכל היותר שני פרמטרי מסווג בחיפוש, ולכל פרמטר עד שלושה ערכים. נרמול None/L2 הוא הגדרת עיבוד נוספת במסלול הישיר. שלושת מסווגי boosting החיצוניים משתמשים בתקציב קבוע של 80 סבבים ובקצב 0.1, כדי להגביל זמן ריצה. אין early stopping על קבוצת הבדיקה.

XGBoost דורש מספרי מחלקות רציפים בכל אימון. `VotingClassifier` עם רכיב יחיד משתמש במקודד התוויות המובנה כדי למפות קודים בתוך הקפל ולהחזיר אותם בחיזוי. זהו מתאם ל-XGBoost יחיד, ולא אנסמבל נוסף. שני הייצוגים קטנים מספיק למערכים צפופים, ולכן כולם מקבלים אותו פורמט, גם HGB שאינו מקבל קלט sparse. ב-XGBoost אפס TF-IDF הוא אפס אמיתי ולא ערך חסר.

לרשת הקטנה משתמשים ב-MLP של scikit-learn עם פלט softmax רב־מחלקתי ו-cross-entropy. מימוש נוסף של אותה רשת ב-TensorFlow או PyTorch אינו מוסיף כאן השערה. גם יערות ו-boosting ב-H2O וב-Spark חוזרים על משפחות שכבר נבדקות ומוסיפים תשתית שאינה דרושה ל-200 רשומות. הם לא הורצו, ואין כאן השוואת מהירות בין מסגרות.

התוצאה תהיה טבלת כל המועמדים וציוני כל קפל. IDF, אוצר מילים, אשכולות, One-hot, השלמת חסרים ומסווג מותאמים רק בתוך חלק האימון של הקפל. `SVC(probability=True)` מוסיף כיול פנימי שאינו מפריד קבוצות תיאור, ולכן אין לפרש את הסתברויותיו כמדד ביטחון מאומת. גם שאר ציוני ההסתברות דורשים כיול חיצוני על מדגם גדול יותר לפני אוטומציה.
\'\'\')
code(\'\'\'
from sklearn.model_selection import ParameterGrid

logistic_model = LogisticRegression(C=1, max_iter=1500, class_weight='balanced', random_state=RANDOM_SEED)
bayes_model = ComplementNB(alpha=1)
forest_model = RandomForestClassifier(n_estimators=120, min_samples_leaf=2, class_weight='balanced',
                                     random_state=RANDOM_SEED, n_jobs=1)
xgboost_model = XGBClassifier(n_estimators=80, max_depth=2, min_child_weight=0, learning_rate=0.1,
    eval_metric='mlogloss', tree_method='hist', random_state=RANDOM_SEED, n_jobs=1)
lightgbm_model = LGBMClassifier(n_estimators=80, num_leaves=7, min_child_samples=5, learning_rate=0.1,
    verbosity=-1, random_state=RANDOM_SEED, n_jobs=1)
catboost_model = CatBoostClassifier(iterations=80, depth=4, learning_rate=0.1, loss_function='MultiClass',
    verbose=False, allow_writing_files=False, random_seed=RANDOM_SEED, thread_count=1)
voting_model = VotingClassifier([('logistic', clone(logistic_model)), ('forest', clone(forest_model)),
    ('xgboost', clone(xgboost_model)), ('lightgbm', clone(lightgbm_model)), ('catboost', clone(catboost_model))],
    voting='soft', n_jobs=1)
model_families = {
    'Logistic regression': (logistic_model, {'classifier__C': [0.1, 1, 10]}),
    'Random forest': (forest_model, {'classifier__min_samples_leaf': [1, 2, 4], 'classifier__max_features': ['sqrt', 0.5]}),
    'Histogram boosting': (HistGradientBoostingClassifier(max_iter=80, min_samples_leaf=2,
        early_stopping=False, random_state=RANDOM_SEED), {'classifier__max_leaf_nodes': [3, 7, 15]}),
    'RBF SVC': (SVC(probability=True, class_weight='balanced', random_state=RANDOM_SEED), {'classifier__C': [0.1, 1, 10]}),
    'XGBoost': (VotingClassifier([('xgboost', xgboost_model)], voting='soft'),
        {'classifier__xgboost__max_depth': [1, 2, 3], 'classifier__xgboost__min_child_weight': [0, 1]}),
    'LightGBM': (lightgbm_model, {'classifier__min_child_samples': [2, 5, 10]}),
    'CatBoost': (catboost_model, {'classifier__depth': [2, 4, 6]}),
    'Small MLP': (MLPClassifier(hidden_layer_sizes=(16,), solver='lbfgs', max_iter=1000,
        tol=1e-3, random_state=RANDOM_SEED), {'classifier__alpha': [0.01, 0.1, 1]}),
    'Complement NB': (bayes_model, {'classifier__alpha': [0.1, 1, 10]}),
    'Soft voting (5)': (voting_model, {'classifier__weights': [(1, 1, 1, 1, 1), (2, 1, 1, 1, 1), (1, 2, 1, 1, 1)]})
}
assert all(len(parameters) <= 5 and all(len(values) <= 3 for values in parameters.values())
           for _, parameters in model_families.values())
'''
s=s[:start]+replacement+s[end:]
s=s.replace("return_train_score=False, error_score='raise')", "return_train_score=False, error_score='raise', verbose=2)")
s=s.replace("Two paths × six model families", "Two paths × ten model families")
s=s.replace("figsize=(14, 4.5), gridspec_kw={'width_ratios': [1.5, 1]}", "figsize=(17, 6), gridspec_kw={'width_ratios': [1.5, 1]}")
s=s.replace("figsize=(13, 4))\naxes[0].barh(best_families", "figsize=(13, 6))\naxes[0].barh(best_families")
s=s.replace("מאמנים כל מועמד על אותו חלק אימון", "מאמנים את המועמד שנבחר ב-CV לכל משפחה ולכל מסלול על אותו חלק אימון")
s=s.replace("for candidate, parameters in zip(candidate_results.candidate, search_results.params):", "test_candidate_indices = sorted(set(best_pairs.index) | {search.best_index_, len(candidate_results) - 1})\nfor candidate_index in test_candidate_indices:\n    candidate = candidate_results.iloc[candidate_index].candidate\n    parameters = search_results.params.iloc[candidate_index]")
s=s.replace("predicted_codes = fitted_candidate.predict(test_features)", "predicted_codes = np.asarray(fitted_candidate.predict(test_features)).ravel()")
s=s.replace("selected_test_predictions.groupby(['seen_in_training', 'matches_source']).size().unstack(fill_value=0)", "selected_test_predictions.groupby(['seen_in_training', 'matches_source']).size().unstack(fill_value=0).reindex(columns=[False, True], fill_value=0)")
s=s.replace("partial_codes = final_model.predict(partial_inputs)", "partial_codes = np.asarray(final_model.predict(partial_inputs)).ravel()")
s=s.replace("assert np.array_equal(restored_model.predict(partial_inputs), partial_codes)", "assert np.array_equal(np.asarray(restored_model.predict(partial_inputs)).ravel(), partial_codes)")
s=s.replace("'sklearn': sklearn.__version__, 'pandas': pd.__version__, 'numpy': np.__version__,", "'sklearn': sklearn.__version__, 'pandas': pd.__version__, 'numpy': np.__version__,\n    'external_models': {package: importlib.metadata.version(package) for package in ['xgboost', 'lightgbm', 'catboost']},")
s=s.replace("- [Common pitfalls]", "- [XGBoost parameters](https://xgboost.readthedocs.io/en/release_3.0.0/parameter.html), [LightGBM API](https://lightgbm.readthedocs.io/en/v4.6.0/pythonapi/lightgbm.LGBMClassifier.html), [CatBoost tuning](https://catboost.ai/docs/en/concepts/parameter-tuning): משמעות פרמטרי מורכבות ותנאי פיצול.\n- [המאמר שסופק על בדיקת אשכולות](https://medium.com/@kavengik/internal-clustering-validation-with-scikit-learn-four-ways-part-1-5d94410be79b): הקשר לבחירת K. המימוש נבדק מול תיעוד scikit-learn.\n- [Common pitfalls]")
p.write_text(s)

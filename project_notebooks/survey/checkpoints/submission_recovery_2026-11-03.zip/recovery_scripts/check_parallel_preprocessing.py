from pathlib import Path
import json, os, tempfile
from runtime_checkpoint import initialize_worker
notebook = json.loads(Path('repo/project_notebooks/survey/survey_complete.ipynb').read_text())
os.chdir(tempfile.mkdtemp())
namespace = {'__name__': '__main__'}
for index in (3,5,7,9,13,15,17,20):
    exec(''.join(notebook['cells'][index]['source']), namespace)
globals()['TextGroups'] = namespace['TextGroups']
exec("""
probe = Pipeline([('features', build_preprocessor('Cluster one-hot')),
                  ('classifier', DummyClassifier(strategy='most_frequent'))],
                 memory=joblib.Memory(tempfile.mkdtemp(), verbose=0))
with joblib.parallel_backend('loky', inner_max_num_threads=1, initializer=initialize_worker, initargs=(TextGroups,)):
    GridSearchCV(probe, {'classifier__strategy':['most_frequent']}, cv=KFold(2), n_jobs=2,
                 error_score='raise').fit(labeled_inputs.iloc[:12], occupation_codes.iloc[:12])
print('PARALLEL PREPROCESSING PASSED')
""", {**namespace, 'initialize_worker': initialize_worker})

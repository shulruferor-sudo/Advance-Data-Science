"""Execution-only recovery for the unchanged sklearn cross-validation fits."""
from pathlib import Path
import json
import os
import warnings
from sklearn.model_selection._validation import _fit_and_score

def initialize_worker(text_group_class=None):
    # This execution service exposes virtual PIDs; loky's optional psutil RSS probe cannot resolve them.
    import joblib.externals.loky.process_executor as executor
    executor._USE_PSUTIL = False
    if text_group_class is not None:
        import __main__
        __main__.TextGroups = text_group_class

def checkpoint_fit_and_score(*args, **kwargs):
    directory = Path(os.environ['SURVEY_CHECKPOINT_DIRECTORY'])
    directory.mkdir(parents=True, exist_ok=True)
    candidate = kwargs['candidate_progress'][0]
    fold = kwargs['split_progress'][0]
    destination = directory / f'{candidate:03d}_{fold:02d}.json'
    if destination.exists():
        return json.loads(destination.read_text())['result']
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter('always')
        result = _fit_and_score(*args, **kwargs)
    payload = {'result': result, 'warnings': [str(item.message) for item in recorded]}
    temporary = destination.with_suffix('.tmp')
    temporary.write_text(json.dumps(payload, default=lambda value: value.item()))
    temporary.replace(destination)
    return result

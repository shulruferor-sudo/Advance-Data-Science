from pathlib import Path
import time,joblib,numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from threadpoolctl import threadpool_limits
p=next(Path('/tmp/tmp4h1lj_q5/joblib/sklearn/pipeline/_fit_transform_one').glob('*/output.pkl'))
a,_=joblib.load(p);y=np.arange(len(a))%49
threadpool_limits(2)
for name,m in [('hist',HistGradientBoostingClassifier(max_iter=80,min_samples_leaf=2,max_leaf_nodes=31,early_stopping=False)),('xgb',XGBClassifier(n_estimators=80,max_depth=6,min_child_weight=0,n_jobs=1)),('cat',CatBoostClassifier(iterations=80,depth=6,loss_function='MultiClass',thread_count=1,verbose=False,allow_writing_files=False))]:
 t=time.perf_counter();m.fit(a,y);print(name,round(time.perf_counter()-t,2),flush=True)

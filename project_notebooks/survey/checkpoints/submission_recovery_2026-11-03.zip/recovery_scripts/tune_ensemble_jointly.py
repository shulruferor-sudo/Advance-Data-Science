from pathlib import Path
import nbformat
p=Path('repo/project_notebooks/survey/survey_complete.ipynb');n=nbformat.read(p,4)
for c in n.cells:
 if c.cell_type=='code':
  s=c.source
  if s.startswith('from sklearn.model_selection import ParameterGrid'):
   s=s.replace("{'classifier__weights': [None, (2, 1, 1, 1, 1), (1, 2, 1, 1, 1)]}", "{'classifier__logistic__C': [0.1, 1, 10], 'classifier__forest__min_samples_leaf': [1, 2, 4]}")
   s=s.replace("{'classifier__weights': None}", "{'classifier__logistic__C': 1, 'classifier__forest__min_samples_leaf': 1}")
  c.source=s
 else:
  s=c.source.replace('1,360','1,720')
  s=s.replace('`weights=[None, (2,1,1,1,1), (1,2,1,1,1)]`','`logistic__C=[0.1,1,10]`, `forest__min_samples_leaf=[1,2,4]`')
  s=s.replace('None היא ברירת המחדל עם משקל שווה. החלופות מדגישות את המודל הליניארי, או הדגשת היער. הרכיבים הם LR, RF, XGBoost, SVC ו-MLP, בסדר זה','מכווננים יחד רגולריזציה של המודל הליניארי ותמיכה בעלה ביער, לפי ציון האנסמבל. משקלי ההצבעה נשארים אחידים. הרכיבים הם LR, RF, XGBoost, SVC ו-MLP')
  s=s.replace('אותו בסיס ואותם משקלים, כדי לבדוק החלטה לפי קולות המחלקה במקום ממוצע הסתברויות','אותן תשע קומבינציות עם קולות מחלקה במקום ממוצע הסתברויות. החיפוש והאימון נפרדים מ-soft')
  s=s.replace('באנסמבל מפרטי הרכיבים נקבעים מראש ומשקלי ההצבעה נבחרים ב-CV.', 'באנסמבל מכווננים שני פרמטרים משותפים בתוך GridSearchCV על האנסמבל השלם. תשע הקומבינציות נבחנות בכל קפל. weights=None נשאר קבוע, כך שלא מוסיפים כוונון של משקלים למדגם קטן.')
  s=s.replace('כל ערך חיובי','כל ערך חיובי')
  if s.startswith('## 11.'):
   s+='\n\nכדי לבחון אם כוונון האנסמבל מועיל לעומת נקודת הייחוס, נשמר גם הציון של C=1 ו-min_samples_leaf=1. אלה ברירות המחדל של שני הפרמטרים שנבחרו לכוונון, ולא טענה שכל יתר הגדרות הרכיבים הן ברירות המחדל של הספריות. הבחירה בשני פרמטרים מגבילה את החיפוש במדגם קטן, ובודקת יחד רגולריזציה ליניארית והגבלת זיכרון של היער. כל יתר ההגדרות הוגדרו מראש. אין העתקה של best_params_ ממסווג יחיד אל האנסמבל.\n'
  c.source=s
nbformat.write(n,p)
print('Separate full joint ensemble grids: 9 settings for each voting mode and representation setting.')

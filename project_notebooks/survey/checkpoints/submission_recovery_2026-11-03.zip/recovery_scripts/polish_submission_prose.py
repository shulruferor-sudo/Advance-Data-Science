from pathlib import Path
import base64, json
from lxml import html
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

root = Path('repo/project_notebooks/survey')
path = root / 'survey_complete.ipynb'
notebook = json.loads(path.read_text())

def clean_prose(text):
    return text.translate(str.maketrans({'—':'-', '–':'-', '־':'-', ';':'.'}))

for index, cell in enumerate(notebook['cells']):
    if cell['cell_type'] == 'markdown' or index in (7,22,38):
        cell['source'] = clean_prose(''.join(cell['source'])).splitlines(keepends=True)
    if index in (7,38):
        for output in cell.get('outputs', []):
            data = output.get('data', {})
            if 'text/plain' in data:
                value = data['text/plain']
                data['text/plain'] = clean_prose(''.join(value) if isinstance(value,list) else value)
            if 'text/html' in data:
                value = data['text/html']
                document = html.fromstring(''.join(value) if isinstance(value,list) else value)
                for node in document.iter():
                    if node.tag not in ('style','script') and node.text:
                        node.text = clean_prose(node.text)
                    if node.tail:
                        node.tail = clean_prose(node.tail)
                data['text/html'] = html.tostring(document,encoding='unicode')

# Re-render only the descriptive figure whose labels changed. Values are saved measured outputs.
output_directory = root / 'survey_results'
representations = pd.read_csv(output_directory / 'representation_overview.csv')
cluster_counts = pd.read_csv(output_directory / 'all_cluster_counts.csv')
plt.rcParams.update({'figure.dpi':110, 'axes.spines.top':False, 'axes.spines.right':False})
namespace = {'plt':plt,'np':np,'representation_overview':representations,
             'cluster_search_results':cluster_counts, 'TEXT_FIELDS':representations.field.tolist(),
             'OUTPUT_DIRECTORY':output_directory}
source = ''.join(notebook['cells'][22]['source'])
plot_source = source[source.index('cluster_scores_matrix ='):].replace('plt.show()', '')
exec(plot_source, namespace)
import io
buffer = io.BytesIO()
namespace['figure'].savefig(buffer, format='png', bbox_inches='tight')
for output in notebook['cells'][22]['outputs']:
    if 'image/png' in output.get('data', {}):
        output['data']['image/png'] = base64.b64encode(buffer.getvalue()).decode()
plt.close('all')

overview = pd.read_csv(output_directory / 'column_overview.csv')
overview['treatment'] = overview.treatment.map(clean_prose)
overview.to_csv(output_directory / 'column_overview.csv',index=False,encoding='utf-8-sig')
path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1))
readme = root / 'README.md'
readme.write_text(clean_prose(readme.read_text()))
print('Updated prose punctuation and re-rendered its affected figure. Scores and predictions are unchanged.')

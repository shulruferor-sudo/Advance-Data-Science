from pathlib import Path
import nbformat
p=Path('repo/project_notebooks/survey/survey_complete.ipynb');n=nbformat.read(p,4)
for c in n.cells:
 if c.cell_type=='code':
  s=c.source.replace('return VotingClassifier([','return VotingClassifier(estimators=[')
  if s.startswith('def prediction_scores('):
   start=s.index('    transformed_inputs =');end=s.index('\ntest_result_records =')
   s=s[:start]+"    return None, 'not_available'\n"+s[end:]
   s=s.replace("test_top_three = search.best_estimator_.classes_[np.argsort(-test_scores, axis=1, kind='stable')[:, :3]]", "test_top_three = (search.best_estimator_.classes_[np.argsort(-test_scores, axis=1, kind='stable')[:, :3]]\n                  if test_scores is not None else [[] for _ in range(len(test_features))])")
   s=s.replace("[code in suggestions for code, suggestions in zip(test_codes, test_top_three)]", "[code in suggestions if len(suggestions) else pd.NA for code, suggestions in zip(test_codes, test_top_three)]")
  if s.startswith('final_model ='):
   s=s.replace('zip(partial_records.itertuples(), partial_scores, partial_codes)', 'zip(partial_records.itertuples(), partial_scores if partial_scores is not None else [None] * len(partial_records), partial_codes)')
   s=s.replace("ordered_classes = np.argsort(-scores, kind='stable')", "ordered_classes = np.argsort(-scores, kind='stable') if scores is not None else np.array([], dtype=int)")
   s=s.replace("'maximum_score': float(scores.max()),", "'maximum_score': float(scores.max()) if scores is not None else None,")
   s=s.replace("assert np.isfinite(partial_scores).all() and np.allclose(partial_scores.sum(axis=1), 1)", "if partial_scores is not None:\n    assert np.isfinite(partial_scores).all() and np.allclose(partial_scores.sum(axis=1), 1)")
  if 'fitted_ensembles, demonstration_records' in s:
   start=s.index('    scores, score_kind =');end=s.index('assert all(soft is not hard',start)
   s=s[:start]+'''    prepared_record = prepare_model_inputs(new_record)
    predicted_code = np.asarray(ensemble.predict(prepared_record)).ravel()[0]
    scores, score_kind = prediction_scores(ensemble, prepared_record)
    ranked_classes = np.argsort(-scores[0], kind='stable')[:3] if scores is not None else np.array([], dtype=int)
    demonstration_records.append({'ensemble': ensemble_name, 'candidate': configuration.candidate,
        'path': configuration.path, 'predicted_code': predicted_code,
        'top_three': ', '.join(ensemble.classes_[ranked_classes]) or None,
        'maximum_probability': float(scores[0].max()) if scores is not None else None,
        'probability_available': scores is not None})
'''+s[end:]
  c.source=s
 else:
  s=c.source.replace('דירוג hard מבוסס על שיעור קולות משוקלל, שאינו הסתברות מכוילת.', 'ל-hard מוצגת תחזית המחלקה בלבד. הספרייה אינה מספקת לו predict_proba, ולכן אין עבורו הסתברויות או דירוג top-3.')
  s=s.replace('כדי לתמוך גם במועמד hard בלי להמציא הסתברויות, דירוג הצעות עבורו מבוסס על קולות הרכיבים. מקור הציון מסומן בטבלאות. תחזית המחלקה עצמה תמיד מגיעה מ-predict של הספרייה.', 'כדי לתמוך גם במועמד hard, טבלאות ההצעות מאפשרות הסתברות חסרה. תחזית המחלקה מגיעה מ-predict של הספרייה. רק מודלים המספקים predict_proba מקבלים הסתברויות ו-top-3. אין מימוש ידני של צירוף הקולות.')
  c.source=s
nbformat.write(n,p)
print('Both voting modes use sklearn fit and predict directly. No custom voting aggregation.')

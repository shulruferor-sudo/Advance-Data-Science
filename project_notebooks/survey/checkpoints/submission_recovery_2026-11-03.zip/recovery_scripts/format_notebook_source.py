from pathlib import Path
import ast,json,pprint
path=Path('repo/project_notebooks/survey/survey_complete.ipynb')
notebook=json.loads(path.read_text())
for cell in notebook['cells']:
 if cell['cell_type']!='code':continue
 source=''.join(cell['source'])
 if source.startswith('FIELD_DECISIONS = '):
  first_line,*remaining_lines=source.splitlines()
  decisions=ast.literal_eval(first_line.split(' = ',1)[1])
  formatted='FIELD_DECISIONS = '+pprint.pformat(decisions,width=110,sort_dicts=False)+'\n'+'\n'.join(remaining_lines)
  assert ast.dump(ast.parse(source))==ast.dump(ast.parse(formatted))
  cell['source']=formatted.splitlines(keepends=True)
# This script is run only after execution finishes, preserving calculated outputs.
notebook['metadata']['language_info']['version']=json.loads((path.parent/'survey_results/run_manifest.json').read_text())['python']
intro=''.join(notebook['cells'][0]['source'])
intro+='\n\n[מצגת PowerPoint](https://github.com/shulruferor-sudo/Advance-Data-Science/blob/main/project_notebooks/survey/survey_presentation.pptx) · [מצגת PDF](https://github.com/shulruferor-sudo/Advance-Data-Science/blob/main/project_notebooks/survey/survey_presentation.pdf)'
notebook['cells'][0]['source']=intro.splitlines(keepends=True)
path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1))
print('Formatted field decisions without changing their AST; preserved all execution outputs.')

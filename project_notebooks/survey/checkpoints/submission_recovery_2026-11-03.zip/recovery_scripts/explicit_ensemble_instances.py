from pathlib import Path
import nbformat
p=Path('repo/project_notebooks/survey/survey_complete.ipynb');n=nbformat.read(p,4)
for c in n.cells:
 if c.cell_type!='code':continue
 s=c.source
 if s.startswith('from sklearn.model_selection import ParameterGrid'):
  start=s.index('voting_model = VotingClassifier(');end=s.index('model_families =',start)
  s=s[:start]+'''def build_ensemble(voting):
    return VotingClassifier([
        ('logistic', LogisticRegression(C=1, max_iter=1500, class_weight='balanced', random_state=RANDOM_SEED)),
        ('forest', RandomForestClassifier(n_estimators=120, min_samples_leaf=2, class_weight='balanced',
                                         random_state=RANDOM_SEED, n_jobs=1)),
        ('xgboost', XGBClassifier(n_estimators=40, max_depth=2, min_child_weight=0, learning_rate=0.1,
            eval_metric='mlogloss', tree_method='hist', random_state=RANDOM_SEED, n_jobs=1)),
        ('svm', SVC(probability=True, class_weight='balanced', random_state=RANDOM_SEED)),
        ('neural', MLPClassifier(hidden_layer_sizes=(16,), solver='lbfgs', alpha=0.01,
                                max_iter=1000, tol=1e-3, random_state=RANDOM_SEED))
    ], voting=voting, n_jobs=1)

voting_model = build_ensemble('soft')
hard_voting_model = build_ensemble('hard')
'''+s[end:]
 if s.startswith('def prediction_scores('):
  s=s.replace("vote_indices = fitted_pipeline.named_steps['classifier'].transform(transformed_inputs).astype(int)","voting_classifier = fitted_pipeline.named_steps['classifier']\n    vote_indices = voting_classifier.transform(transformed_inputs).astype(int)")
  s=s.replace("vote_shares = np.eye(len(fitted_pipeline.classes_))[vote_indices].mean(axis=1)","vote_shares = np.average(np.eye(len(fitted_pipeline.classes_))[vote_indices], axis=1, weights=voting_classifier.weights)")
  s=s.replace("'unweighted_vote_share'","'weighted_vote_share'")
 if 'fitted_ensembles, demonstration_records' in s:
  s=s.replace("ensemble = clone(model_pipeline).set_params(**clone(search_results.params.iloc[ensemble_index], safe=False))\n    ensemble.set_params(memory=None).fit(labeled_inputs, occupation_codes)","configuration = candidate_results.iloc[ensemble_index]\n    normalization = None if configuration.normalization == 'None' else configuration.normalization\n    ensemble = Pipeline([('features', build_preprocessor(configuration.path, normalization)),\n                         ('classifier', build_ensemble('soft' if ensemble_name.startswith('Soft') else 'hard'))])\n    ensemble.set_params(**json.loads(configuration.parameters)).fit(labeled_inputs, occupation_codes)")
 c.source=s
for c in n.cells:
 if c.cell_type=='markdown':
  c.source=c.source.replace('soft ו-hard הם שני מופעי VotingClassifier נפרדים שנוצרים ממפרטים לא מאומנים.', 'soft ו-hard נבנים בשתי קריאות נפרדות ל-build_ensemble. כל קריאה יוצרת חמישה מסווגים חדשים באמצעות הבנאים של הספריות. אף מודל מהניסויים היחידניים אינו מועבר לפונקציה.')
  c.source=c.source.replace('דירוג hard מבוסס על שיעור קולות,','דירוג hard מבוסס על שיעור קולות משוקלל,')
nbformat.write(n,p)
print('Each ensemble now explicitly constructs five fresh independent estimator instances.')

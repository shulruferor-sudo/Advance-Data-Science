from pathlib import Path
import nbformat
p=Path('repo/project_notebooks/survey/survey_complete.ipynb');n=nbformat.read(p,4)
for c in n.cells:
 if c.cell_type=='code':
  s=c.source
  if s.startswith('from sklearn.model_selection import ParameterGrid'):
   s=s.replace("voting='soft', n_jobs=1)\nmodel_families", "voting='soft', n_jobs=1)\nhard_voting_model = clone(voting_model).set_params(voting='hard')\nmodel_families")
   s=s.replace("'classifier__weights': [None, (2, 1, 1, 1, 1), (1, 2, 1, 1, 1)]})\n}","'classifier__weights': [None, (2, 1, 1, 1, 1), (1, 2, 1, 1, 1)]}),\n    'Hard voting (5)': (hard_voting_model, {'classifier__weights': [None, (2, 1, 1, 1, 1), (1, 2, 1, 1, 1)]})\n}")
   s=s.replace("'Soft voting (5)': {'classifier__weights': None}}", "'Soft voting (5)': {'classifier__weights': None},\n    'Hard voting (5)': {'classifier__weights': None}}")
  if s.startswith('test_result_records ='):
   s='''def prediction_scores(fitted_pipeline, inputs):
    if hasattr(fitted_pipeline, 'predict_proba'):
        return fitted_pipeline.predict_proba(inputs), 'uncalibrated_probability'
    transformed_inputs = fitted_pipeline.named_steps['features'].transform(inputs)
    vote_indices = fitted_pipeline.named_steps['classifier'].transform(transformed_inputs).astype(int)
    vote_shares = np.eye(len(fitted_pipeline.classes_))[vote_indices].mean(axis=1)
    return vote_shares, 'unweighted_vote_share'

'''+s
   s=s.replace('test_probabilities = search.best_estimator_.predict_proba(test_features)',"test_scores, test_score_kind = prediction_scores(search.best_estimator_, test_features)")
   s=s.replace('-test_probabilities','-test_scores')
   s=s.replace("selected_test_predictions['top_three'] =", "selected_test_predictions['ranking_score_kind'] = test_score_kind\nselected_test_predictions['top_three'] =")
  if s.startswith('final_model ='):
   s=s.replace('partial_probabilities = final_model.predict_proba(partial_inputs)', 'partial_scores, partial_score_kind = prediction_scores(final_model, partial_inputs)')
   s=s.replace('partial_probabilities','partial_scores').replace('probabilities','scores')
   s=s.replace("'maximum_uncalibrated_probability': float(scores.max()),", "'maximum_score': float(scores.max()), 'score_kind': partial_score_kind,")
  if s.startswith('best_ensemble_index ='):
   start=s.index('new_record = pd.DataFrame')
   end=s.index('new_probabilities =')
   input_code=s[start:end]
   s=input_code+'''
fitted_ensembles, demonstration_records = {}, []
for ensemble_name in ['Soft voting (5)', 'Hard voting (5)']:
    ensemble_index = main_results.loc[main_results.family.eq(ensemble_name), 'mean_test_macro_f1'].idxmax()
    ensemble = clone(model_pipeline).set_params(**clone(search_results.params.iloc[ensemble_index], safe=False))
    ensemble.set_params(memory=None).fit(labeled_inputs, occupation_codes)
    fitted_ensembles[ensemble_name] = ensemble
    voters = ensemble.named_steps['classifier']
    assert all(trained is not specification for trained, (_, specification) in zip(voters.estimators_, voters.estimators))
    scores, score_kind = prediction_scores(ensemble, prepare_model_inputs(new_record))
    ranked_classes = np.argsort(-scores[0], kind='stable')[:3]
    for rank, class_index in enumerate(ranked_classes, 1):
        demonstration_records.append({'ensemble': ensemble_name, 'candidate': candidate_results.iloc[ensemble_index].candidate,
            'path': candidate_results.iloc[ensemble_index].path, 'rank': rank,
            'suggested_code': ensemble.classes_[class_index], 'score': scores[0, class_index], 'score_kind': score_kind})
assert all(soft is not hard for soft, hard in zip(
    fitted_ensembles['Soft voting (5)'].named_steps['classifier'].estimators_,
    fitted_ensembles['Hard voting (5)'].named_steps['classifier'].estimators_))
new_instance_prediction = pd.DataFrame(demonstration_records)
display(new_record)
display(new_instance_prediction)
'''
  s=s.replace('Two paths × ten model families','Two paths × eleven classifier options').replace('All ten models:','All eleven classifiers:')
  c.source=s
 else:
  s=c.source.replace('1,270','1,360').replace('עשר המשפחות','אחת-עשרה האפשרויות').replace('מעשר המשפחות','מאחת-עשרה האפשרויות')
  if s.startswith('## 11.'):
   marker='| הצבעה רכה של חמישה |'
   lines=s.splitlines();i=next(i for i,line in enumerate(lines) if line.startswith(marker))
   lines.insert(i+1,'| הצבעה קשה של חמישה | `weights=[None, (2,1,1,1,1), (1,2,1,1,1)]` | אותו בסיס ואותם משקלים, כדי לבדוק החלטה לפי קולות המחלקה במקום ממוצע הסתברויות |')
   s='\n'.join(lines)
   s+='\n\nכדי לשמור על עצמאות הניסויים, soft ו-hard הם שני מופעי VotingClassifier נפרדים שנוצרים ממפרטים לא מאומנים. בכל fit הספרייה משכפלת ומאמנת את רכיביה, וגם כל קפל מקבל אנסמבל חדש. אין שימוש במודלים שאומנו בהשוואות היחידניות. voting קובע את צירוף התחזיות ולא פונקציית אימון חדשה לרכיבים: soft משקלל הסתברויות, ו-hard משקלל קולות של מחלקות. מפרטי הרכיבים קבועים בשתי הגרסאות, וכל גרסה מאומנת בנפרד.\n'
  if s.startswith('### רשומה חדשה'):
   s='''### רשומה חדשה מדגימה אנסמבל רך ואנסמבל קשה
כדי להשוות שימוש בשתי שיטות ההצבעה, בוחרים לכל אחת את המפרט הטוב ב-CV ומאמנים אנסמבל חדש על כל התוויות המלאות. בדיקת זהות מוודאת שהרכיבים המאומנים שונים ממפרטי הבנייה, ושמופעי soft ו-hard אינם משותפים. שניהם חוזים את אותה רשומה חדשה שנכתבה להדגמה. אין לה קוד אמת ולכן אין מדד דיוק.

דירוג soft מבוסס על הסתברויות בלתי מכוילות. דירוג hard מבוסס על שיעור קולות, שאינו הסתברות מכוילת. הקוד אינו משתמש בקוד ענף סופי, במזהה או בתווית בזמן החיזוי. בדיקות הקצה בהמשך בודקות תקינות קלט בלבד.
'''
  if s.startswith('## 12.'):
   s+='\n\nכדי לתמוך גם במועמד hard בלי להמציא הסתברויות, דירוג הצעות עבורו מבוסס על קולות הרכיבים. מקור הציון מסומן בטבלאות. תחזית המחלקה עצמה תמיד מגיעה מ-predict של הספרייה.\n'
  if s.startswith('## 16.'):
   s+='\n\nכדי לבדוק אם המסקנה משתנה בנתונים גדולים ומגוונים יותר, נבחן בנפרד כמות רשומות, מספר מקצועות ומגוון ניסוחים. יותר דוגמאות לכל מקצוע עשויות לשפר את שני המסלולים. אשכולות עשויים לעזור כאשר ניסוחים שונים חולקים ראיות לשוניות שימושיות, אך עלולים לאבד מילה נדירה שמבדילה בין מקצועות. TF-IDF אינו מבטיח זיהוי מילים נרדפות או תיקון שגיאות כתיב. יותר שורות לבדן אינן סיבה לצפות ליתרון של הקיבוץ, ודירוג המודלים עשוי להשתנות או להישאר דומה. נבדוק זאת במדגמי אימון גדלים מול בדיקה מייצגת קבועה, תוך מדידת איכות, זיכרון וזמן.\n'
  c.source=s
nbformat.write(n,p)
print('Added independently fitted hard voting, score types and instance-isolation assertions.')

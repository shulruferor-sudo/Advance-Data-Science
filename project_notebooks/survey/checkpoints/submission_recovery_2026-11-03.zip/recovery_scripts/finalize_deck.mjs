import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const root='/workspace/scratch/14b0f58f673c';
const {finalizePresentation}=await import(pathToFileURL('/root/.codex/skills/builtins/presentations/container_tools/artifact_tool_utils.mjs'));
const result=await finalizePresentation({
 workspaceDir:root,candidatePath:root+'/deck_rtl.pptx',
 finalPath:root+'/repo/project_notebooks/survey/survey_presentation.pptx',
 pythonExecutable:process.env.CODEX_PRIMARY_RUNTIME_PYTHON,
 integrityValidatorPath:'/root/.codex/skills/builtins/presentations/container_tools/inspect_presentation_package_integrity.py',
 layoutValidatorPath:'/root/.codex/skills/builtins/presentations/container_tools/inspect_presentation_layout_geometry.py',
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit',
   ...[2,4,6,10].flatMap(number=>['--require-native-table-slide',String(number)])],
 explicitTotalSlideCount:10,
 requiredNativeTableOwnerSlides:[2,4,6,10],requiredNativeChartOwnerSlides:[3,5,7,8,9],
 materializeLiteralChartWorkbooks:true,fontPolicy:{basis:'design',families:['Arial']},
 verifyArtifactToolImport:true,receiptPath:root+'/deck_validation.json'
});
console.log(JSON.stringify(result));

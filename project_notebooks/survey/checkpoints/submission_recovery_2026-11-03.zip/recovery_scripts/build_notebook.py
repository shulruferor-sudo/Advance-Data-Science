from pathlib import Path
import ast
import base64
import gzip
import hashlib
import json
import subprocess
import textwrap

ROOT = Path('/workspace/scratch/14b0f58f673c')
REPO = ROOT / 'repo'
OUT = REPO / 'project_notebooks/survey'
OUT.mkdir(exist_ok=True)
revision = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
cells = []

def md(text):
    cells.append(dict(cell_type='markdown', metadata={}, source=textwrap.dedent(text).strip()))

def code(text, hidden=False):
    cells.append(dict(cell_type='code', execution_count=None,
                      metadata={'cellView': 'form'} if hidden else {},
                      source=textwrap.dedent(text).strip(), outputs=[]))

md('''
# סיווג משלחי יד מתוך נתוני סקר
**מטלת קבלה לתפקיד מדען נתונים בכיר · אור שולרופר**

המטרה היא להדגים תהליך קריא ושלם לחיזוי `SemelMishlachSofi`. לפי המטלה, הנתונים סינתטיים ואין משמעות לציון החיזוי לצורך המבחן. לכן מרכז העבודה הוא הבנת הנתונים, טיפול מנומק בכל שדה, מניעת טעויות בתהליך, אימון והצגת תחזיות. המדדים מתארים את הניסוי בלבד.

[הקוד ב-GitHub](https://github.com/shulruferor-sudo/Advance-Data-Science/blob/main/project_notebooks/survey/survey_complete.ipynb) · [פתיחה ב-Colab](https://colab.research.google.com/github/shulruferor-sudo/Advance-Data-Science/blob/main/project_notebooks/survey/survey_complete.ipynb)

**הרצה:** Runtime → Run all, במעבד CPU. המחברת מכילה עותק דחוס של קובץ ה-Excel המקורי, עם אימות SHA-256. אין צורך בגישה ציבורית למאגר, בחיבור ל-Drive או במפתח גישה. ניתן להעלות את המחברת ל-Colab גם כאשר המאגר פרטי. התא הטכני של הנתונים מכווץ כדי לשמור על קריאות. כל התוצאות מחושבות מחדש, ללא טעינת תוצאות מניסויים קודמים.

התוצרים כוללים ביקורת לכל 18 השדות, תרשימים, השוואה מוגבלת של מודלים, כוונון פרמטרים, תחזיות לקבוצת בדיקה ולרשומות עם קוד חלקי, וקבצי CSV לכל הניסויים שבוצעו. המצגת מסכמת את ההגשה בעשרה שקפים.
''')

md('''
## 1. הבעיה העסקית והיקף הפתרון
למ״ס מסווגת את משלח היד של משתתף לפי תיאור העבודה. השאלון יכול להיות חלקי ולהישלח שוב. תהליך הסימול הידני מספק תוויות אימון, אך המטלה מציינת שיעור נכונות משוער של 90% בבדיקות מדגמיות. אין כאן תווית אמת עצמאית לכל רשומה, ולכן שיעור זה אינו תקרת דיוק של המודל ואינו מוכיח שדווקא 20 מתוך 200 התוויות שגויות.

זהו סיווג רב־מחלקתי של קודים נומינליים. `X` מציין סימול לא מלא, ולא משלח יד נוסף. מודל ראשון יציע קוד לסמלן. מעבר לסיווג אוטומטי דורש נתוני אמת, תוויות מאומתות ומדידת שיעור טעויות במחיר ובכיסוי מוסכמים. המטלה אינה מחייבת מודל מסוים או הכרת תקן חיצוני.
''')
code('''
import importlib.metadata as metadata_version
import importlib.util
import subprocess
import sys

# Pin the model API used for the submitted run, before importing scikit-learn.
required = {'scikit-learn': '1.8.0', 'openpyxl': '3.1.5'}
for package, version in required.items():
    try:
        installed = metadata_version.version(package)
    except metadata_version.PackageNotFoundError:
        installed = None
    if installed != version:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', f'{package}=={version}'])

import base64
import gzip
import hashlib
import io
import json
import re
import time
import warnings
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from IPython.display import display, Markdown
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import ExtraTreesClassifier, VotingClassifier
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score, make_scorer
from sklearn.model_selection import GridSearchCV, GroupKFold, GroupShuffleSplit, KFold, cross_val_predict
from sklearn.naive_bayes import ComplementNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MaxAbsScaler, OneHotEncoder
from threadpoolctl import threadpool_limits

SEED = 42
TARGET = 'SemelMishlachSofi'
OUTPUT = Path('survey_results')
OUTPUT.mkdir(exist_ok=True)
threadpool_limits(limits=2)
warnings.filterwarnings('error', category=ConvergenceWarning)
pd.set_option('display.max_colwidth', 100)
plt.rcParams.update({'figure.dpi': 110, 'axes.spines.top': False, 'axes.spines.right': False})
print({'python': sys.version.split()[0], 'pandas': pd.__version__, 'sklearn': sklearn.__version__})
''')

md('''
## 2. המקור והגבולות של טבלת הנתונים
נקראו מסמך המטלה ושני גיליונות המקור. קובץ ה-Excel שהתקבל מ-Drive זהה בבייטים לעותק שבמאגר בזמן הבדיקה. ב-`Metadata` יש ארבע עמודות הגדרה. בתאים `BX18:XFD18` מופיע שוב השם `TarichHathala`, ללא הגדרות נוספות. ב-`Survey Dataset` יש 200 רשומות בעלות מספר רץ, ולאחריהן התא `J202` עם הנוסחה `=1.5*1.15`. הוא אינו רשומת סקר ואינו ממוצע שחושב מהסקרים. אזורי העודף אינם נכנסים לטבלת העבודה. המקור עצמו נשמר ללא שינוי.

קודי הסיווג נקראים כמחרוזות. אין השלמה אוטומטית של `123` ל-`0123`, משום שהקובץ אינו מוכיח שזה התיקון הנכון. התא הבא מכיל את **קובץ המקור בלבד**, ולא תחזיות או מודלים מאומנים.
''')
payload = base64.b64encode(gzip.compress((ROOT/'DUMMY_DATASET.xlsx').read_bytes(), mtime=0)).decode()
code('#@title קובץ המקור המקורי ואימות שלמותו\nWORKBOOK_GZIP_BASE64 = '+repr(payload)+'''
workbook_bytes = gzip.decompress(base64.b64decode(WORKBOOK_GZIP_BASE64))
SOURCE_SHA256 = 'e1e7f391c0675dd14830eaae6b5cd114edc256f18b956bb48a454b0b1209e1ac'
assert hashlib.sha256(workbook_bytes).hexdigest() == SOURCE_SHA256
workbook = pd.ExcelFile(io.BytesIO(workbook_bytes), engine='openpyxl')
assert set(workbook.sheet_names) == {'Survey Dataset', 'Metadata'}
metadata = pd.read_excel(workbook, sheet_name='Metadata', usecols='A:D').dropna(subset=['משתנה'])
metadata['משתנה'] = metadata['משתנה'].str.strip()
metadata['פורמט'] = metadata['פורמט'].str.strip()
definitions = metadata.set_index('משתנה', verify_integrity=True)
raw = pd.read_excel(workbook, sheet_name='Survey Dataset', usecols='A:R',
                    dtype={'SemelAnafSofi': 'string', TARGET: 'string'})
excluded_rows = raw.loc[raw.ID.isna()].dropna(how='all')
survey = raw.loc[raw.ID.notna()].copy().reset_index(drop=True)
survey['ID'] = survey.ID.astype('int64')
assert survey.shape == (200, 18) and metadata.shape == (18, 4)
assert survey.ID.is_unique and set(survey) == set(definitions.index)
print('Records:', len(survey), 'Fields:', len(survey.columns), 'Excluded nonempty footer rows:', len(excluded_rows))
display(metadata)
display(excluded_rows.dropna(axis=1, how='all'))
''', hidden=True)

md('''
## 3. החלטה מפורשת לכל שדה
הטיפוס שב-Metadata מתאר אחסון. המשמעות קובעת את השימוש. קוד מספרי של מעמד תעסוקה אינו גודל כמותי. שם יישוב הוא קטגוריה אפשרית, ותיאור עבודה הוא טקסט. עצם היות השדה `TEXT` אינו מוכיח כיצד המשתתף הזין אותו במערכת.

הטבלה מצמידה לכל הגדרה מקורית החלטת טיפול ונימוק. גיל, יישוב, מעסיק ותאריך התחלה נבדקים במלואם, אך אינם נכללים במודל הראשי. אלה בחירות מצומצמות לצורך ההדגמה, ולא טענה שהשדות לעולם אינם מועילים. זמינות `SemelAnafSofi` לפני הסימול אינה מתועדת, ולכן גם הוא מוחרג. אין תאריך סקר שממנו ניתן לחשב ותק.
''')
treatments = {
'ID':('audit','Sequential row number. Check uniqueness and join predictions. Not a participant identifier.'),
'YeshuvAvoda':('audit','Work locality. Inspect spelling variants. Excluded from the demonstration to avoid geographic shortcuts.'),
'ShemAvoda':('audit','Employer or workplace name, sometimes a generic activity. Inspect repetition. Excluded from predictive features.'),
'SugAvoda':('text','Employer activity. Preserve context separately from participant duties.'),
'ShemMachlaka':('text','Department name. Retain text and missing state in a separate channel.'),
'SugMachlaka':('text','Department activity. Preserve useful text. Mark unresolved references without guessing their antecedent.'),
'EzoAvoda':('text','Work performed by the participant. Primary occupational evidence, including Hebrew and English.'),
'TeurPeula':('text','Tasks performed. Retain despite high missingness. Do not fill from another row.'),
'TeurTafkid':('text','Optional job title. Flag numeric zero as an undocumented placeholder and mask it in the model copy.'),
'MenahelEtMi':('category','Management category. One-hot encode. Missing does not mean non-manager.'),
'MaamadAvoda':('category','Employment status. One-hot encode documented categories and missing state.'),
'MakorSachar':('category','Salary source applies only to status 1 or 5. Separate missing, inapplicable and unknown applicability.'),
'TeudaGvoha':('category','Highest certificate. One-hot encode because codes 8 and 9 prevent a simple numerical ranking.'),
'shnotlimud':('numeric','Years of education. Training-fold median imputation and MaxAbs scaling. Missing indicator retained.'),
'Gil':('audit','Age. Check type and observed range. Excluded to keep the demonstration focused on occupational evidence.'),
'TarichHathala':('audit','Role start date. Parse and inspect. No invented survey date, tenure or submission order.'),
'SemelAnafSofi':('audit','Final industry code. Preserve source strings, flag short and partial codes. Timing of availability is unknown.'),
TARGET:('target','Nominal occupation code. Fit on four-digit complete labels. Keep X cases for separate prediction and review.')}
code('TREATMENTS = '+repr(treatments)+'''
TEXT = [c for c, (role, _) in TREATMENTS.items() if role == 'text']
CATEGORICAL = [c for c, (role, _) in TREATMENTS.items() if role == 'category']
NUMERIC = ['shnotlimud']
assert set(TREATMENTS) == set(survey)
domains = {c: set(map(int, re.findall(r'(?m)^\\s*(\\d+)\\.', str(definitions.loc[c, 'ערכים אפשריים']))))
           for c in survey}
audit_rows, issues = [], []
for column in survey:
    values = survey[column]
    kind = definitions.loc[column, 'פורמט']
    checks = {}
    if kind == 'INTEGER':
        number = pd.to_numeric(values, errors='coerce')
        checks['invalid_integer'] = values.notna() & (number.isna() | number.mod(1).ne(0))
        if domains[column]:
            checks['outside_metadata_domain'] = number.notna() & ~number.isin(domains[column])
    if kind == 'DATE':
        checks['unparseable_date'] = values.notna() & pd.to_datetime(values, errors='coerce').isna()
    if column in ['SemelAnafSofi', TARGET]:
        checks['invalid_code_shape'] = ~values.str.fullmatch(r'[0-9X]{4}', na=False)
    for rule, mask in checks.items():
        issues.extend({'ID': int(survey.loc[i, 'ID']), 'field': column, 'rule': rule,
                       'source_value': str(values.loc[i])} for i in survey.index[mask])
    audit_rows.append({'field': column, 'definition': definitions.loc[column, 'הסבר'],
                      'format': kind, 'missing': int(values.isna().sum()),
                      'distinct': int(values.nunique()), 'role': TREATMENTS[column][0],
                      'treatment': TREATMENTS[column][1]})
column_audit = pd.DataFrame(audit_rows)
display(column_audit)
''')

md('''
## 4. חסרים, תנאים וערכים חשודים
המטלה מתירה שדות חסרים. לכן חסר לבדו אינו שגיאה. ב-`MakorSachar` הניסוח "מלא רק במידה" מגדיר תנאי הכרחי, ולא חובה למלא אצל כל שכיר. תשע רשומות מכילות מקור שכר אף שמעמדן אינו 1 או 5. הערך המקורי נשאר בדוח, ובקלט המודל הוא מקבל מצב "לא חל".

`כנ״ל` הוא הפניה שהיעד שלה אינו מתועד. `חסוי` ו-`לא יכול לפרט` הם מידע על אי־מסירה, ולא עיסוק. `0` בתואר המשרה של רשומה 39 אינו ערך מתועד. מצבי הטקסט הללו נשמרים כמצבים שונים בקלט המעובד. לא ממציאים תוכן, לא מתקנים שגיאות כתיב לפי היעד ולא מעתיקים תשובות בין שורות.
''')
code('''
salary_conflict = survey.MaamadAvoda.notna() & ~survey.MaamadAvoda.isin([1, 5]) & survey.MakorSachar.notna()
issues.extend({'ID': int(row.ID), 'field': 'MakorSachar', 'rule': 'inapplicable_salary_source',
               'source_value': str(row.MakorSachar)} for row in survey[salary_conflict].itertuples())
zero_title = survey.TeurTafkid.astype('string').eq('0').fillna(False)
issues.extend({'ID': int(i), 'field': 'TeurTafkid', 'rule': 'undocumented_zero', 'source_value': '0'}
              for i in survey.loc[zero_title, 'ID'])
issue_table = pd.DataFrame(issues)
complete_mask = survey[TARGET].str.fullmatch(r'[0-9]{4}', na=False)
partial_mask = survey[TARGET].str.fullmatch(r'[0-9X]{4}', na=False) & survey[TARGET].str.contains('X', na=False)
assert (complete_mask | partial_mask).all()
display(issue_table)
display(survey.loc[partial_mask, ['ID', 'EzoAvoda', TARGET]])
display(survey[['Gil', 'shnotlimud', 'TarichHathala']].agg(['min', 'max']))
print('Complete labels:', complete_mask.sum(), 'Partial labels:', partial_mask.sum())

# All observed values remain available, including spelling variants and missing values.
value_counts = pd.concat([survey[c].astype('string').fillna('[MISSING]').value_counts()
                         .rename_axis('value').reset_index(name='count').assign(field=c)
                         for c in survey], ignore_index=True)
display(value_counts)
fig, ax = plt.subplots(figsize=(9, 6))
column_audit.set_index('field')['missing'].sort_values().plot.barh(ax=ax, color='#087f8c')
ax.set(xlabel='Missing records out of 200', title='Missingness in every source field')
fig.tight_layout(); plt.show()
''')
code('''
# Each source field receives a distribution plot appropriate to its meaning.
for start in range(0, len(survey.columns), 3):
    fig, axes = plt.subplots(1, 3, figsize=(15, 3.3))
    for ax, column in zip(axes, survey.columns[start:start + 3]):
        values = survey[column].dropna()
        if column == 'ID':
            ax.plot(survey.ID.to_numpy(), linewidth=1)
            ax.set(xlabel='Row position', ylabel='Sequential ID')
        elif column == 'TarichHathala':
            values.dt.year.value_counts().sort_index().plot.bar(ax=ax)
            ax.set(xlabel='Role start year', ylabel='Records')
        elif column in ['Gil', 'shnotlimud']:
            ax.hist(values, bins=10, color='#087f8c')
            ax.set(xlabel='Years', ylabel='Records')
        elif column in CATEGORICAL or column in [TARGET, 'SemelAnafSofi']:
            values.astype(str).value_counts().head(10).plot.bar(ax=ax, color='#087f8c')
            ax.set(xlabel='Code (top 10 when needed)', ylabel='Records')
        else:
            ax.hist(values.astype(str).str.len(), bins=10, color='#087f8c')
            ax.set(xlabel='Characters in source response', ylabel='Records')
        ax.set_title(column)
    fig.tight_layout(); plt.show()
''')

md('''
## 5. הכנת קלט וכפילויות
הניקוי הבא דטרמיניסטי לכל רשומה ואינו לומד מהמדגם. הוא מנרמל Unicode, רווחים ורישיות לטינית. הוא אינו מתרגם, מאחד מעסיקים או מסיק מקצוע משמות. ששת שדות התיאור נשארים נפרדים כדי לשמור על משמעותם. ארבעת הקודים המוגדרים ב-Metadata עוברים One-hot. שנות הלימוד נשארות כמותיות.

אין מזהה משתתף יציב, מזהה שידור או מזהה סמלן. לכן אי אפשר לזהות בוודאות שידורים של אותו אדם, לבחור "שידור אחרון" או למדוד הבדלים בין סמלנים. לצורך החלוקה משתמשים בחתימה של ששת תיאורי העבודה המעובדים. תיאורים זהים נשארים יחד גם כשהמעסיק או היישוב שונים. זהו קיבוץ תיאורים בלבד. ניסוחים דומים אך שונים עדיין יכולים להופיע בקבוצות שונות.

רשומות חוזרות אינן נמחקות בלי הוכחת זהות. סתירת תוויות מדווחת ומועברת לבדיקה, ללא הצבעת רוב המשנה את המקור.
''')
code('''
TEXT_STATES = {'': '__missing__', 'כנ"ל': '__reference__', 'כנ״ל': '__reference__',
               'חסוי': '__withheld__', 'לא יכול לפרט': '__withheld__', '0': '__invalid__'}

def prepare_inputs(frame):
    result = frame[TEXT + CATEGORICAL + NUMERIC].copy()
    for column in TEXT:
        text = (frame[column].astype('string').fillna('').str.normalize('NFKC')
                .str.lower().str.replace(r'\\s+', ' ', regex=True).str.strip())
        result[column] = text.replace(TEXT_STATES).astype(str)
    for column in CATEGORICAL:
        result[column] = pd.to_numeric(frame[column], errors='raise').astype('Int64').astype('string').fillna('__missing__').astype(str)
    status = frame.MaamadAvoda
    result.loc[status.notna() & ~status.isin([1, 5]), 'MakorSachar'] = '__not_applicable__'
    result.loc[status.isna(), 'MakorSachar'] = '__applicability_unknown__'
    return result

prepared = prepare_inputs(survey)
groups = pd.util.hash_pandas_object(prepared[TEXT], index=False).astype(str)
group_audit = survey.assign(description_group=groups).groupby('description_group').agg(
    records=('ID', 'size'), distinct_labels=(TARGET, 'nunique'))
conflicting = group_audit.index[group_audit.distinct_labels.gt(1)]
print('Repeated complete source rows excluding ID:', survey.drop(columns='ID').duplicated().sum())
print('Distinct description groups:', groups.nunique())
display(survey.loc[groups.isin(conflicting), ['ID', *TEXT, TARGET]])

X = prepared.loc[complete_mask].reset_index(drop=True)
y = survey.loc[complete_mask, TARGET].astype(str).reset_index(drop=True)
group = groups.loc[complete_mask].reset_index(drop=True)
record_ids = survey.loc[complete_mask, 'ID'].reset_index(drop=True)
support = pd.DataFrame({'label': y, 'group': group}).groupby('label').agg(records=('group', 'size'), groups=('group', 'nunique'))
display(support.sort_values(['records', 'label']))
print('Classes:', len(support), 'Singleton classes:', support.records.eq(1).sum(),
      'Classes confined to one description group:', support.groups.eq(1).sum())
assert TARGET not in X and 'SemelAnafSofi' not in X
''')

md('''
## 6. ניסוי קטן והפרדת אימון ובדיקה
נשמרת קבוצת בדיקה באמצעות `GroupShuffleSplit` עם seed קבוע, ללא התאמת החלוקה לציון. בחלק האימון נערכת ולידציה של עשרה קפלים מופרדי קבוצות. `GroupKFold` אינו מבטיח שכל מקצוע יופיע בכל קפל. כאשר מחלקה מופיעה בקבוצה אחת בלבד, אי אפשר גם להפריד את הקבוצה וגם להשאיר דוגמה ממנה באימון.

הטקסט, השלמת החסרים והקידוד נלמדים מחדש בכל קפל באמצעות `Pipeline`. בחירת פרמטרים נעשית רק בתוך חלק האימון. מוצגים כל המועמדים שנבדקו, גם אם לא נבחרו. תוצאות קבוצת הבדיקה הן הדגמה על מדגם סינתטי שכבר נבחן בגרסאות קודמות, ולא מבחן ייצור בלתי־תלוי או סט נתונים חדש שמעולם לא נצפה.

מדד הבחירה הוא macro-F1 הממוצע בקפלי האימון, לצד accuracy. בכל קפל F1 מחושב על איחוד התוויות האמיתיות והחזויות, וערך שאינו מוגדר מקבל אפס. מדווחים בנפרד גם כיסוי מחלקות והתחזיות עצמן. הציון המנצח לאחר חיפוש הוא ציון בחירה, לא אומדן נטול הטיה.
''')
code('''
train, test = next(GroupShuffleSplit(n_splits=1, test_size=0.22, random_state=SEED).split(X, y, group))
X_train, X_test = X.iloc[train], X.iloc[test]
y_train, y_test = y.iloc[train], y.iloc[test]
g_train = group.iloc[train]
cv = list(GroupKFold(n_splits=10, shuffle=True, random_state=SEED).split(X_train, y_train, g_train))
assert set(group.iloc[train]).isdisjoint(group.iloc[test])
fold_audit = []
for fold, (fit, valid) in enumerate(cv, 1):
    assert set(g_train.iloc[fit]).isdisjoint(g_train.iloc[valid])
    fold_audit.append({'fold': fold, 'train_rows': len(fit), 'validation_rows': len(valid),
                       'unseen_label_rows': int((~y_train.iloc[valid].isin(y_train.iloc[fit])).sum())})
assert sorted(np.concatenate([valid for _, valid in cv]).tolist()) == list(range(len(train)))
display(pd.DataFrame(fold_audit))
print('Train / test rows:', len(train), len(test))
print('Test rows with labels absent from training:', int((~y_test.isin(y_train)).sum()))
''')

md('''
## 7. ייצוגים ומודלים
TF-IDF של מקטעי תווים מתאים כנקודת פתיחה לטקסט קצר בעברית ובאנגלית ואינו דורש מילון או מודל שפה. הסברה שמקטעי תווים יעזרו לשגיאות כתיב נבדקת כהשערת מידול, ולא כעובדה שהוכחה כאן. נבחנים גם מקטעי מילים ו-One-hot של תשובות שלמות כבדיקת השוואה מוגבלת. מסלול One-hot עשוי לזהות תשובה מוכרת, אך אינו מייצג דמיון בין תשובות חדשות.

שלוש משפחות המודלים הן Logistic Regression, Complement Naive Bayes ו-Extra Trees. הן מספקות מסווג ליניארי, מודל ספירות הסתברותי ויער עצים. נבחן גם `VotingClassifier` המשלב את שלושתן בהצבעה רכה. כל רכיב מאומן באמצעות API רגיל. אין שינוי ידני של שדות פנימיים ואין מתאמי מודלים מותאמים אישית.

טווחי הפרמטרים קטנים ומוגדרים לפני חישוב התוצאות. ההצבעה נבחנת עם שני משקלים ובפרמטרי בסיס קבועים. אין הנחה שהאנסמבל טוב יותר. ההסתברויות אינן מכוילות, ולכן אינן מדד אמון תפעולי. בחירת K, אשכולות סמנטיים, מרחק לכל דוגמת אימון ומודלי שפה אינם דרושים למטלה זו.
''')
code('''
def features(mode='char', structured=True, fields=None):
    fields = TEXT if fields is None else fields
    if mode == 'onehot':
        parts = [('text', OneHotEncoder(handle_unknown='ignore'), fields)]
    else:
        options = {'analyzer': 'char_wb', 'ngram_range': (2, 4)} if mode == 'char' else {'analyzer': 'word', 'ngram_range': (1, 2)}
        parts = [(column, TfidfVectorizer(**options, min_df=1, max_features=2000,
                   sublinear_tf=True, norm='l2'), column) for column in fields]
    if structured:
        parts += [('categories', OneHotEncoder(handle_unknown='ignore'), CATEGORICAL),
                  ('education_years', Pipeline([('impute', SimpleImputer(strategy='median', add_indicator=True)),
                                                 ('scale', MaxAbsScaler())]), NUMERIC)]
    return ColumnTransformer(parts, remainder='drop', sparse_threshold=1.0)

lr = LogisticRegression(max_iter=1500, C=1, class_weight='balanced', random_state=SEED)
nb = ComplementNB(alpha=1)
trees = ExtraTreesClassifier(n_estimators=100, class_weight='balanced', random_state=SEED, n_jobs=1)
vote = VotingClassifier([('lr', clone(lr)), ('nb', clone(nb)), ('trees', clone(trees))], voting='soft', n_jobs=1)
pipeline = Pipeline([('features', features()), ('model', clone(lr))])

# One search keeps preprocessing, candidate comparison and refitting together.
parameter_grid = [
    {'model': [lr], 'model__C': [0.3, 1, 3]},
    {'model': [nb], 'model__alpha': [0.3, 1, 3]},
    {'model': [trees], 'model__min_samples_leaf': [1, 3]},
    {'model': [vote], 'model__weights': [(1, 1, 1), (2, 1, 1)]},
    {'features': [features('word')], 'model': [clone(lr)]},
    {'features': [features('onehot')], 'model': [clone(lr)]},
    {'features': [features(structured=False)], 'model': [clone(lr)]},
    {'features': [features(fields=['EzoAvoda', 'TeurPeula', 'TeurTafkid'])], 'model': [clone(lr)]},
    {'model': [DummyClassifier(strategy='most_frequent')]},
]
scoring = {'macro_f1': make_scorer(f1_score, average='macro', zero_division=0), 'accuracy': 'accuracy'}
started = time.perf_counter()
search = GridSearchCV(pipeline, parameter_grid, scoring=scoring, refit='macro_f1',
                      cv=cv, n_jobs=1, return_train_score=False, error_score='raise')
search.fit(X_train, y_train)
print('Search seconds:', round(time.perf_counter() - started, 1))
''')

code('''
results = pd.DataFrame(search.cv_results_)
results['candidate'] = [f'C{i:02d}' for i in range(len(results))]
results['family'] = [type(p['model']).__name__ for p in results.params]
results['configuration'] = [str({k: str(v) if k in ['model', 'features'] else v for k, v in p.items()}) for p in results.params]
score_columns = ['candidate', 'family', 'mean_test_macro_f1', 'std_test_macro_f1', 'mean_test_accuracy', 'rank_test_macro_f1']
display(results[score_columns].round(4))
print('Selected candidate:', results.loc[search.best_index_, 'candidate'])
display(pd.DataFrame({'parameter': list(search.best_params_), 'value': [str(v) for v in search.best_params_.values()]}))
fold_scores = results[['candidate', *[c for c in results if re.fullmatch(r'split\\d+_test_.*', c)]]
display(fold_scores)
fig, ax = plt.subplots(figsize=(10, 5))
ax.barh(results.candidate + ' ' + results.family, results.mean_test_macro_f1, color='#087f8c')
ax.set(xlabel='Mean validation macro-F1', title='Every candidate on the same 10 training folds', xlim=(0, 1))
fig.tight_layout(); plt.show()
''')

md('''
## 8. כל תחזיות הבדיקה והניתוח שלהן
מזהה המועמד שנבחר נקבע לפני חיזוי הבדיקה. לצורך שקיפות, גם כל יתר המועמדים מאומנים על אותו חלק אימון ומפיקים תחזיות לאותן רשומות בדיקה. הטבלה מציגה אותם בלי לשנות את הבחירה לפי התוצאות.

הדוח מפריד בין התאמה לתווית המקור ובין נכונות מקצועית מאומתת. מחלקה שלא הופיעה באימון אינה ניתנת לחיזוי על ידי המסווגים הסגורים האלה. שגיאה כזאת נרשמת, ולא מוסתרת באמצעות הסרת הרשומה מהמדד הכולל. Top-3 מוצג כדי להדגים סיוע לסמלן, ולא כסיווג מלא נכון.
''')
code('''
holdout_rows, all_predictions = [], []
selected_id = results.loc[search.best_index_, 'candidate']
for candidate, params in zip(results.candidate, results.params):
    fitted = clone(pipeline).set_params(**params).fit(X_train, y_train)
    predicted = fitted.predict(X_test)
    holdout_rows.append({'candidate': candidate, 'selected_in_training': candidate == selected_id,
                         'accuracy': accuracy_score(y_test, predicted),
                         'macro_f1': f1_score(y_test, predicted, average='macro', zero_division=0)})
    all_predictions.extend({'candidate': candidate, 'ID': int(record_ids.iloc[pos]),
                            'observed': truth, 'predicted': prediction,
                            'label_seen_in_training': truth in set(y_train)}
                           for pos, truth, prediction in zip(test, y_test, predicted))
holdout_scores = pd.DataFrame(holdout_rows)
holdout_predictions = pd.DataFrame(all_predictions)
display(holdout_scores.round(4))
selected_predictions = holdout_predictions.query('candidate == @selected_id').copy()
probabilities = search.best_estimator_.predict_proba(X_test)
classes = search.best_estimator_.classes_
top3 = classes[np.argsort(-probabilities, axis=1, kind='stable')[:, :3]]
selected_predictions['top3'] = [', '.join(row) for row in top3]
selected_predictions['top3_contains_label'] = [truth in row for truth, row in zip(y_test, top3)]
selected_predictions['maximum_uncalibrated_probability'] = probabilities.max(axis=1)
selected_predictions['matches_source'] = selected_predictions.observed.eq(selected_predictions.predicted)
with pd.option_context('display.max_rows', None):
    display(selected_predictions)
prediction = selected_predictions.predicted.to_numpy()
per_class = pd.DataFrame(classification_report(y_test, prediction, output_dict=True, zero_division=0)).T
display(per_class)
print('Top-3 agreement:', selected_predictions.top3_contains_label.mean())
print('Labels unseen in training:', selected_predictions.loc[~selected_predictions.label_seen_in_training, 'observed'].tolist())
confusions = (selected_predictions.loc[~selected_predictions.matches_source]
              .groupby(['observed', 'predicted']).size().rename('records').reset_index())
display(confusions)
fig, ax = plt.subplots(figsize=(9, 4))
holdout_scores.set_index('candidate')[['accuracy', 'macro_f1']].plot.bar(ax=ax, color=['#087f8c', '#a35d27'])
ax.set(title='All candidates on the demonstration holdout', ylabel='Score', ylim=(0, 1))
fig.tight_layout(); plt.show()
''')

md('''
## 9. בדיקת רגישות לחלוקה
ההשוואה הבאה מחזיקה מודל Logistic Regression בפרמטרי בסיס קבועים ומחליפה רק את אופן החלוקה על 191 הרשומות המלאות. חלוקה אקראית לפי שורה יכולה לשים תיאורים זהים באימון ובבדיקה. חלוקה לפי חתימת התיאור מונעת זאת. מדווחים גם כמה רשומות בדיקה חולקות חתימה עם האימון בכל שיטה. ההפרש אינו אומדן נקי של נזק הזליגה, משום שגם קושי המשימה וכיסוי המחלקות משתנים.

זהו ניסוי אבחוני מוגדר מראש. הוא אינו משתתף בבחירת המודל להגשה ואינו משמש לתיקון תוויות.
''')
code('''
sensitivity, sensitivity_predictions = [], []
for name, splitter in [('random_rows', KFold(n_splits=10, shuffle=True, random_state=SEED)),
                       ('description_groups', GroupKFold(n_splits=10, shuffle=True, random_state=SEED))]:
    splits = list(splitter.split(X, y, group))
    predictions = cross_val_predict(clone(pipeline).set_params(model=clone(lr)), X, y, cv=splits, n_jobs=1)
    overlap = sum(group.iloc[valid].isin(set(group.iloc[fit])).sum() for fit, valid in splits)
    unseen = sum((~y.iloc[valid].isin(set(y.iloc[fit]))).sum() for fit, valid in splits)
    sensitivity.append({'split': name, 'accuracy': accuracy_score(y, predictions),
                        'pooled_macro_f1': f1_score(y, predictions, average='macro', zero_division=0),
                        'rows_with_training_description_overlap': int(overlap), 'unseen_label_rows': int(unseen)})
    sensitivity_predictions.extend({'split': name, 'ID': int(i), 'observed': t, 'predicted': p}
                                   for i, t, p in zip(record_ids, y, predictions))
sensitivity = pd.DataFrame(sensitivity)
display(sensitivity)
''')

md('''
## 10. אימון סופי והצעות לסימול חלקי
לאחר הבחירה והדיווח, מאמנים את אותו מפרט שנבחר על כל 191 הרשומות בעלות הקוד המלא. התחזיות לתשע הרשומות החלקיות הן הצעות בלבד. הספרות שכבר ידועות בקוד המקור אינן נכנסות למאפייני המודל. מוצגת בנפרד הצעה התואמת את הספרות הידועות, ככל שקיים קוד כזה בין מחלקות האימון. התאמה לספרות אינה אימות מקצועי של הקוד, והסינון אינו מכייל הסתברויות.

כאשר אין תיאור ענייני, המודל עדיין עשוי להחזיר קוד על סמך המאפיינים שנותרו. תוצאה כזאת מקבלת דגל מפורש. בשלב ההדגמה כל תשע הרשומות נשארות לבדיקה אנושית, ולא נבחר סף אוטומציה על סמך הדוגמה הסינתטית.
''')
code('''
final_model = clone(search.best_estimator_).fit(X, y)
partial = survey.loc[partial_mask].copy()
partial_X = prepared.loc[partial_mask]
partial_probability = final_model.predict_proba(partial_X)
final_classes = final_model.classes_
partial_rows = []
for row, values, (_, inputs) in zip(partial.itertuples(), partial_probability, partial_X.iterrows()):
    original = getattr(row, TARGET)
    ranked = np.argsort(-values, kind='stable')
    compatible = np.array([all(a == 'X' or a == b for a, b in zip(original, label)) for label in final_classes])
    compatible_ranked = ranked[compatible[ranked]]
    suggestion = final_classes[compatible_ranked[0]] if len(compatible_ranked) else None
    partial_rows.append({'ID': int(row.ID), 'original_partial_code': original,
                         'prediction': final_classes[ranked[0]],
                         'top3': ', '.join(final_classes[ranked[:3]]),
                         'maximum_uncalibrated_probability': float(values.max()),
                         'digit_compatible_suggestion': suggestion,
                         'compatible_training_classes': int(compatible.sum()),
                         'no_substantive_description': bool(inputs[TEXT].str.startswith('__').all()),
                         'action': 'human_review'})
partial_predictions = pd.DataFrame(partial_rows)
display(partial_predictions)
assert np.isfinite(partial_probability).all() and np.allclose(partial_probability.sum(axis=1), 1)
assert set(final_classes) == set(y)
assert partial_predictions.ID.tolist() == partial.ID.tolist()
''')

md('''
## 11. בדיקות שימוש ושמירת תוצאות
הבדיקות בוחנות שימוש ממשי: חיזוי עם קלט חסר, קטגוריה שלא הופיעה באימון, ושחזור אותו מודל לאחר שמירה. `prepare_inputs` היא אותה פונקציה באימון ובחיזוי. אין תלות בקובצי Python חיצוניים או במשתני סביבה מגרסאות קודמות. אין לטעון קובץ `joblib` ממקור שאינו מהימן.
''')
code('''
probe = survey.head(2).copy()
probe.loc[probe.index[0], TEXT + CATEGORICAL + NUMERIC] = np.nan
probe.loc[probe.index[1], 'MenahelEtMi'] = 99  # robustness test only, not a valid metadata code
probe_prediction = final_model.predict(prepare_inputs(probe))
assert len(probe_prediction) == 2
joblib.dump(final_model, OUTPUT / 'occupation_model.joblib')
reloaded = joblib.load(OUTPUT / 'occupation_model.joblib')
assert np.array_equal(reloaded.predict(partial_X), final_model.predict(partial_X))
assert hashlib.sha256(workbook_bytes).hexdigest() == SOURCE_SHA256

tables = {'column_audit': column_audit, 'metadata': metadata, 'source_issues': issue_table,
          'all_observed_values': value_counts, 'class_support': support.reset_index(),
          'fold_audit': pd.DataFrame(fold_audit), 'candidate_scores': results[score_columns + ['configuration']],
          'all_candidate_fold_scores': fold_scores, 'all_holdout_predictions': holdout_predictions,
          'holdout_scores': holdout_scores, 'selected_holdout_predictions': selected_predictions,
          'per_class_holdout': per_class.reset_index(), 'confusions': confusions,
          'split_sensitivity': sensitivity, 'split_sensitivity_predictions': pd.DataFrame(sensitivity_predictions),
          'partial_predictions': partial_predictions}
for name, table in tables.items():
    table.to_csv(OUTPUT / f'{name}.csv', index=False, encoding='utf-8-sig')
manifest = {'source_sha256': SOURCE_SHA256, 'seed': SEED, 'python': sys.version.split()[0],
            'sklearn': sklearn.__version__, 'pandas': pd.__version__, 'numpy': np.__version__,
            'records': len(survey), 'complete': len(y), 'partial': len(partial),
            'train': len(train), 'test': len(test), 'folds': len(cv), 'candidates': len(results),
            'selected_candidate': selected_id, 'selected_parameters': str(search.best_params_),
            'test_is_independent_production_evidence': False,
            'description_groups_are_participant_ids': False,
            'probabilities_are_calibrated': False}
(OUTPUT / 'run_manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
print('Saved', len(tables), 'tables, model and run manifest to', OUTPUT.resolve())
display(Markdown(f'**תוצאת ההרצה:** נבחר `{selected_id}` לפי ולידציית האימון. '
                 f'נוצרו {len(selected_predictions)} תחזיות בדיקה ו-{len(partial_predictions)} הצעות לקודים חלקיים. '
                 'כל התוצאות נשמרו ומקור הנתונים נשאר ללא שינוי.'))
''')

md('''
## 12. תובנות והמשך הטמעה
המדגם מדגים היטב את חשיבות הטיפול בנתונים. 191 רשומות בעלות סימול מלא מתחלקות ל-59 מחלקות, מתוכן 24 עם דוגמה יחידה. תיאור תפקיד חסר ב-172 רשומות. תיאורים חוזרים אינם מוכיחים שמדובר באותו משתתף, וקוד ידני אינו תמיד אמת מקצועית. לכן שינוי באיכות החלוקה ובכיסוי המחלקות יכול לשנות את הציון בלי שינוי ביכולת התפעולית.

השלב הבא הוא תיעוד מזהה משתתף, גרסת שאלון, זמן שידור וזמן סימול. לאחר מכן נדרשים מדגם אמת שנבדק בידי סמלנים, הכרעה במחלוקות וכיסוי של מקצועות נדירים. פיילוט יכול להציג לסמלן מספר הצעות עם תיאורי המקור, לתעד קבלה או תיקון ולמדוד זמן עבודה ושיעור תיקונים. רק לאחר הערכה עצמאית וכיול ניתן לקבוע סף לאוטומציה, ולנטר כיסוי, שגיאות לפי מקצוע, חסרים ושינויים בהתפלגות. אין להסיק מנתוני הדמה שסף כלשהו מוכן לפריסה.
''')

md('''
## 13. סקירת הקבצים הקודמים והחלטות האיחוד
נאספו כל קובצי `.ipynb` ו-`.py` מתחת ל-`project_notebooks` בגרסת המאגר המתועדת להלן. הקבצים המקוריים נשארים בהיסטוריה ובמיקומם. המחברת הזו היא נקודת הכניסה להגשה. הסקירה אינה קביעה שכל שורה בקבצים הקודמים שגויה.

נשמרו עקרונות מועילים: קריאת Metadata, הפרדת הקוד הסופי מהמאפיינים, טיפול מותנה במקור שכר, ולידציה לפי קבוצות והפקת תחזיות. תוקנו תיאור הנוסחה כ"סיכום", קיבוץ שכלל את שם המעסיק, תלות בנתיבי `/mnt/data` ובקבצים חסרים, שימוש בטבלאות תוצאה מוטמעות במקום חישוב נוכחי, והצגת סט בדיקה שנצפה קודם כראיה חיצונית חדשה.

אשכולות CH, מרחקי עוגנים, מימושי סיווג מותאמים ושרשרות ניסויים רחבות לא הועברו למסלול ההרצה. הם מוסיפים מורכבות שאינה נחוצה להדגמת המטלה. התוצאות ההיסטוריות נשארות בקובצי המקור, אינן מוצגות כאן כתוצאות מאומתות של התהליך החדש, ואינן משפיעות על בחירתו.

המאגר `OrShulrufer/Ensembles` נבדק כהקשר לניסיון קודם בלבד. זהו מימוש לסיווג בינארי הכולל דגימת איזון, כוונון והצבעה. הקוד לא הועתק. כאן אין צורך בסף בינארי, בהסרת דוגמאות באמצעות TomekLinks או בהזרקה ידנית של מודלים לשדות פנימיים של VotingClassifier.
''')
notes = {
'survey_occupation_classification.ipynb': 'Retained metadata and basic pipeline ideas. Replaced single-model demonstration with bounded comparison.',
'survey_occupation_classification_v2.ipynb': 'Retained metadata-driven domain checks and salary applicability. Kept row-level issue evidence.',
'survey_occupation_classification_v3.ipynb': 'Reviewed custom CH clustering, K selection and alternate encodings. Retired clustering from submission.',
'survey_occupation_classification_v4.ipynb': 'Reviewed six text representations and common holdout. Retained direct TF-IDF and one-hot comparison.',
'survey_occupation_classification_v6.ipynb': 'Reviewed multiple classifiers, 10 folds and voting. Consolidated using GridSearchCV and native estimators.',
'survey.ipynb': 'Reviewed extended clustering and geometry checks. Removed custom clustering machinery from main path.',
'survey_v10.ipynb': 'Contains earlier V4-style pipeline plus voting constructors. Replaced appended fragments with one executed workflow.',
'survey_v10.py': 'Requires V10_COLUMN, /mnt/data notebooks and earlier CSV artifacts. Not standalone. Two identical copies collected.',
'occupation_classification_full_comparison_final_v11.ipynb': 'Contains large embedded evidence payloads and literal final-result tables. New results are computed from source data.',
'Proof.ipynb': 'Unrelated arXiv/BERT semantic-structure project. Inventoried, inspected for scope and left outside survey modeling.'}
inventory=[]
for p in sorted((REPO/'project_notebooks').rglob('*')):
    if p.suffix not in {'.py','.ipynb'} or p.name=='survey_complete.ipynb': continue
    b=p.read_bytes()
    source=b.decode()
    if p.suffix=='.ipynb':
        source='\n\n'.join(''.join(c['source']) for c in json.loads(source)['cells'] if c['cell_type']=='code')
    inventory.append({'path':str(p.relative_to(REPO)), 'sha256':hashlib.sha256(b).hexdigest(),
                      'code_lines':len(source.splitlines()), 'assessment':notes[p.name]})
code('SOURCE_REPOSITORY_REVISION = '+repr(revision)+'\nSOURCE_INVENTORY = '+repr(inventory)+'''
inventory = pd.DataFrame(SOURCE_INVENTORY)
display(inventory[['path', 'code_lines', 'assessment']])
print('Reviewed repository revision:', SOURCE_REPOSITORY_REVISION)
inventory.to_csv(OUTPUT / 'source_inventory.csv', index=False)
''')
md('''
## 14. מקורות ותוקף ההחלטות
המסמך **מדען נתונים 2.11 ג- מטלה.docx** וגיליון `Metadata` הם המקורות למשמעות השדות ולדרישות. תיעוד תוכנה אינו מקור להגדרות המקצועיות של הסקר. מקורות חיצוניים תומכים במנגנוני ההערכה והמימוש, אך אינם מוכיחים איזה מודל מתאים ביותר למדגם הזה.

| החלטה | מקור ותפקידו |
|---|---|
| התאמת עיבוד הנתונים באימון בלבד | [scikit-learn Common pitfalls](https://scikit-learn.org/1.8/common_pitfalls.html), הוראות למניעת זליגה |
| קבוצות שאינן חוצות קפלים | [GroupKFold](https://scikit-learn.org/1.8/modules/generated/sklearn.model_selection.GroupKFold.html), התנהגות ה-API. החתימה המסוימת היא בחירת ניתוח מוגבלת |
| ייצוגי טקסט ומודלים פשוטים | [Text classification with sparse features](https://scikit-learn.org/stable/auto_examples/text/plot_document_classification_20newsgroups.html), דוגמת תוכנה על נתונים אחרים |
| TF-IDF תווי ומילולי | [TfidfVectorizer](https://scikit-learn.org/1.8/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html), הגדרת הייצוג והפרמטרים |
| קטגוריות חדשות וחסרים | [OneHotEncoder](https://scikit-learn.org/1.8/modules/generated/sklearn.preprocessing.OneHotEncoder.html) ו-[SimpleImputer](https://scikit-learn.org/1.8/modules/generated/sklearn.impute.SimpleImputer.html) |
| חיפוש קטן ושקוף | [GridSearchCV](https://scikit-learn.org/1.8/modules/generated/sklearn.model_selection.GridSearchCV.html), פירוט כל מועמד וכל קפל |
| הצבעה רכה | [VotingClassifier](https://scikit-learn.org/1.8/modules/generated/sklearn.ensemble.VotingClassifier.html), ממוצע הסתברויות. [Probability calibration](https://scikit-learn.org/stable/modules/calibration.html) מסביר מדוע ציון אינו אמון מוכח |
| ציון שנבחר לאחר חיפוש מוטה כלפי מעלה | [Cawley and Talbot, JMLR 2010](https://jmlr.org/papers/v11/cawley10a.html), מקור מחקרי ראשוני התומך בהפרדת בחירה מהערכה |
| תיעוד זליגה ותוקף ההערכה | [Kapoor and Narayanan 2022](https://arxiv.org/abs/2207.07048), מקור מחקרי עצמאי על כשלי הערכה. אינו בדיקה של נתוני המטלה |

נבדקו תיעוד scikit-learn ומקורות מחקריים ראשוניים נפרדים. דוגמת nested CV בתיעוד scikit-learn מפנה למאמר Cawley–Talbot, ולכן אינה אישור מחקרי עצמאי נוסף של אותו ממצא. במחברת זו נשמרת הפרדה פשוטה בין אימון ובדיקה, המתאימה להדגמת המבחן. לא נטען שהדוגמה הסינתטית מספקת אומדן דיוק ייצור או ודאות מספרית לגבי נכונות מקצועית.
''')

for i, cell in enumerate(cells):
    cell['id'] = f'survey-{i:02d}'
    if cell['cell_type']=='code': ast.parse(cell['source'])
notebook = dict(cells=cells, metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
                'language_info':{'name':'python','version':'3.12'}, 'colab':{'provenance':[]}}, nbformat=4, nbformat_minor=5)
(OUT/'survey_complete.ipynb').write_text(json.dumps(notebook,ensure_ascii=False,indent=1),encoding='utf-8')
(OUT/'source_inventory.json').write_text(json.dumps({'revision':revision,'files':inventory},ensure_ascii=False,indent=2))
print('Built', len(cells), 'cells', sum(len(c['source'].splitlines()) for c in cells if c['cell_type']=='code'), 'code lines')

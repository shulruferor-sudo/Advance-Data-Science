from pathlib import Path
import re,zipfile,sys
from lxml import etree
source=Path(sys.argv[1]);destination=Path(sys.argv[2])
ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
with zipfile.ZipFile(source) as original,zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as output:
 for item in original.infolist():
  data=original.read(item.filename)
  if item.filename.endswith('.xml') and (item.filename.startswith('ppt/slides/') or item.filename.startswith('ppt/charts/') or item.filename.startswith('ppt/notesSlides/')):
   root=etree.fromstring(data)
   for paragraph in root.findall('.//a:p',ns):
    content=''.join(paragraph.itertext())
    if re.search(r'[\u0590-\u05ff]',content):
     properties=paragraph.find('a:pPr',ns)
     if properties is None:
      properties=etree.Element('{'+ns['a']+'}pPr');paragraph.insert(0,properties)
     properties.set('rtl','1');properties.set('algn','r')
   data=etree.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
  output.writestr(item,data)
print(destination)

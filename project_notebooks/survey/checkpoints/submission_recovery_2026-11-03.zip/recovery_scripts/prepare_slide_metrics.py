from pathlib import Path
import json,pandas as pd,numpy as np
root=Path('repo/project_notebooks/survey/survey_results')
def records(name):return pd.read_csv(root/f'{name}.csv').replace({np.nan:None}).to_dict('records')
manifest=json.loads((root/'run_manifest.json').read_text())
result={'manifest':manifest,'quality':records('data_quality_counts'),'classes':records('class_support'),
 'folds':records('fold_overview'),'representations':records('representation_overview'),
 'candidates':records('all_candidate_results'),'test_paths':records('two_path_comparison'),
 'split':records('split_comparison'),'partial':records('partial_predictions'),'new':records('new_instance_prediction')}
Path('slide_metrics.json').write_text(json.dumps(result,ensure_ascii=False))
print(manifest)

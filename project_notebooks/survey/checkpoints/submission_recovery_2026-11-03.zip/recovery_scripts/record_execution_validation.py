from pathlib import Path
import json
root = Path('repo/project_notebooks/survey')
manifest_path = root / 'survey_results/run_manifest.json'
manifest = json.loads(manifest_path.read_text())
manifest['local_execution_validation'] = {
    'runtime': 'Fresh IPython process',
    'gridsearch_fit_count': 1270,
    'parallel_workers_in_validation_harness': 4,
    'notebook_default_parallel_workers': 1,
    'completed_fit_results_reused_in_final_integration_run': 1270,
    'checkpointing_changes_estimator_parameters_or_splits': False,
    'native_jupyter_kernel_executed': False,
    'native_google_colab_session_executed': False,
    'search_wall_time_is_clean_serial_benchmark': False,
}
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
path = root / 'survey_complete.ipynb'
notebook = json.loads(path.read_text())
for cell in notebook['cells']:
    if cell['cell_type']=='markdown' and ''.join(cell['source']).startswith('### תרשימים משותפים'):
        text = ''.join(cell['source'])
        text += '\n\nבדיקת ההרצה המקומית בוצעה בתהליך IPython חדש. לאחר ניתוק, החיפוש המשיך עם תוצאות התאמות שנשמרו, עד להשלמת כל 1,270 התאמות הוולידציה. כלי הבדיקה הפעיל ארבעה תהליכים עם אותם נתונים, קפלים, פרמטרים וזרעים. ברירת המחדל במחברת היא תהליך אחד כדי לפשט הרצה ב-Colab. זמן החיפוש המצורף כולל המשך מהרצה קודמת, ולכן אינו מדידת זמן של חיפוש סדרתי חדש. לא נבדק סשן Colab בפועל.\n'
        cell['source'] = text.splitlines(keepends=True)
notebook['metadata']['execution_validation'] = manifest['local_execution_validation']
path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1))
print('Recorded the actual execution environment and recovery limits.')

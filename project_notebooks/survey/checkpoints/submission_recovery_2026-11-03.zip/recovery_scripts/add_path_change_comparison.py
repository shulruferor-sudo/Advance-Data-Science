from pathlib import Path
import json
import nbformat
import pandas as pd
import numpy as np
from IPython.terminal.interactiveshell import TerminalInteractiveShell
from IPython.utils.capture import capture_output
root=Path('repo/project_notebooks/survey')
notebook=nbformat.read(root/'survey_complete.ipynb',4)
comparison_code="""
# Compare every model family across the two paths using the same validation folds.
path_changes = comparison_matrix.T.copy()
path_changes['cluster_minus_direct'] = path_changes['Cluster one-hot'] - path_changes['Direct TF-IDF']
path_changes = path_changes.sort_values('cluster_minus_direct')
display(path_changes.round(4))
figure, axis = plt.subplots(figsize=(11, 5.5))
path_changes.cluster_minus_direct.plot.barh(ax=axis,
    color=np.where(path_changes.cluster_minus_direct.gt(0), '#bea15a', '#147d92'))
axis.axvline(0, color='#536774', linewidth=1)
axis.bar_label(axis.containers[0], fmt='%+.3f', padding=3, fontsize=10)
axis.set(xlabel='Cluster one-hot minus direct TF-IDF', ylabel='',
    title='All ten models: change in best tested mean CV macro-F1',
    xlim=(path_changes.cluster_minus_direct.min()-0.025, path_changes.cluster_minus_direct.max()+0.025))
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'model_path_changes.png', dpi=160)
plt.show()
path_changes.to_csv(OUTPUT_DIRECTORY / 'model_path_changes.csv', encoding='utf-8-sig')
"""
results=pd.read_csv(root/'survey_results/all_candidate_results.csv')
best_pairs=results.loc[results.family.ne('Most frequent')].sort_values('mean_test_macro_f1',ascending=False,kind='stable').drop_duplicates(['path','family'])
comparison_matrix=best_pairs.pivot(index='path',columns='family',values='mean_test_macro_f1')
shell=TerminalInteractiveShell.instance()
shell.run_cell('%matplotlib inline',store_history=False)
shell.display_formatter.active_types=['text/plain','text/html','image/png']
shell.display_formatter.formatters['text/html'].enabled=True
import matplotlib.pyplot as plt
plt.rcParams.update({'figure.dpi':110,'axes.spines.top':False,'axes.spines.right':False})
shell.user_ns.update({'pd':pd,'np':np,'plt':plt,'comparison_matrix':comparison_matrix,'OUTPUT_DIRECTORY':root/'survey_results'})
with capture_output() as captured:
 result=shell.run_cell(comparison_code,store_history=True)
assert result.error_before_exec is None and result.error_in_exec is None
cell=next(c for c in notebook.cells if c.cell_type=='code' and c.source.startswith('search_results ='))
cell.source+='\n'+comparison_code
for output in captured.outputs:
 cell.outputs.append(nbformat.v4.new_output('display_data',data=output.data,metadata=output.metadata))
if captured.stdout:cell.outputs.append(nbformat.v4.new_output('stream',name='stdout',text=captured.stdout))
for c in notebook.cells:
 if c.cell_type=='markdown' and c.source.startswith('### תרשימים משותפים'):
  c.source+='\n\nכדי לראות אם הקיבוץ מועיל באופן עקבי, תרשים נוסף מציג לכל אחת מעשר המשפחות את ציון מסלול הקבוצות פחות ציון המסלול הישיר, כולל אנסמבל חמשת המודלים. ערך חיובי מעיד על שיפור שנצפה במסלול הקבוצות. כל נקודה מייצגת את המפרט הטוב שנבדק לאותה משפחה ולמסלול, ולכן ההפרש כולל גם את בחירת הפרמטרים ואינו השפעה מבודדת של פעולת הקיבוץ. בחלק הישיר נבחר גם הנרמול מתוך None ו-L2.\n\nבשלוש משפחות נצפה שיפור קטן עם קבוצות: Random forest בכ-0.017, Histogram boosting בכ-0.005 ו-CatBoost בכ-0.002. בשבע האחרות המסלול הישיר גבוה יותר, ובהן האנסמבל עם 0.372 לעומת 0.322. התוצאות אינן זהות, אך אינן מראות יתרון עקבי של הקיבוץ. קו הבסיס שמנבא תמיד את המקצוע השכיח אינו תלוי בייצוג ולכן מחושב פעם אחת.\n'
nbformat.write(notebook,root/'survey_complete.ipynb')
print(shell.user_ns['path_changes'].round(4).to_string())

from pathlib import Path
import ast, hashlib, json, re, zipfile
import nbformat
import numpy as np
import pandas as pd
root=Path('/workspace/scratch/14b0f58f673c/repo/project_notebooks/survey')
notebook=nbformat.read(root/'survey_complete.ipynb',as_version=4)
nbformat.validate(notebook)
code_cells=[cell for cell in notebook.cells if cell.cell_type=='code']
for cell in code_cells:
 ast.parse(cell.source)
 assert cell.execution_count is not None
 assert not any(output.output_type=='error' for output in cell.outputs)
assert all(index>0 and notebook.cells[index-1].cell_type=='markdown'
           for index,cell in enumerate(notebook.cells) if cell.cell_type=='code')
results=root/'survey_results'
manifest=json.loads((results/'run_manifest.json').read_text())
candidates=pd.read_csv(results/'all_candidate_results.csv')
folds=pd.read_csv(results/'all_candidate_fold_scores.csv')
assert len(candidates)==127 and len(folds)==127 and manifest['folds']==10
assert np.isfinite(candidates.filter(regex='mean_|std_').to_numpy()).all()
assert np.isfinite(folds.filter(regex='split').to_numpy()).all()
assert set(candidates.path)=={'Direct TF-IDF','Cluster one-hot'}
assert candidates.family.nunique()==11
assert pd.read_csv(results/'partial_predictions.csv').shape[0]==9
assert pd.read_csv(results/'selected_test_predictions.csv').shape[0]==35
quality=pd.read_csv(results/'data_quality_counts.csv')
assert len(quality)==18 and quality.iloc[:,1:].sum(axis=1).eq(200).all()
assert pd.read_csv(results/'source_issues.csv').shape[0]==15
assert manifest['source_sha256']==hashlib.sha256(Path('/workspace/scratch/14b0f58f673c/DUMMY_DATASET.xlsx').read_bytes()).hexdigest()
assert not manifest['actual_colab_session_tested']
assert json.loads((root/'source_inventory.json').read_text())['files'].__len__()==11
with zipfile.ZipFile(root/'survey_presentation.pptx') as presentation:
 slides=[name for name in presentation.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml',name)]
 assert len(slides)==10
 assert len([name for name in presentation.namelist() if re.fullmatch(r'ppt/charts/chart\d+\.xml',name)])==5
for matrix_name in ['direct_tfidf','cluster_onehot']:
 from scipy.sparse import load_npz
 matrix=load_npz(results/f'{matrix_name}_training_matrix.npz')
 columns=json.loads((results/'training_matrix_columns.json').read_text())[matrix_name]
 assert matrix.shape[0]==156 and matrix.shape[1]==len(columns)
print(json.dumps({'code_cells_executed':len(code_cells),'candidates':len(candidates),'folds':10,
 'source_records':200,'slides':len(slides),'test_rows':35,'partial_predictions':9},indent=2))

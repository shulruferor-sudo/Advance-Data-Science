from pathlib import Path
import time
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager

notebook_path = Path('/workspace/scratch/14b0f58f673c/repo/project_notebooks/survey/survey_complete.ipynb')
notebook = nbformat.read(notebook_path, as_version=4)
nbformat.validate(notebook)
started = time.perf_counter()

def announce(cell, cell_index, **kwargs):
    if cell.cell_type == 'code':
        print(f'Cell {cell_index} started at {time.perf_counter() - started:.1f}s', flush=True)

kernel_manager = KernelManager(kernel_name='survey-validation', transport='ipc',
    ip='/workspace/scratch/14b0f58f673c/survey-kernel')
client = NotebookClient(notebook, timeout=1800, kernel_name='survey-validation', km=kernel_manager,
                        resources={'metadata': {'path': str(notebook_path.parent)}},
                        on_cell_start=announce)
try:
    client.execute()
finally:
    nbformat.write(notebook, notebook_path)
print(f'COMPLETE: {time.perf_counter() - started:.1f}s', flush=True)

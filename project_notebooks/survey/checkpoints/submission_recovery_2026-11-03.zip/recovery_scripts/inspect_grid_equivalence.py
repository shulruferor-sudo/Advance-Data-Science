# Check the submitted full grids against their documented defaults without fitting models.
from pathlib import Path
import json,ast
notebook=json.loads(Path('repo/project_notebooks/survey/survey_complete.ipynb').read_text())
source='\n'.join(''.join(c['source']) for c in notebook['cells'] if c['cell_type']=='code')
assert "GridSearchCV(model_pipeline, parameter_grids" in source
assert "RandomizedSearchCV" not in source
assert "'classifier__xgboost__min_child_weight': [0, 0.1, 1]" in source
assert 'smooth_idf=False' in source
assert 'n_splits=10' in source
assert "set_params(memory=None)" in source
print('Grid, preprocessing and validation source checks passed.')

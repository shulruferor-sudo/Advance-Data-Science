import fs from 'node:fs/promises';
const ink='#173446', teal='#147D92', gold='#B89B58', paper='#F7F9FA', muted='#536774';
const source='https://drive.google.com/drive/folders/1XMeO2TSCBxGl2HXWhOMCbBH9XqVUOL5g';
const notebook='https://github.com/shulruferor-sudo/Advance-Data-Science/blob/main/project_notebooks/survey/survey_complete.ipynb';
function text(slide,name,value,left,top,width,height,size=25,color=ink,bold=false,alignment='right') {
 const shape=slide.shapes.add({geometry:'textbox',name,position:{left,top,width,height},fill:'none',line:{style:'solid',fill:'none',width:0}});
 shape.text=value;shape.text.style={fontSize:size,typeface:'Arial',color,bold,alignment,verticalAlignment:'top',insets:0,wrap:'word'};return shape;
}
function base(presentation,index,title,reason) {
 const slide=index===0?presentation.slides.getItem(0):presentation.slides.add();
 slide.background.fill=paper;
 text(slide,'title',title,60,38,1160,64,40,ink,true);
 if(reason)text(slide,'reason',reason,60,113,1160,77,25,muted);
 text(slide,'page',String(index+1).padStart(2,'0'),60,674,70,24,16,muted,false,'left');
 return slide;
}
function table(slide,values,top=215,height=370,widths=[390,390,380],font=25) {
 const result=slide.tables.add({rows:values.length,columns:values[0].length,left:60,top,width:1160,height,values,columnWidths:widths});
 result.borders.assign({style:'solid',fill:'#D7E0E4',width:1});
 for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++) {
  const cell=result.getCell(r,c);cell.fill=r===0?ink:(r%2?paper:'#EDF2F4');
  cell.text.style={fontSize:font,typeface:'Arial',alignment:'right',color:r===0?'#FFFFFF':ink,bold:r===0,insets:10};
 }
 return result;
}
function note(slide,body,refs=[source,notebook]) {slide.speakerNotes.text=body+'\n\nמקורות:\n'+refs.join('\n');}
function chart(slide,categories,series,position,options={}) {
 series=series.map(item=>({...item,values:item.values.map(value=>Number(value.toFixed(6)))}));
 return slide.charts.add('bar',{position,categories,series,hasLegend:true,
 barOptions:{direction:options.direction||'bar',grouping:options.stacked?'stacked':'clustered',gapWidth:options.gap||60},
 legend:{position:'bottom',textStyle:{typeface:'Arial',fontSize:17,fill:ink}},
 xAxis:{min:0,max:options.max,numberFormatCode:options.format||'0.00',textStyle:{typeface:'Arial',fontSize:16,fill:muted},majorGridlines:{style:'solid',fill:'#D7E0E4',width:1}},
 yAxis:{min:0,max:options.max,numberFormatCode:options.format||'0.00',textStyle:{typeface:'Arial',fontSize:options.labelSize||18,fill:ink}},
 dataLabels:{showValue:options.labels??false,position:options.stacked?'center':'outEnd',numberFormatCode:options.format||'0.00',textStyle:{typeface:'Arial',fontSize:15,fill:ink}},
 chartFill:paper,plotAreaFill:paper,chartLine:{style:'solid',fill:'none',width:0},plotAreaLine:{style:'solid',fill:'none',width:0}});
}
export async function first(presentation) {
 let slide=base(presentation,0,'סיווג משלחי יד מנתוני סקר','');
 text(slide,'why','כדי לצמצם עבודת סימול ידנית,\nנבנה חיזוי משלח יד לשאלונים חדשים.',125,208,1030,138,36,ink);
 text(slide,'scope','מטלת קבלה לתפקיד מדען נתונים בכיר\nOr Shulrufer',125,406,1030,86,27,muted);
 text(slide,'data','200 רשומות סינתטיות    18 שדות    יעד רב-מחלקתי',125,549,1030,40,27,teal,true);
 text(slide,'assessment','מטרת ההגשה: החלטות מבוססות נתונים ותהליך שניתן להריץ מחדש',125,608,1030,35,23,muted);
 note(slide,'המטלה מבקשת סיווג אוטומטי של משלח יד לשאלונים חדשים. הצעת סימול לסמלן היא שלב הטמעה מוצע. מדדי ההטמעה יהיו זמן טיפול ושיעור טעויות מאומת. המטלה אומרת שאין משמעות לתוצאות החיזוי לצורך הערכת ההגשה. כ-90% נכונות מתייחסים לסימול ידני במדגם בדיקות, ולא לתקרת ביצועים של מודל.');
 slide=base(presentation,1,'שלוש אי-ודאויות שמכתיבות את התהליך','כדי לא להמציא מידע חסר, כל החלטה נשענת על מה שמתועד ועל גבולות הקובץ.');
 table(slide,[['החלטה במימוש','מה חסר כדי להכריע','המשמעות במטלה'],
 ['שומרים שורות ומפרידים תיאורים חוזרים ב-CV','מזהה נסקר ומועד שידור','שאלונים חלקיים ושידורים חוזרים'],
 ['קודים מלאים לאימון, חלקיים להצעות לסמלן','אמת מאומתת ומזהה סמלן','סימול ידני עם טעויות ועם X'],
 ['משלח היד הוא היעד. קוד הענף נשמר לביקורת','מועד זמינות קוד הענף והגדרת תקן הקודים','ענף כלכלי של מקום העבודה ומשלח היד של האדם']
 ],210,378,[420,360,380],26);
 text(slide,'outcome','התוצאה: הנחות מפורשות שניתן לבדוק בהטמעה',60,612,1160,40,27,teal,true);
 note(slide,'ID מוגדר כמספר רץ בלבד. TarichHathala הוא תחילת עבודה ולא מועד השידור. חזרות אינן מוכיחות זהות נסקר. X הוא סימול לא מלא ולא מקצוע נוסף. SemelAnafSofi מתאר ענף כלכלי ו-SemelMishlachSofi מתאר את משלח היד של האדם. תשע רשומות עם X בענף וקוד משלח יד מלא נשמרות באימון. תשע רשומות אחרות עם X ביעד מקבלות הצעות נפרדות. אין פירוש מספרי או היררכיה משוערת לקוד. קוד מלא אינו בהכרח נכון. זמינות SemelAnafSofi לפני החיזוי אינה מתועדת ולכן הוא מחוץ למאפיינים הראשיים.');
 slide=base(presentation,2,'איכות הנתונים בכל 18 השדות','כדי להבחין בין חסר מותר לבין בעיית נתונים, כל תא מקבל מצב אחד בדוח המקור.');
 const fields=['ID','YeshuvAvoda','ShemAvoda','SugAvoda','ShemMachlaka','SugMachlaka','EzoAvoda','TeurPeula','TeurTafkid','MenahelEtMi','MaamadAvoda','MakorSachar','TeudaGvoha','shnotlimud','Gil','TarichHathala','SemelAnafSofi','SemelMishlachSofi'];
 const missing=[0,0,0,25,64,134,7,136,172,168,2,14,2,2,2,0,0,0];
 const special=[0,0,0,4,4,8,4,12,4,0,0,0,0,0,0,0,0,0];
 const partial=fields.map((_,i)=>i>=16?9:0);
 const issue=fields.map((_,i)=>i===8?1:i===11?9:i===16?5:0);
 const content=fields.map((_,i)=>200-missing[i]-special[i]-partial[i]-issue[i]);
 chart(slide,fields.slice().reverse(),[
 {name:'תוכן',values:content.slice().reverse(),fill:teal},
 {name:'חסר',values:missing.slice().reverse(),fill:'#D4DEE4'},
 {name:'ללא תיאור ענייני',values:special.slice().reverse(),fill:gold},
 {name:'קוד חלקי',values:partial.slice().reverse(),fill:'#8666AC'},
 {name:'הפרת כלל',values:issue.slice().reverse(),fill:'#C45B4D'}],{left:45,top:188,width:1175,height:425},{stacked:true,max:200,format:'0',labelSize:17,gap:30});
 text(slide,'findings','9 חריגות תחולה במקור השכר    5 קודי ענף קצרים    0 לא מתועד בתואר משרה',60,622,1160,35,23,ink);
 note(slide,'כל עמודה מסכמת 200 רשומות. חסר אינו בהכרח שגיאה. 9 חריגות במקור שכר: קיים ערך כאשר מעמד העבודה אינו 1 או 5. נשמרים המקור ודוח הבעיות, ובקלט מסומן לא חל. חמישה קודי ענף באורך שלוש נשמרים ללא הוספת אפס. ערך 0 בתואר משרה מסומן לא תקין. כנ״ל, חסוי ולא יכול לפרט מופרדים מתא חסר. בגיליון הסקר יש תא נוסחה J202 מחוץ לרשומות, וב-Metadata יש תאים חוזרים אחרי אזור ההגדרות. שניהם אינם דוגמאות אימון. הצבע תוכן אינו אימות של נכונות הערך.');
 slide=base(presentation,3,'משמעות השדות קובעת את הייצוג','כדי לשמור על מידע שימושי, מפרידים תיאורים, ישויות, קודים וכמויות לפי Metadata.');
 table(slide,[['טיפול זהה בשני המסלולים','שדות','סוג מידע'],
 ['TF-IDF נפרד לכל שדה, בהמשך עם קבוצות או בלעדיהן','פעילות מקום ומחלקה, שם מחלקה, עבודה, פעולות ותואר','6 תיאורים'],
 ['One-hot עם טיפול בקטגוריה חדשה','יישוב ומקום עבודה','2 ישויות'],
 ['One-hot לפי תחומים מתועדים ותנאי תחולה','ניהול, מעמד, מקור שכר ותעודה','4 קודים'],
 ['חציון וקנה מידה נלמדים באימון','גיל, שנות לימוד ושנת תחילת עבודה','3 כמויות'],
 ['נשמרים לחיבור תוצאות ולביקורת','ID, קוד ענף סופי וקוד משלח יד','3 שדות מחוץ לקלט']
 ],205,400,[475,450,235],23);
 text(slide,'meaning','TEXT אינו הוכחה לשדה חופשי. מעט ערכים אינם הוכחה לרשימה סגורה.',60,626,1160,36,25,teal,true);
 note(slide,'אין רשימת ערכים מותרת עבור שדות הטקסט. שם מקום עבודה הוא ישות פתוחה שעשויה לכלול גם תיאור ולכן One-hot הוא פשרה שמגבילה הכללה לשמות חדשים. שם מחלקה ותואר עשויים לשאת משמעות ולכן נשארים תיאורים. תעודה גבוהה היא נומינלית בגלל קודים 8 ו-9. אין ותק ללא תאריך סקר. אין מחיקה מראש של גיל, מעסיק או יישוב.');
 return {slides:4};
}
export {base,text,table,chart,note,ink,teal,gold,paper,muted,source,notebook};

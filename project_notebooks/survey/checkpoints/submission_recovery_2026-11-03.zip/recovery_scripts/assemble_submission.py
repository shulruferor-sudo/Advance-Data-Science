from pathlib import Path
import base64
import gzip
import hashlib
import json
import subprocess
import textwrap

ROOT = Path('/workspace/scratch/14b0f58f673c')
REPOSITORY = ROOT / 'repo'
DESTINATION = REPOSITORY / 'project_notebooks/survey'
cells = []

def markdown(content):
    cells.append(dict(cell_type='markdown', metadata={}, source=textwrap.dedent(content).strip()))

def code(content, hidden=False):
    cells.append(dict(cell_type='code', metadata={'cellView': 'form'} if hidden else {},
                      execution_count=None, source=textwrap.dedent(content).strip(), outputs=[]))

markdown('''
# סיווג משלחי יד מנתוני סקר
**מטלת קבלה לתפקיד מדען נתונים בכיר · Or Shulrufer**

כדי להדגים תהליך שניתן לבדוק ולהריץ מחדש, המחברת עוברת מהגדרת המשימה ומהנתונים המקוריים אל השוואת פתרונות ותחזיות. הדגש הוא על החלטות נכונות וקריאות הקוד. הנתונים סינתטיים, והמטלה מציינת שאין משמעות לציון החיזוי לצורך ההערכה.

[הקוד ב-GitHub](https://github.com/shulruferor-sudo/Advance-Data-Science/blob/main/project_notebooks/survey/survey_complete.ipynb) · [פתיחה ב-Google Colab](https://colab.research.google.com/github/shulruferor-sudo/Advance-Data-Science/blob/main/project_notebooks/survey/survey_complete.ipynb)

**הרצה:** Runtime → Run all, במעבד CPU. קובץ המקור כלול במחברת בתא מכווץ, עם בדיקת שלמות. אין תלות בקבצים מהגרסאות הקודמות. במאגר פרטי אפשר להוריד את המחברת ולהעלות אותה ל-Colab. זמן ההרצה בפועל נמדד ומוצג; אין צורך ב-GPU.

**התוצר:** הגדרות וטיפול בכל 18 העמודות, תרשימים משולבים, כל תוצאות המועמדים שנבדקו, תחזיות בדיקה, הצעות לקודים חלקיים וקובצי תוצאות. מצגת בת עשרה שקפים מסכמת את אותו תהליך.
''')

markdown('''
## 1. מתחילים מהחלטה עסקית שניתן לתמוך בה
כדי לצמצם את עבודת הסימול הידני, נרצה להציע לסמלן קוד משלח יד על בסיס התשובות הזמינות בזמן קבלת השאלון. `SemelMishlachSofi` הוא יעד רב־מחלקתי נומינלי: אין משמעות לחיסור בין שני קודים. התוצר הראשון הוא הצעת סימול; הפעלה אוטומטית תדרוש בהמשך מדידת טעויות וכיסוי על נתוני אמת מאומתים.

שלוש הבחנות מנחות את המימוש:

| מצב במטלה | ההחלטה והנימוק | מה אין בקובץ כדי להכריע יותר |
|---|---|---|
| שאלון חלקי ושידורים חוזרים | שומרים תשובות חסרות; לא ממזגים שורות ולא בוחרים "אחרונה" לפי מספר רץ | מזהה נסקר יציב, מזהה שידור וחותמת זמן לשידור |
| סימול ידני בכ־90% נכונות ו-`X` | קוד חלקי אינו מקצוע חדש. לומדים מקודים מלאים, מפיקים הצעות לחלקיים ומדווחים סתירות | אמת מקצועית מאומתת ומזהה סמלן; אי אפשר לזהות בדיוק 10% תוויות שגויות |
| שדות בעלי משמעות ותזמון שונים | משתמשים במשמעות שב-Metadata; בודקים תנאי מילוי וזמינות בזמן החיזוי | האם קוד הענף הסופי זמין לפני סימול משלח היד; תאריך הסקר לצורך חישוב ותק |

הניתוב האקראי לסמלנים אינו מבטיח שאין טעויות שיטתיות ואינו פותר את החוסר במזהה סמלן. שיעור ה-90% אינו תקרת דיוק של מודל מול אמת מקצועית. חסר מותר אינו בהכרח שגיאת נתונים; קוד מלא אינו בהכרח קוד נכון.
''')

markdown('''
## 2. סביבת ריצה קבועה מאפשרת לשחזר את העבודה
כדי שהמחברת תפעל ב-Colab עם אותו ממשק מודלים, מתקינים לפני הייבוא רק גרסאות חסרות או שונות של התלויות המפורשות. משתמשים בספריות המקובלות של Python ובמימושים הקיימים של scikit-learn. בסיום התא מתקבלת סביבת ריצה מזוהה ותיקייה לתוצאות המחושבות בהרצה זו.
''')
code('''
import importlib.metadata
import subprocess
import sys

for package, version in {'scikit-learn': '1.8.0', 'openpyxl': '3.1.5',
                         'xgboost': '3.0.5', 'lightgbm': '4.6.0', 'catboost': '1.2.10'}.items():
    try:
        installed_version = importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        installed_version = None
    if installed_version != version:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', f'{package}=={version}'])

import base64
import gzip
import hashlib
import io
import json
import re
import tempfile
import time
import warnings
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from IPython.display import display, Markdown
from sklearn.base import clone
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, VotingClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, f1_score, make_scorer, calinski_harabasz_score
from sklearn.model_selection import GridSearchCV, GroupKFold, GroupShuffleSplit, KFold, cross_val_predict
from sklearn.naive_bayes import ComplementNB
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits

RANDOM_SEED = 42
TARGET_FIELD = 'SemelMishlachSofi'
OUTPUT_DIRECTORY = Path('survey_results')
OUTPUT_DIRECTORY.mkdir(exist_ok=True)
threadpool_limits(limits=1)
pd.set_option('display.max_colwidth', 100)
pd.set_option('display.max_columns', None)
plt.rcParams.update({'figure.dpi': 110, 'axes.spines.top': False, 'axes.spines.right': False})
run_started = time.perf_counter()
print({'python': sys.version.split()[0], 'pandas': pd.__version__, 'scikit_learn': sklearn.__version__})
''')

markdown('''
## 3. גבולות טבלת המקור קודמים לניקוי
כדי שלא נלמד מתאים שאינם רשומות סקר, טוענים את שני הגיליונות ומגבילים את הקריאה לאזורי הטבלה שנבדקו בקובץ. גיליון Metadata מכיל 18 הגדרות בארבע עמודות; בהמשך השורה האחרונה מופיע השם `TarichHathala` פעמים רבות ללא הגדרות חדשות. בגיליון הסקר יש 200 רשומות, ואחריהן רק התא `J202` עם הנוסחה `=1.5*1.15`. זו אינה רשומת סקר וגם אינה ממוצע של הנתונים.

הקוד שומר את ערכי המקור בנפרד ומציג את האזור שהוחרג. שמות השדות מחברים בין הטבלאות, משום שסדרם שונה. התוצאה היא טבלת רשומות וטבלת הגדרות שניתן להצליב בלי לשנות את המקור. העותק מ-Drive זהה בבייטים לעותק הנתונים במאגר בעת האיסוף.
''')
source_payload = base64.b64encode(gzip.compress((ROOT / 'DUMMY_DATASET.xlsx').read_bytes(), mtime=0)).decode()
code('#@title קובץ ה-Excel המקורי וטעינת שני הגיליונות\nSOURCE_WORKBOOK_GZIP = '+repr(source_payload)+'''
source_bytes = gzip.decompress(base64.b64decode(SOURCE_WORKBOOK_GZIP))
SOURCE_SHA256 = 'e1e7f391c0675dd14830eaae6b5cd114edc256f18b956bb48a454b0b1209e1ac'
assert hashlib.sha256(source_bytes).hexdigest() == SOURCE_SHA256
workbook = pd.ExcelFile(io.BytesIO(source_bytes), engine='openpyxl')
assert set(workbook.sheet_names) == {'Survey Dataset', 'Metadata'}
metadata = pd.read_excel(workbook, sheet_name='Metadata', usecols='A:D').dropna(subset=['משתנה'])
metadata[['משתנה', 'פורמט']] = metadata[['משתנה', 'פורמט']].apply(lambda column: column.str.strip())
field_definitions = metadata.set_index('משתנה', verify_integrity=True)
source_sheet = pd.read_excel(workbook, sheet_name='Survey Dataset', usecols='A:R', dtype=object)
excluded_cells = source_sheet.loc[source_sheet.ID.isna()].dropna(how='all')
survey_records = source_sheet.loc[source_sheet.ID.notna()].copy().reset_index(drop=True)
assert survey_records.shape == (200, 18) and metadata.shape == (18, 4)
assert survey_records.ID.is_unique and set(survey_records) == set(field_definitions.index)
assert excluded_cells.count().sum() == 1 and np.isclose(excluded_cells.MenahelEtMi.iloc[0], 1.725)
survey_records['ID'] = survey_records.ID.astype('int64')
for field in ['SemelAnafSofi', TARGET_FIELD]:
    survey_records[field] = survey_records[field].astype('string').str.strip().str.upper()
print('Survey records:', len(survey_records), '| Fields:', len(field_definitions))
display(metadata)
display(excluded_cells.dropna(axis=1, how='all'))
''', hidden=True)

markdown('''
## 4. משמעות כל עמודה מגדירה את הטיפול
כדי לנצל את המידע בלי לייחס לקודים משמעות מספרית שגויה, מפרידים בין טקסט, קטגוריה וכמות. שם מעסיק ויישוב עשויים לספק הקשר, לכן אינם נפסלים מראש: הם נכללים בשני המסלולים תחת אותה מדיניות מאפיינים, והסיכון להסתמכות עליהם נרשם להמשך בדיקה על נתוני אמת. תאריך התחלה מספק כאן שנת התחלה בלבד, ולא ותק או סדר שידורים.

שלושה שדות אינם מאפייני חיזוי: היעד עצמו, המספר הרץ, וקוד הענף הסופי שזמינותו בזמן החיזוי אינה מתועדת. הבחירה האחרונה היא הנחת תכנון שמרנית, ולא קביעה שקוד הענף בהכרח דולף. הטבלה מציגה את ההגדרה, הנוכחות והחלטת הטיפול לכל 18 העמודות; היא משמשת חוזה לקלט המודל.
''')
field_decisions = {
    'ID': ('identifier', 'מספר רץ לבדיקת שלמות ולחיבור תחזיות. אינו מזהה נסקר לאורך זמן.'),
    'YeshuvAvoda': ('category', 'יישוב העבודה: קטגוריה נומינלית. וריאציות כתיב נשמרות, ויישוב חדש מטופל כקטגוריה לא מוכרת.'),
    'ShemAvoda': ('category', 'שם מקום העבודה: ישות נומינלית ב-One-hot; זהו שדה פתוח שיכול לכלול גם תיאור כללי; זמינות שם חדש מגבילה את One-hot.'),
    'SugAvoda': ('text', 'פעילות מקום העבודה: נשמרת בנפרד מעבודת הנסקר.'),
    'ShemMachlaka': ('text', 'שם המחלקה: ערוץ טקסט נפרד עם מצב חסר מפורש.'),
    'SugMachlaka': ('text', 'פעילות המחלקה: לא משלימים כנ״ל ללא יעד הפניה מתועד.'),
    'EzoAvoda': ('text', 'העבודה שהנסקר מבצע: ראיה ישירה למשלח היד; נשמרים עברית ואנגלית.'),
    'TeurPeula': ('text', 'פעולות עיקריות: נשמרות גם כשהשדה חסר ברוב השורות.'),
    'TeurTafkid': ('text', 'תואר משרה אם קיים: 0 הוא ערך לא מתועד, ולא מקצוע.'),
    'MenahelEtMi': ('category', 'שלוש קטגוריות ניהול. חסר אינו הוכחה שהאדם אינו מנהל.'),
    'MaamadAvoda': ('category', 'מעמד עבודה: שבע קטגוריות, ללא מרחק מספרי ביניהן.'),
    'MakorSachar': ('category', 'חל רק במעמד 1 או 5. מפרידים לא חל, חסר ותחולה לא ידועה.'),
    'TeudaGvoha': ('category', 'תעודה גבוהה: הקודים 8 ו-9 אינם המשך של סולם כמותי; One-hot.'),
    'shnotlimud': ('numeric', 'שנות לימוד: כמות, השלמת חציון וקנה מידה נלמדים באימון בלבד.'),
    'Gil': ('numeric', 'גיל: כמות זמינה בשאלון; יש לבדוק בהמשך אם תרומתו יציבה על נתונים אמיתיים.'),
    'TarichHathala': ('date', 'תאריך התחלת העבודה: המרה לשנה. אין חישוב ותק בלי תאריך סקר.'),
    'SemelAnafSofi': ('audit', 'קוד ענף סופי: נשמר לביקורת. חמישה קודים קצרים אינם מתוקנים אוטומטית.'),
    'SemelMishlachSofi': ('target', 'קוד יעד נומינלי. קודים מלאים לאימון; X להצעות נפרדות ובדיקת סמלן.')
}
code('FIELD_DECISIONS = '+repr(field_decisions)+'''
TEXT_FIELDS = [field for field, (role, _) in FIELD_DECISIONS.items() if role == 'text']
DESCRIPTION_FIELDS = TEXT_FIELDS.copy()
CATEGORY_FIELDS = [field for field, (role, _) in FIELD_DECISIONS.items() if role == 'category']
NUMBER_FIELDS = ['shnotlimud', 'Gil', 'start_year']
INPUT_FIELDS = [field for field, (role, _) in FIELD_DECISIONS.items()
                if role in ['text', 'category', 'numeric', 'date']]
allowed_codes = {field: set(map(int, re.findall(r'(?m)^\\s*(\\d+)\\.', str(definition))))
                 for field, definition in field_definitions['ערכים אפשריים'].items()}
column_overview = pd.DataFrame({
    'definition': field_definitions['הסבר'], 'source_format': field_definitions['פורמט'],
    'missing': survey_records.isna().sum(), 'distinct': survey_records.nunique(),
    'role': {field: decision[0] for field, decision in FIELD_DECISIONS.items()},
    'treatment': {field: decision[1] for field, decision in FIELD_DECISIONS.items()}
}).reindex(survey_records.columns).rename_axis('field')
assert set(FIELD_DECISIONS) == set(survey_records)
display(column_overview)
''')

markdown('''
## 5. מפרידים בעיות מקור מחוסר מידע מותר
כדי לתקן רק מה שמוצדק, בודקים טיפוסים, ערכים מותרים ותנאים בין שדות לפני המידול. המשפט "מלא רק במידה" בשדה מקור השכר מגביל את תחולתו לשכיר או לחבר קואופרטיב; הוא אינו מחייב שכל זכאי ימלא אותו. ערך שמפר תנאי נשמר בדוח המקור ומסומן כלא חל בקלט המודל.

`כנ״ל` מסמן הפניה לא פתורה; `חסוי` ו-`לא יכול לפרט` מציינים אי־מסירה; `0` בתואר משרה אינו ערך מוגדר. אלה אינם אותו מצב כמו תא ריק. קוד קצר, כמו `123`, עשוי לנבוע מאובדן אפס מוביל או מסיבה אחרת; אין די מידע כדי להחליט ולהשלים אותו.

התוצאה היא רשימת בעיות עם מזהי השורות, טבלת מצבי טקסט, ומבט משולב על כל העמודות. חסרים מוצגים בנפרד מקודים חלקיים ומהפרות כללים. נשמרת גם טבלת כל הערכים והשכיחויות, כדי שהתרשים המצומצם לא יסתיר פרטים.
''')
code('''
def normalize_text(values):
    return (values.astype('string').fillna('').str.normalize('NFKC').str.lower()
            .str.replace(r'\\s+', ' ', regex=True).str.strip())

TEXT_STATES = {'': '__missing__', 'כנ"ל': '__reference__', 'כנ״ל': '__reference__',
               'חסוי': '__withheld__', 'לא יכול לפרט': '__withheld__', '0': '__invalid__'}
issue_records = []
for field in survey_records:
    values = survey_records[field]
    populated = normalize_text(values).ne('')
    checks = {}
    if field_definitions.loc[field, 'פורמט'] == 'INTEGER':
        numbers = pd.to_numeric(values, errors='coerce')
        checks['invalid_integer'] = populated & (numbers.isna() | numbers.mod(1).ne(0))
        if allowed_codes[field]:
            checks['outside_domain'] = populated & ~numbers.isin(allowed_codes[field])
    if field_definitions.loc[field, 'פורמט'] == 'DATE':
        checks['invalid_date'] = populated & pd.to_datetime(values, errors='coerce').isna()
    if field in ['SemelAnafSofi', TARGET_FIELD]:
        checks['code_width_or_character'] = populated & ~values.str.fullmatch(r'[0-9X]{4}', na=False)
    for rule, affected in checks.items():
        issue_records.extend({'ID': int(survey_records.loc[index, 'ID']), 'field': field,
                              'rule': rule, 'source_value': str(values.loc[index])}
                             for index in survey_records.index[affected])

salary_conflicts = (survey_records.MaamadAvoda.notna() & ~survey_records.MaamadAvoda.isin([1, 5])
                    & survey_records.MakorSachar.notna())
for record in survey_records.loc[salary_conflicts].itertuples():
    issue_records.append({'ID': record.ID, 'field': 'MakorSachar',
                          'rule': 'salary_not_applicable', 'source_value': str(record.MakorSachar)})
for record in survey_records.loc[normalize_text(survey_records.TeurTafkid).eq('0')].itertuples():
    issue_records.append({'ID': record.ID, 'field': 'TeurTafkid',
                          'rule': 'undocumented_zero', 'source_value': '0'})
source_issues = pd.DataFrame(issue_records)
text_states = survey_records[TEXT_FIELDS].apply(normalize_text).replace(TEXT_STATES)
complete_labels = survey_records[TARGET_FIELD].str.fullmatch(r'[0-9]{4}', na=False)
partial_labels = (survey_records[TARGET_FIELD].str.fullmatch(r'[0-9X]{4}', na=False)
                  & survey_records[TARGET_FIELD].str.contains('X', na=False))
assert (complete_labels | partial_labels).all()
assert len(source_issues) == 15 and salary_conflicts.sum() == 9
all_value_counts = pd.concat([
    survey_records[field].astype('string').fillna('[MISSING]').value_counts(dropna=False)
    .rename_axis('source_value').reset_index(name='count').assign(field=field)
    for field in survey_records], ignore_index=True)
display(source_issues)
display(pd.DataFrame({field: text_states[field].value_counts().reindex(list(dict.fromkeys(TEXT_STATES.values()))).dropna()
                      for field in TEXT_FIELDS}).T)
display(survey_records[['Gil', 'shnotlimud', 'TarichHathala']].agg(['min', 'max']))
print('Complete target codes:', complete_labels.sum(), '| Partial target codes:', partial_labels.sum())
''')

markdown('''
### תרשים אחד מאפשר לראות היכן חסר מידע והיכן נדרש טיפול
כדי להשוות את כל השדות באותו קנה מידה, מחלקים את 200 התאים בכל עמודה למצבים בלעדיים: תוכן, חסר, טקסט לא ענייני, קוד חלקי והפרת כלל. צבע של "תוכן" מציין שהערך קיים ולא נפל בבדיקות הללו; הוא אינו אישור מקצועי לנכונותו. טבלת השכיחויות המצורפת מאפשרת לרדת מכל עמודה לערכים עצמם.
''')
code('''
cell_states = pd.DataFrame('Content', index=survey_records.index, columns=survey_records.columns)
cell_states[survey_records.isna()] = 'Missing'
for field in TEXT_FIELDS:
    special = text_states[field].isin(['__reference__', '__withheld__', '__invalid__'])
    cell_states.loc[special, field] = 'No substantive text'
for field in ['SemelAnafSofi', TARGET_FIELD]:
    cell_states.loc[survey_records[field].str.contains('X', na=False), field] = 'Partial code'
for issue in source_issues.itertuples():
    cell_states.loc[survey_records.ID.eq(issue.ID), issue.field] = 'Rule issue'
state_order = ['Content', 'Missing', 'No substantive text', 'Partial code', 'Rule issue']
data_quality_counts = cell_states.apply(pd.Series.value_counts).T.reindex(columns=state_order, fill_value=0).fillna(0).astype(int)
figure, axis = plt.subplots(figsize=(12, 8))
data_quality_counts.iloc[::-1].plot.barh(stacked=True, ax=axis, width=0.8,
    color=['#147d92', '#d9e0e6', '#bea15a', '#8666ac', '#c45b4d'])
axis.set(xlabel='Records (200 per field)', ylabel='', xlim=(0, 200), title='All 18 fields: availability and documented issues')
axis.legend(loc='lower center', bbox_to_anchor=(0.5, 1.01), ncol=3, frameon=False)
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'all_fields_quality.png', dpi=160)
plt.show()
''')

markdown('''
## 6. הכנה עקבית שומרת על משמעות גם בקלט חסר
כדי שהאימון והחיזוי יקבלו אותם מצבים, משתמשים בפונקציית הכנה אחת. היא מנרמלת Unicode ורווחים, מסמנת את מצבי אי־המסירה, ומיישמת את תנאי מקור השכר. קוד קטגוריאלי לא מוכר מקבל מצב לא תקין; כמות לא ניתנת לפענוח נשארת חסרה. הטבלה המקורית והדוח נשארים זמינים, ולכן ההמרה אינה מסתירה את הבעיה.

השלמת חציון, אוצר המילים, משקלי IDF, קידוד קטגוריות וקנה המידה יילמדו בהמשך בתוך כל קפל אימון. השלב הנוכחי פועל על כל שורה בנפרד, בלי לחשב ממוצע או ללמוד משורות אחרות. התוצאה היא קלט אחיד, עם כל שדה במקומו המקורי.
''')
code('''
def prepare_model_inputs(records):
    prepared_inputs = pd.DataFrame(index=records.index)
    for field in TEXT_FIELDS:
        prepared_inputs[field] = normalize_text(records[field]).replace(TEXT_STATES).astype(str)
    for field in CATEGORY_FIELDS:
        if allowed_codes[field]:
            numbers = pd.to_numeric(records[field], errors='coerce')
            valid_numbers = numbers.where(numbers.isin(allowed_codes[field]))
            categories = valid_numbers.astype('Int64').astype('string').fillna('__missing__')
            invalid_values = records[field].notna() & valid_numbers.isna()
            categories = categories.mask(invalid_values, '__invalid__')
        else:
            categories = normalize_text(records[field]).replace(TEXT_STATES)
        prepared_inputs[field] = categories.astype(str)
    employment_status = pd.to_numeric(records.MaamadAvoda, errors='coerce')
    known_status = employment_status.isin(allowed_codes['MaamadAvoda'])
    prepared_inputs.loc[known_status & ~employment_status.isin([1, 5]), 'MakorSachar'] = '__not_applicable__'
    prepared_inputs.loc[~known_status, 'MakorSachar'] = '__applicability_unknown__'
    for field in ['Gil', 'shnotlimud']:
        numbers = pd.to_numeric(records[field], errors='coerce')
        prepared_inputs[field] = numbers.where(numbers.ge(0) & numbers.mod(1).eq(0)).astype(float)
    prepared_inputs['start_year'] = pd.to_datetime(records.TarichHathala, errors='coerce').dt.year.astype(float)
    return prepared_inputs

model_inputs = prepare_model_inputs(survey_records)
assert set(model_inputs) == set(TEXT_FIELDS + CATEGORY_FIELDS + NUMBER_FIELDS)
display(model_inputs.head())
''')

markdown('''
## 7. חזרות וקודים נדירים קובעים מה באמת ניתן לבדוק
כדי למנוע מתיאורים זהים להופיע משני צדי החלוקה, בונים קבוצות לפי ששת תיאורי הפעילות, ללא מעסיק, יישוב או יעד. זהו מבחן הכללה לתיאורים שלא נראו, ולא זיהוי של נסקרים. שורות שאין בהן שום תיאור ענייני מקבלות קבוצות נפרדות, כדי שלא נניח זהות רק משום שהן ריקות.

לא מוחקים חזרות ולא משלימים משורה אחרת: גם שני אנשים שונים יכולים לתת אותן תשובות. סתירות בין תוויות מדווחות בלי "לתקן" את המיעוט. למשל, בקבוצת תיאורי המעבדה בבית החולים מופיעים `3311` ו-`3211`; הקובץ אינו מוכיח איזו תווית נכונה. לעומת זאת, `335X` ו-`3354` תואמים בספרות הידועות ואינם נספרים כסתירה בין קודים מלאים.

הטבלאות והתרשים המשותף יראו כמה תיאורים חוזרים וכמה מחלקות נתמכות בדוגמה או בקבוצה אחת בלבד. מחלקה שיש לה קבוצה אחת אינה יכולה להיות מיוצגת גם באימון וגם בוולידציה מופרדת קבוצות. זו מגבלת מדידה, ולא סיבה למחוק אותה מהדיווח.
''')
code('''
description_groups = pd.Series(pd.MultiIndex.from_frame(model_inputs[DESCRIPTION_FIELDS]).factorize()[0],
                               index=survey_records.index).astype(str)
has_description = ~model_inputs[DESCRIPTION_FIELDS].apply(lambda column: column.str.startswith('__')).all(axis=1)
description_groups.loc[~has_description] = 'empty_record_' + survey_records.loc[~has_description, 'ID'].astype(str)
group_summary = survey_records.assign(description_group=description_groups).groupby('description_group').agg(
    records=('ID', 'size'))
complete_code_counts = survey_records.loc[complete_labels].assign(
    description_group=description_groups.loc[complete_labels]).groupby('description_group')[TARGET_FIELD].nunique()
group_summary['distinct_complete_codes'] = complete_code_counts.reindex(group_summary.index, fill_value=0)
conflicting_groups = group_summary.index[group_summary.distinct_complete_codes.gt(1)]
display(survey_records.loc[description_groups.isin(conflicting_groups), ['ID', *DESCRIPTION_FIELDS, TARGET_FIELD]])
print('Repeated source rows beyond the first, excluding ID:', survey_records.drop(columns='ID').duplicated().sum())
print('Description groups:', description_groups.nunique(), '| Conflicting groups:', len(conflicting_groups))

labeled_inputs = model_inputs.loc[complete_labels].reset_index(drop=True)
occupation_codes = survey_records.loc[complete_labels, TARGET_FIELD].astype(str).reset_index(drop=True)
labeled_groups = description_groups.loc[complete_labels].reset_index(drop=True)
labeled_record_ids = survey_records.loc[complete_labels, 'ID'].reset_index(drop=True)
class_support = pd.DataFrame({'code': occupation_codes, 'description_group': labeled_groups}).groupby('code').agg(
    records=('description_group', 'size'), groups=('description_group', 'nunique'))
display(class_support.sort_values('records'))
figure, axes = plt.subplots(1, 2, figsize=(14, 4.5))
class_support.sort_values('records', ascending=False)[['records', 'groups']].plot.bar(ax=axes[0], width=0.9)
axes[0].set(title='All complete occupation codes: records and description groups', xlabel='Occupation code', ylabel='Count')
axes[0].tick_params(axis='x', labelsize=6)
group_summary.records.value_counts().sort_index().plot.bar(ax=axes[1], color='#147d92')
axes[1].set(title='Repeated description patterns', xlabel='Records per description group', ylabel='Groups')
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'labels_and_repetition.png', dpi=160)
plt.show()
''')

markdown('''
## 8. חלוקה הוגנת לפני למידת ייצוג או בחירת מודל
כדי שההשוואה תבחן הכללה ולא זיכרון של אותו תיאור, שומרים קבוצת בדיקה ומפרידים את קבוצות התיאור גם בעשרת קפלי האימון. `GroupKFold` מתאים לאילוץ הזה, אך אינו מבטיח שכל מקצוע יופיע בכל צד. הטבלה תציג את גודל הקפלים ואת מספר הרשומות שמחלקתן חסרה באימון.

הבחירה תתבסס על macro-F1 ממוצע בקפלי האימון, לצד accuracy ועלות הריצה. משתמשים בהגדרת scikit-learn הרגילה: ממוצע F1 על איחוד המחלקות האמיתיות והחזויות בכל קפל, עם אפס למקרה לא מוגדר. לכן השוואות נעשות על אותם קפלים, וסטיית התקן ביניהם מתארת שונות, לא רווח סמך.

לא מכוונים חלוקה לפי תוצאה ולא מסירים מחלקות נדירות. ציון הבחירה לאחר חיפוש אינו אומדן נטול הטיה. קבוצת הבדיקה נשמרת מהכוונון בהרצה זו, אבל הנתונים הסינתטיים כבר נבחנו בגרסאות קודמות; זו הדגמת תהליך ולא בדיקת ייצור עצמאית.
''')
code('''
training_positions, test_positions = next(GroupShuffleSplit(n_splits=1, test_size=0.22,
    random_state=RANDOM_SEED).split(labeled_inputs, occupation_codes, labeled_groups))
training_features, test_features = labeled_inputs.iloc[training_positions], labeled_inputs.iloc[test_positions]
training_codes, test_codes = occupation_codes.iloc[training_positions], occupation_codes.iloc[test_positions]
training_groups = labeled_groups.iloc[training_positions]
validation_splits = list(GroupKFold(n_splits=10, shuffle=True, random_state=RANDOM_SEED).split(
    training_features, training_codes, training_groups))
assert set(training_groups).isdisjoint(labeled_groups.iloc[test_positions])
fold_records = []
for fold_number, (fit_positions, validation_positions) in enumerate(validation_splits, 1):
    assert set(training_groups.iloc[fit_positions]).isdisjoint(training_groups.iloc[validation_positions])
    fold_records.append({'fold': fold_number, 'training_records': len(fit_positions),
        'validation_records': len(validation_positions), 'unseen_label_records': int(
            (~training_codes.iloc[validation_positions].isin(training_codes.iloc[fit_positions])).sum())})
fold_overview = pd.DataFrame(fold_records)
assert sorted(np.concatenate([positions for _, positions in validation_splits])) == list(range(len(training_features)))
display(fold_overview)
print('Training / test records:', len(training_features), len(test_features))
print('Test records with unseen labels:', (~test_codes.isin(training_codes)).sum())
''')


markdown('''
## 9. בחירת ייצוג נובעת ממשמעות השדה
כדי שלא נבלבל בין טיפוס אחסון ובין אופן המענה, מפרידים בין מה שמתועד ובין החלטת מידול. ארבע רשימות ערכים ממוספרות מוגדרות במפורש ב-Metadata: ניהול, מעמד עבודה, מקור שכר ותעודה. אלה קטגוריות גם כשהן נשמרות כמספר. בשדות הטקסט אין רשימת ערכים מותרת ואין תיאור של ממשק המענה; לכן אי אפשר לקבוע מהקובץ אם היו תיבות טקסט או רשימות בחירה.

| שדות | המשמעות המתועדת וההחלטה | מה נבדק במקום להניח |
|---|---|---|
| `YeshuvAvoda`, `ShemAvoda` | ישויות: יישוב ומקום עבודה. One-hot כקו בסיס, עם טיפול בישות שלא נראתה | שם מקום העבודה כולל לעיתים תיאור כללי; הפשרה ב-One-hot היא אובדן דמיון לשם חדש |
| `SugAvoda`, `SugMachlaka`, `EzoAvoda`, `TeurPeula` | פעילות ועשייה: תיאורים לשוניים, ולכן TF-IDF | איכות הייצוג ואובדן מידע באשכולות נבדקים על אותם קפלים |
| `ShemMachlaka`, `TeurTafkid` | שם מחלקה ותואר משרה: אין מילון סגור מתועד; ניסוחים חדשים יכולים לשאת משמעות | 16 ערכים נצפים בתואר המשרה אינם מילון סגור; נדרשת הגדרת השאלון כדי לאשר זאת |
| ארבעת הקודים הממוספרים | תחומים סגורים מתועדים: One-hot | ערכים מחוץ לתחום מסומנים במפורש |
| גיל, שנות לימוד ושנת תחילת תפקיד | כמויות ולא תוויות | נשמרות מספריות; לא נגזר ותק ללא תאריך הסקר |

חזרתיות או מספר קטן של ערכים שנצפו אינם הוכחה לשאלון סגור. מנגד, שם יישוב אינו דורש TF-IDF רק משום שהוא TEXT. ההחלטה נובעת מהמשמעות; אימות סוג ממשק המענה נותר שאלה להטמעה, ולא עובדה שממציאים מהמדגם.
''')

markdown('''
## 10. שני מסלולים מפורשים לפני בחירת מסווג
כדי לבדוק אם grouping מוסיף מידע שימושי או מאבד הבחנות חשובות, בונים שני ייצוגים של אותם שדות:

1. **Direct TF-IDF:** ששת התיאורים מיוצגים במשקלי TF-IDF; שדות הקטגוריה ב-One-hot. מוצגים המשקלים הגולמיים ללא L2. בהשוואת המודלים נבחן גם L2 כהגדרה בתוך מסלול זה.
2. **Cluster one-hot:** בכל שדה תיאור מבצעים TF-IDF ללא smoothing, נרמול L2, בחירת מספר קבוצות עם K-means, וקידוד One-hot של זהות הקבוצה. גם שדות הקטגוריה מקודדים ב-One-hot.

בשני המסלולים `smooth_idf=False` ו-TF רגיל. מימוש scikit-learn משתמש ב-`idf = log(n / df) + 1` גם בלי smoothing; לא מחליפים זאת בנוסחה אחרת. L2 מביא כל וקטור לא־אפס לאורך יחידה, כך שמכפלה פנימית בין שני וקטורים מנורמלים שווה לדמיון קוסינוס. הוא מפחית השפעה של אורך התיאור; האורך עשוי לשאת מידע, ולכן במסלול הישיר הוא נבדק ולא מוכרע מראש. לפני K-means הנרמול תמיד מופעל.

לכל שדה נבחנים כל מספרי הקבוצות השלמים מ-2 עד מספר הווקטורים השונים פחות 1. בוחרים את ציון Calinski–Harabasz הגבוה ביותר, ובשוויון את המספר הקטן יותר. זה מדד לפיזור בין ובתוך קבוצות, לא לאיכות סיווג מקצועי. כל ניסוח ענייני שונה מקבל משקל אחד בבחירת הקבוצות, כדי שחזרות סינתטיות לא יכריעו את הגאומטריה. IDF עצמו נלמד משורות האימון.

מצבי חסר, אי־מסירה והפניה נשארים קטגוריות מפורשות ואינם משתתפים בבחירת קבוצות התוכן. כשאין די וקטורים שונים, נשמרים מצב ריק או עד שני מרכזים ללא אופטימיזציית CH. טקסט ללא מונח מוכר מקבל קטגוריית טקסט חדש, ולא קבוצה סמנטית מומצאת. המתאם הקצר הבא מחבר את המימושים הקיימים של TF-IDF, KMeans ו-OneHotEncoder; הוא אינו מממש מחדש את האלגוריתמים.
''')
code('''
from sklearn.base import BaseEstimator, TransformerMixin

def text_vectorizer(normalization=None):
    return TfidfVectorizer(smooth_idf=False, norm=normalization, sublinear_tf=False,
                          token_pattern=r'(?u)\\b\\w+\\b')

class TextGroups(BaseEstimator, TransformerMixin):
    def __init__(self, random_state=42):
        self.random_state = random_state

    def fit(self, texts, labels=None):
        texts = pd.Series(np.asarray(texts), dtype=str)
        self.vectorizer_ = text_vectorizer('l2').fit(texts)
        content = texts.loc[~texts.str.startswith('__')].drop_duplicates()
        self.scores_, self.model_, self.selected_clusters_ = [], None, 0
        if content.empty:
            return self
        vectors = self.vectorizer_.transform(content)
        distinct_vectors = np.unique(vectors.toarray(), axis=0)
        distinct_vectors = distinct_vectors[np.linalg.norm(distinct_vectors, axis=1) > 0]
        assert np.allclose(np.linalg.norm(distinct_vectors, axis=1), 1)
        self.scores_, self.model_ = [], None
        if len(distinct_vectors) == 0:
            return self
        best_score = -np.inf
        cluster_counts = range(2, len(distinct_vectors)) if len(distinct_vectors) > 2 else [len(distinct_vectors)]
        for cluster_count in cluster_counts:
            candidate = KMeans(n_clusters=cluster_count, n_init=10, max_iter=300,
                               random_state=self.random_state).fit(distinct_vectors)
            score = calinski_harabasz_score(distinct_vectors, candidate.labels_) if len(distinct_vectors) > 2 else np.nan
            self.scores_.append({'clusters': cluster_count, 'CH': score, 'iterations': candidate.n_iter_})
            if self.model_ is None or score > best_score:
                self.model_, best_score = candidate, score
        self.selected_clusters_ = self.model_.n_clusters
        return self

    def transform(self, texts):
        texts = pd.Series(np.asarray(texts), dtype=str)
        categories = texts.where(texts.str.startswith('__'), '__unseen_text__').to_numpy(dtype=object)
        if self.model_ is not None:
            vectors = self.vectorizer_.transform(texts)
            usable = ~texts.str.startswith('__').to_numpy() & (vectors.getnnz(axis=1) > 0)
            if usable.any():
                categories[usable] = [f'group_{number}' for number in self.model_.predict(vectors[usable].toarray())]
        return categories.reshape(-1, 1)

def build_preprocessor(path='Direct TF-IDF', normalization=None):
    text_transformers = []
    for field in TEXT_FIELDS:
        encoder = text_vectorizer(normalization) if path == 'Direct TF-IDF' else Pipeline([
            ('groups', TextGroups(RANDOM_SEED)), ('onehot', OneHotEncoder(handle_unknown='ignore'))])
        text_transformers.append((field, encoder, field))
    return ColumnTransformer(text_transformers + [
        ('categories', OneHotEncoder(handle_unknown='ignore'), CATEGORY_FIELDS),
        ('numbers', Pipeline([('impute', SimpleImputer(strategy='median', add_indicator=True, keep_empty_features=True)),
                              ('scale', MinMaxScaler(clip=True))]), NUMBER_FIELDS)
    ], remainder='drop', sparse_threshold=0)
''')

markdown('''
### טבלאות המאפיינים מציגות מה המסווג יקבל בפועל
כדי לבדוק את הייצוג לפני המודלים, מתאימים כעת את שני המסלולים לחלק האימון בלבד ומציגים דוגמאות מספריות, ממדים ומספר קבוצות לכל שדה. אלה עותקי המחשה; בוולידציה תתבצע התאמה חדשה בתוך כל קפל.

במסלול הישיר רואים משקלי TF-IDF אמיתיים של מונחים, ללא L2. במסלול הקבוצות רואים ערכי 0/1. גם שם גיל, שנות לימוד ושנת התחלה נשארים כמותיים; "כל הטקסט ב-One-hot" אינו הופך כמויות לקטגוריות. הטבלאות המלאות נשמרות, והתרשים המאוחד מציג את בחירת מספר הקבוצות בכל השדות יחד.
''')
code('''
direct_preview = build_preprocessor().fit(training_features, training_codes)
cluster_preview = build_preprocessor('Cluster one-hot').fit(training_features, training_codes)
direct_matrix = direct_preview.transform(training_features)
cluster_matrix = cluster_preview.transform(training_features)
raw_tfidf_examples, cluster_examples, cluster_search_records, cluster_memberships = [], [], [], []
representation_records = []
for field in TEXT_FIELDS:
    vectorizer = direct_preview.named_transformers_[field]
    weights = vectorizer.transform(training_features[field]).toarray()
    terms = vectorizer.get_feature_names_out()
    substantive_terms = np.flatnonzero(~pd.Series(terms).str.startswith('__'))
    chosen_terms = substantive_terms[np.argsort(-weights[:, substantive_terms].sum(axis=0))[:3]]
    raw_tfidf_examples.append(pd.DataFrame(weights[:, chosen_terms], columns=[field + ' / ' + terms[index] for index in chosen_terms]))
    group_pipeline = cluster_preview.named_transformers_[field]
    learned_groups = group_pipeline.named_steps['groups']
    group_matrix = group_pipeline.transform(training_features[field]).toarray()
    cluster_examples.append(pd.DataFrame(group_matrix, columns=[field + ' / ' + category
        for category in group_pipeline.named_steps['onehot'].categories_[0]]))
    representation_records.append({'field': field, 'raw_tfidf_dimensions': weights.shape[1],
        'content_clusters': getattr(learned_groups, 'selected_clusters_', 0),
        'onehot_dimensions': group_matrix.shape[1]})
    cluster_search_records.extend({'field': field, **result} for result in learned_groups.scores_)
    cluster_memberships.extend({'field': field, 'text': text, 'group': category}
        for text, category in zip(training_features[field], learned_groups.transform(training_features[field]).ravel()))
raw_tfidf_sample = pd.concat(raw_tfidf_examples, axis=1)
onehot_sample = pd.concat(cluster_examples, axis=1)
representation_overview = pd.DataFrame(representation_records)
cluster_search_results = pd.DataFrame(cluster_search_records)
display(representation_overview)
display(raw_tfidf_sample.head(8).round(3))
display(onehot_sample.head(8))
assert set(np.unique(onehot_sample)).issubset({0, 1})
print('Complete training matrices:', direct_matrix.shape, cluster_matrix.shape)
cluster_scores_matrix = cluster_search_results.pivot(index='field', columns='clusters', values='CH').reindex(TEXT_FIELDS)
figure, axes = plt.subplots(1, 2, figsize=(14, 4.5), gridspec_kw={'width_ratios': [1, 1.5]})
representation_overview.set_index('field')[['raw_tfidf_dimensions', 'onehot_dimensions']].plot.barh(ax=axes[0])
axes[0].set(xlabel='Features per text field', ylabel='', title='Both representations, every text field')
heatmap = axes[1].imshow(np.log1p(cluster_scores_matrix), aspect='auto', cmap='YlGnBu')
axes[1].set_yticks(range(len(TEXT_FIELDS)), TEXT_FIELDS)
tick_positions = np.arange(0, len(cluster_scores_matrix.columns), 5)
axes[1].set_xticks(tick_positions, cluster_scores_matrix.columns[tick_positions])
axes[1].set(xlabel='Candidate group count', title='All admissible K values; blank = not admissible')
figure.colorbar(heatmap, ax=axes[1], label='log(1 + CH); compare K within each field')
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'two_representations.png', dpi=160)
plt.show()
''')

markdown('''
## 11. פרמטרים נבחרים לפי השפעתם הצפויה על המדגם
כדי לזהות איזו הנחת מודל מתאימה לייצוגים, משווים את כל המשפחות באותם עשרה קפלי אימון. ריבוי מקצועות ומעט דוגמאות לכל מקצוע מכוונים את החיפוש לרגולריזציה, גודל עלים ועומק, ולא לרשתות גדולות. כל הערכים נקבעים לפני קריאת תוצאות הבדיקה. אין הגרלה ואין הבטחה מוקדמת שאלו הערכים הטובים בעולם: זו השוואה מוגבלת ומנומקת.

| מודל | פרמטרים וערכים מפורשים | מדוע דווקא אלה |
|---|---|---|
| LogisticRegression | `C=[0.1, 1, 10]` | עשירית, ברירת המחדל ופי עשרה: טווח לוגריתמי לבדיקת רגולריזציה חזקה, בינונית וחלשה במרחב טקסט רחב |
| RandomForestClassifier | `min_samples_leaf=[1, 2, 4]`, `max_features=['sqrt', 0.5, 1.0]` | עלה יחיד שומר אות נדיר אך עלול לזכור רעש. 2 ו-4 דורשים תמיכה נוספת. sqrt משווה ברירת מחדל דלילה לדגימת מחצית המאפיינים או כולם כשאותות רבים נדירים |
| HistGradientBoostingClassifier | `max_leaf_nodes=[3, 7, 31]` | 3 ו-7 עלים מגבילים אינטראקציות מול ברירת המחדל 31. `min_samples_leaf=2` קבוע כי ברירת המחדל 20 גדולה ביחס למדגם ולמקצועות הנדירים |
| SVC עם RBF | `C=[0.1, 1, 10]` | אותו טווח לוגריתמי לענישה על שגיאות. `gamma='scale'` מתאים את קנה המידה לשונות המאפיינים בתוך כל קפל |
| XGBClassifier | `max_depth=[1, 3, 6]`, `min_child_weight=[0, 0.1, 1]` | גדם ושלוש רמות מגבילים מורכבות מול ברירת המחדל שש. ברירת המחדל 1 עלולה לחסום פיצולים במקצועות נדירים כי Hessian רב־מחלקתי קטן. 0 מסיר חסם זה ו-0.1 בודק סף נמוך פי עשרה עם דרישת תמיכה מסוימת. אין פירושו אפס רשומות לעלה |
| LGBMClassifier | `min_child_samples=[2, 5, 20]` | ברירת המחדל 20 מול 2 לשימור אות נדיר ו-5 להגבלת פיצולים עם מעט תמיכה. 20 עלול למנוע פיצולים שימושיים כאן, ונבדק בפועל. שבעה עלים מגבילים מורכבות |
| CatBoostClassifier | `depth=[2, 4, 6]` | 4, 16 ו-64 עלים לכל היותר בעצים הסימטריים: מגבלה חזקה, בינונית ועומק ברירת המחדל. שישה עלולים כבר להיות גדולים מדי למדגם |
| MLPClassifier | `alpha=[0.0001, 0.01, 1]` | ברירת המחדל 0.0001 מול רגולריזציה חזקה פי 100 ופי 10,000, להגבלת רשת בת 16 יחידות כאשר מספר המאפיינים גדול ממספר הרשומות |
| ComplementNB | `alpha=[0.1, 1, 10]` | בסיס טקסט מהיר: עשירית, Laplace=1 ורגולריזציה חזקה יותר. זהו smoothing של אומדן המסווג, נפרד מ-IDF שנותר ללא smoothing |
| הצבעה רכה של חמישה | `weights=[None, (2,1,1,1,1), (1,2,1,1,1)]` | None היא ברירת המחדל עם משקל שווה. החלופות מדגישות את המודל הליניארי, או הדגשת היער. הרכיבים הם LR, RF, XGBoost, SVC ו-MLP, בסדר זה |

באנסמבל מפרטי הרכיבים נקבעים מראש ומשקלי ההצבעה נבחרים ב-CV. לא משתמשים בזוכים שנבחרו על כל קפלי האימון כאילו היו בחירות בלתי תלויות בתוך אותם קפלים. לכל מודל לכל היותר שני פרמטרי מסווג בחיפוש, ולכל פרמטר שלושה ערכים בדיוק, ובהם ברירת המחדל המתועדת ושתי חלופות. נרמול None/L2 הוא הגדרת עיבוד נוספת במסלול הישיר. ארבעת מסווגי boosting משתמשים בתקציב קבוע של 40 סבבים ובקצב 0.1, כדי להגביל זמן ריצה של הרשת המלאה. התקציב הופחת בחצי לאחר בדיקת זמן ריצה, לפני עיון בציוני המועמדים או הבדיקה. זהו ניסוי להשוואת תהליכים בתקציב מוגבל, ולא מיצוי דיוק של כל ספרייה. אין early stopping על קבוצת הבדיקה. GridSearchCV מקבל את הרשתות עצמן ומחשב את המכפלה הקרטזית המלאה. ParameterGrid משמש רק לשמות ולתיעוד הצירופים באותו סדר.

XGBoost דורש מספרי מחלקות רציפים בכל אימון. `VotingClassifier` עם רכיב יחיד משתמש במקודד התוויות המובנה כדי למפות קודים בתוך הקפל ולהחזיר אותם בחיזוי. זהו מתאם ל-XGBoost יחיד, ולא אנסמבל נוסף. שני הייצוגים קטנים מספיק למערכים צפופים, ולכן כולם מקבלים אותו פורמט, גם HGB שאינו מקבל קלט sparse. ב-XGBoost אפס TF-IDF הוא אפס אמיתי ולא ערך חסר.

לרשת הקטנה משתמשים ב-MLP של scikit-learn עם פלט softmax רב־מחלקתי ו-cross-entropy. מימוש נוסף של אותה רשת ב-TensorFlow או PyTorch אינו מוסיף כאן השערה. גם יערות ו-boosting ב-H2O וב-Spark חוזרים על משפחות שכבר נבדקות ומוסיפים תשתית שאינה דרושה ל-200 רשומות. הם לא הורצו, ואין כאן השוואת מהירות בין מסגרות.

התוצאה תהיה טבלת כל המועמדים וציוני כל קפל. IDF, אוצר מילים, אשכולות, One-hot, השלמת חסרים ומסווג מותאמים רק בתוך חלק האימון של הקפל. `SVC(probability=True)` מוסיף כיול פנימי שאינו מפריד קבוצות תיאור, ולכן אין לפרש את הסתברויותיו כמדד ביטחון מאומת. גם שאר ציוני ההסתברות דורשים כיול חיצוני על מדגם גדול יותר לפני אוטומציה.
''')
code('''
from sklearn.model_selection import ParameterGrid

logistic_model = LogisticRegression(C=1, max_iter=1500, class_weight='balanced', random_state=RANDOM_SEED)
bayes_model = ComplementNB(alpha=1)
forest_model = RandomForestClassifier(n_estimators=120, min_samples_leaf=2, class_weight='balanced',
                                     random_state=RANDOM_SEED, n_jobs=1)
xgboost_model = XGBClassifier(n_estimators=40, max_depth=2, min_child_weight=0, learning_rate=0.1,
    eval_metric='mlogloss', tree_method='hist', random_state=RANDOM_SEED, n_jobs=1)
lightgbm_model = LGBMClassifier(n_estimators=40, num_leaves=7, min_child_samples=5, learning_rate=0.1,
    verbosity=-1, random_state=RANDOM_SEED, n_jobs=1)
catboost_model = CatBoostClassifier(iterations=40, depth=4, learning_rate=0.1, loss_function='MultiClass',
    verbose=False, allow_writing_files=False, random_seed=RANDOM_SEED, thread_count=1)
svm_model = SVC(probability=True, class_weight='balanced', random_state=RANDOM_SEED)
neural_model = MLPClassifier(hidden_layer_sizes=(16,), solver='lbfgs', alpha=0.01,
    max_iter=1000, tol=1e-3, random_state=RANDOM_SEED)
voting_model = VotingClassifier([('logistic', clone(logistic_model)), ('forest', clone(forest_model)),
    ('xgboost', clone(xgboost_model)), ('svm', clone(svm_model)), ('neural', clone(neural_model))],
    voting='soft', n_jobs=1)
model_families = {
    'Logistic regression': (logistic_model, {'classifier__C': [0.1, 1, 10]}),
    'Random forest': (forest_model, {'classifier__min_samples_leaf': [1, 2, 4], 'classifier__max_features': ['sqrt', 0.5, 1.0]}),
    'Histogram boosting': (HistGradientBoostingClassifier(max_iter=40, min_samples_leaf=2,
        early_stopping=False, random_state=RANDOM_SEED), {'classifier__max_leaf_nodes': [3, 7, 31]}),
    'RBF SVC': (svm_model, {'classifier__C': [0.1, 1, 10]}),
    'XGBoost': (VotingClassifier([('xgboost', xgboost_model)], voting='soft'),
        {'classifier__xgboost__max_depth': [1, 3, 6], 'classifier__xgboost__min_child_weight': [0, 0.1, 1]}),
    'LightGBM': (lightgbm_model, {'classifier__min_child_samples': [2, 5, 20]}),
    'CatBoost': (catboost_model, {'classifier__depth': [2, 4, 6]}),
    'Small MLP': (neural_model, {'classifier__alpha': [0.0001, 0.01, 1]}),
    'Complement NB': (bayes_model, {'classifier__alpha': [0.1, 1, 10]}),
    'Soft voting (5)': (voting_model, {'classifier__weights': [None, (2, 1, 1, 1, 1), (1, 2, 1, 1, 1)]})
}
parameter_defaults = {
    'Logistic regression': {'classifier__C': 1},
    'Random forest': {'classifier__min_samples_leaf': 1, 'classifier__max_features': 'sqrt'},
    'Histogram boosting': {'classifier__max_leaf_nodes': 31},
    'RBF SVC': {'classifier__C': 1},
    'XGBoost': {'classifier__xgboost__max_depth': 6, 'classifier__xgboost__min_child_weight': 1},
    'LightGBM': {'classifier__min_child_samples': 20},
    'CatBoost': {'classifier__depth': 6},
    'Small MLP': {'classifier__alpha': 0.0001},
    'Complement NB': {'classifier__alpha': 1},
    'Soft voting (5)': {'classifier__weights': None}}
assert all(parameter_defaults[family][name] in values for family, (_, parameters) in model_families.items()
           for name, values in parameters.items())
assert all(len(parameters) <= 5 and all(len(values) == 3 for values in parameters.values())
           for _, parameters in model_families.values())
parameter_grids, candidate_descriptions = [], []
for path in ['Direct TF-IDF', 'Cluster one-hot']:
    for normalization in ([None, 'l2'] if path == 'Direct TF-IDF' else ['l2']):
        for family, (classifier, parameters) in model_families.items():
            parameter_grids.append({'features': [build_preprocessor(path, normalization)],
                                    'classifier': [classifier], **parameters})
            for combination in ParameterGrid(parameters):
                candidate_descriptions.append({'candidate': f'C{len(candidate_descriptions):03d}',
                    'path': path, 'family': family, 'normalization': normalization or 'None',
                    'experiment': 'Main comparison', 'parameters': json.dumps(combination)})
parameter_grids.append({'features': [build_preprocessor()], 'classifier': [DummyClassifier(strategy='most_frequent')]})
candidate_descriptions.append({'candidate': f'C{len(candidate_descriptions):03d}', 'path': 'Direct TF-IDF',
    'family': 'Most frequent', 'normalization': 'None', 'experiment': 'Main comparison', 'parameters': '{}'})
assert len(ParameterGrid(parameter_grids)) == len(candidate_descriptions)

temporary_cache = tempfile.TemporaryDirectory()
model_pipeline = Pipeline([('features', build_preprocessor()), ('classifier', logistic_model)],
                          memory=joblib.Memory(temporary_cache.name, verbose=0))
search = GridSearchCV(model_pipeline, parameter_grids, cv=validation_splits, n_jobs=1,
    scoring={'macro_f1': make_scorer(f1_score, average='macro', pos_label=None, zero_division=0), 'accuracy': 'accuracy'},
    refit='macro_f1', return_train_score=False, error_score='raise', verbose=1)
print('Candidates:', len(ParameterGrid(parameter_grids)), '| Folds:', len(validation_splits), flush=True)
search_started = time.perf_counter()
with warnings.catch_warnings(record=True) as training_warnings:
    warnings.simplefilter('always')
    search.fit(training_features, training_codes)
search_seconds = time.perf_counter() - search_started
warning_summary = pd.Series([str(warning.message) for warning in training_warnings], dtype=str).value_counts()
print('Search seconds:', round(search_seconds, 1), '| Recorded warnings:', len(training_warnings))
display(warning_summary.rename_axis('warning').reset_index(name='count'))
''')

markdown('''
### תרשימים משותפים מציגים תוצאה, שונות ועלות
כדי להשוות את שתי דרכי הייצוג ואת כל המשפחות באותו מבט, מפת החום מציגה את הפרמטר הטוב ביותר שנבדק לכל זוג מסלול–משפחה. כל יתר המועמדים נשארים בטבלה, והציונים בכל קפל נשמרים בקובץ. לצד ההשוואה מופיעים סטיית התקן בין הקפלים וזמן ההתאמה; זו שונות בין קפלים, לא רווח סמך.

הבחירה מבוססת על ולידציית האימון בלבד. בשוויון מדויק משתמשים בסדר המועמדים שהוגדר מראש. אזהרות התכנסות, אם הופיעו, מוצגות יחד עם תוצאות הריצה; הן אינן הוכחה שהמועמד הגיע לפתרון מיטבי.
''')
code('''
search_results = pd.DataFrame(search.cv_results_)
candidate_results = pd.concat([pd.DataFrame(candidate_descriptions), search_results[[
    'mean_test_macro_f1', 'std_test_macro_f1', 'mean_test_accuracy', 'mean_fit_time', 'rank_test_macro_f1']]], axis=1)
selected_candidate = candidate_results.iloc[search.best_index_]['candidate']
fold_scores = pd.concat([candidate_results[['candidate']], search_results.filter(regex=r'^split\\d+_test_')], axis=1)
with pd.option_context('display.max_rows', None):
    display(candidate_results.round(4))
print('Selected before test prediction:', selected_candidate)
main_results = candidate_results.query('experiment == "Main comparison" and family != "Most frequent"')
best_pairs = main_results.sort_values('mean_test_macro_f1', ascending=False, kind='stable').drop_duplicates(['path', 'family'])
comparison_matrix = best_pairs.pivot(index='path', columns='family', values='mean_test_macro_f1')
figure, axes = plt.subplots(1, 2, figsize=(17, 6), gridspec_kw={'width_ratios': [1.5, 1]})
heatmap = axes[0].imshow(comparison_matrix, vmin=0, vmax=1, cmap='YlGnBu', aspect='auto')
axes[0].set_xticks(range(len(comparison_matrix.columns)), comparison_matrix.columns, rotation=25, ha='right')
axes[0].set_yticks(range(len(comparison_matrix)), comparison_matrix.index)
for row_number in range(len(comparison_matrix)):
    for column_number in range(len(comparison_matrix.columns)):
        value = comparison_matrix.iloc[row_number, column_number]
        axes[0].text(column_number, row_number, f'{value:.3f}', ha='center', va='center',
                     color='white' if value > 0.55 else '#142b3e')
axes[0].set_title('Two paths × ten model families: mean validation macro-F1')
normalization_comparison = main_results.query('path == "Direct TF-IDF"').groupby(['family', 'normalization']).mean_test_macro_f1.max().unstack()
normalization_comparison.plot.barh(ax=axes[1], color=['#147d92', '#bea15a'])
axes[1].set(xlim=(0, 1), xlabel='Best tested mean macro-F1', ylabel='', title='Direct TF-IDF: raw weights versus L2')
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'all_models_and_paths.png', dpi=160)
plt.show()

best_families = main_results.sort_values('mean_test_macro_f1', ascending=False, kind='stable').drop_duplicates('family')
figure, axes = plt.subplots(1, 2, figsize=(13, 6))
axes[0].barh(best_families.family, best_families.mean_test_macro_f1,
    xerr=best_families.std_test_macro_f1, color='#147d92', capsize=3)
axes[0].set(xlabel='Mean macro-F1 ± fold standard deviation', title='Best tested candidate per family', xlim=(0, 1))
axes[1].barh(best_families.family, best_families.mean_fit_time, color='#bea15a')
axes[1].set(xlabel='Mean seconds per fit (this run)', title='Fitting cost, with shared preprocessing cache')
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'model_quality_and_cost.png', dpi=160)
plt.show()
display(best_pairs[['path', 'family', 'normalization', 'parameters', 'mean_test_macro_f1']].round(4))
''')

markdown('''
## 12. תחזיות הבדיקה מחברות את ההשוואה לרשומות עצמן
כדי להראות מה כל בחירה משנה בפועל, מאמנים את המועמד שנבחר ב-CV לכל משפחה ולכל מסלול על אותו חלק אימון ומפיקים תחזיות לאותן רשומות בדיקה. הזוכה בכל מסלול והזוכה הכולל נקבעים מראש לפי הוולידציה. לא מחליפים אותם לפי תוצאות הבדיקה. נשמרות כל התחזיות, ובמחברת מוצגת במלואה טבלת הזוכה הכולל.

Accuracy ו-macro-F1 מודדים כאן התאמה לסימול הידני שבקובץ, ולא אמת מקצועית. מחלקות שלא הופיעו באימון נשארות במכנה. Top-3 מדגים עזרה אפשרית לסמלן ואינו שקול לסימול מלא נכון. ציוני ההסתברות אינם מכוילים, ולכן אין מהם סף אוטומציה מוסמך.
''')
code('''
test_result_records, test_prediction_records = [], []
test_candidate_indices = sorted(set(best_pairs.index) | {search.best_index_, len(candidate_results) - 1})
for candidate_index in test_candidate_indices:
    candidate = candidate_results.iloc[candidate_index].candidate
    parameters = search_results.params.iloc[candidate_index]
    fitted_candidate = clone(model_pipeline).set_params(**parameters).fit(training_features, training_codes)
    predicted_codes = np.asarray(fitted_candidate.predict(test_features)).ravel()
    test_result_records.append({'candidate': candidate, 'accuracy': accuracy_score(test_codes, predicted_codes),
        'macro_f1': f1_score(test_codes, predicted_codes, average='macro', zero_division=0)})
    test_prediction_records.extend({'candidate': candidate, 'ID': int(labeled_record_ids.iloc[position]),
        'source_code': source_code, 'predicted_code': predicted_code, 'seen_in_training': source_code in set(training_codes)}
        for position, source_code, predicted_code in zip(test_positions, test_codes, predicted_codes))
test_results = candidate_results.merge(pd.DataFrame(test_result_records), on='candidate', validate='one_to_one')
all_test_predictions = pd.DataFrame(test_prediction_records)
best_path_candidates = main_results.sort_values('mean_test_macro_f1', ascending=False, kind='stable').drop_duplicates('path')
path_comparison = test_results.loc[test_results.candidate.isin(best_path_candidates.candidate)].copy()
display(path_comparison[['path', 'family', 'normalization', 'mean_test_macro_f1', 'accuracy', 'macro_f1']].round(4))

selected_test_predictions = all_test_predictions.query('candidate == @selected_candidate').copy()
test_probabilities = search.best_estimator_.predict_proba(test_features)
test_top_three = search.best_estimator_.classes_[np.argsort(-test_probabilities, axis=1, kind='stable')[:, :3]]
selected_test_predictions['top_three'] = [', '.join(codes) for codes in test_top_three]
selected_test_predictions['top_three_matches_source'] = [code in suggestions for code, suggestions in zip(test_codes, test_top_three)]
selected_test_predictions['matches_source'] = selected_test_predictions.source_code.eq(selected_test_predictions.predicted_code)
with pd.option_context('display.max_rows', None):
    display(selected_test_predictions)
per_class_results = pd.DataFrame(classification_report(test_codes, selected_test_predictions.predicted_code,
    output_dict=True, zero_division=0)).T
display(per_class_results)
error_context = survey_records.set_index('ID').loc[selected_test_predictions.loc[
    ~selected_test_predictions.matches_source, 'ID'], ['EzoAvoda', 'TeurPeula', 'TeurTafkid', TARGET_FIELD]]
display(error_context.join(selected_test_predictions.set_index('ID')[['predicted_code', 'seen_in_training']]))

figure, axes = plt.subplots(1, 2, figsize=(13, 4))
path_comparison.set_index('path')[['accuracy', 'macro_f1']].plot.bar(ax=axes[0], rot=0, color=['#147d92', '#bea15a'])
axes[0].set(ylim=(0, 1), ylabel='Agreement with synthetic source labels', xlabel='', title='Two paths: candidates chosen using training only')
error_breakdown = selected_test_predictions.groupby(['seen_in_training', 'matches_source']).size().unstack(fill_value=0).reindex(columns=[False, True], fill_value=0)
error_breakdown.plot.bar(stacked=True, ax=axes[1], rot=0, color=['#c45b4d', '#147d92'])
axes[1].set(xlabel='Source code present in training', ylabel='Test records', title='Selected model: disagreements and label coverage')
axes[1].legend(['Disagrees', 'Agrees'], frameon=False)
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'two_paths_test_results.png', dpi=160)
plt.show()
''')

markdown('''
## 13. בדיקת החלוקה מסבירה מה יכול לנפח ציון
כדי לבדוק את משמעות התיאורים החוזרים, משווים חלוקה אקראית לפי שורה לחלוקה לפי קבוצות תיאור, עם אותו מסווג ליניארי ואותו TF-IDF גולמי. זהו ניסוי אבחוני קבוע שאינו משתתף בבחירת המודל. סופרים גם חפיפת תיאורים ומחלקות שלא נראו באימון.

הפלט מאפשר לזהות עד כמה חלוקה לפי שורות מקלה על המשימה. ההפרש בציונים אינו אומדן סיבתי טהור של זליגה: גם כיסוי המקצועות והרכב הקפלים משתנים. אין כאן הוכחה שהרשומות החוזרות הן שידורים של אותו אדם.
''')
code('''
split_comparison_records = []
for split_name, splitter in [
    ('Random rows', KFold(n_splits=10, shuffle=True, random_state=RANDOM_SEED)),
    ('Description groups', GroupKFold(n_splits=10, shuffle=True, random_state=RANDOM_SEED))]:
    partitions = list(splitter.split(labeled_inputs, occupation_codes, labeled_groups))
    reference_model = Pipeline([('features', build_preprocessor()), ('classifier', clone(logistic_model))])
    predictions = cross_val_predict(reference_model, labeled_inputs, occupation_codes, cv=partitions, n_jobs=1)
    overlapping_records = sum(labeled_groups.iloc[validation].isin(labeled_groups.iloc[training]).sum()
                              for training, validation in partitions)
    unseen_records = sum((~occupation_codes.iloc[validation].isin(occupation_codes.iloc[training])).sum()
                         for training, validation in partitions)
    split_comparison_records.append({'split': split_name, 'accuracy': accuracy_score(occupation_codes, predictions),
        'macro_f1': f1_score(occupation_codes, predictions, average='macro', zero_division=0),
        'records_with_description_overlap': int(overlapping_records), 'records_with_unseen_labels': int(unseen_records)})
split_comparison = pd.DataFrame(split_comparison_records)
display(split_comparison)
figure, axes = plt.subplots(1, 2, figsize=(12, 3.8))
split_comparison.set_index('split')[['accuracy', 'macro_f1']].plot.bar(ax=axes[0], rot=0, color=['#147d92', '#bea15a'])
axes[0].set(ylim=(0, 1), xlabel='', ylabel='Pooled out-of-fold score', title='Same fixed model, different split assumptions')
split_comparison.set_index('split')[['records_with_description_overlap', 'records_with_unseen_labels']].plot.bar(
    ax=axes[1], rot=0, color=['#c45b4d', '#8666ac'])
axes[1].set(xlabel='', ylabel='Records', title='Why these evaluations differ')
axes[1].legend(['Description overlap', 'Unseen source code'], frameon=False)
figure.tight_layout()
figure.savefig(OUTPUT_DIRECTORY / 'split_sensitivity.png', dpi=160)
plt.show()
''')

markdown('''
## 14. אימון סופי והצעות לרשומות עם סימול חלקי
כדי להפיק את תוצר המשימה לאחר ההשוואה, מאמנים את המפרט שנבחר על כל 191 הרשומות בעלות קוד מלא. תשע הרשומות עם `X` אינן תוויות אימון מלאות, ולכן מקבלות הצעות נפרדות. הספרות הידועות בקוד החלקי אינן מאפייני חיזוי; הן משמשות רק להצגת הצעה נוספת התואמת אותן, אם קיימת מחלקת אימון מתאימה.

הפלט שומר את הקוד המקורי, התחזית, שלוש הצעות ודגל לחוסר תיאור ענייני. התאמה לספרות הידועות אינה אישור מקצועי, והצעה בהיעדר תיאור אינה מקבלת סמכות אוטומטית. כל הרשומות האלה מועברות לבדיקה אנושית. גם הקודים המלאים אינם "אמת נקייה"; לא מתקנים אותם על פי תחזית המודל.
''')
code('''
final_model = clone(search.best_estimator_).set_params(memory=None).fit(labeled_inputs, occupation_codes)
partial_records = survey_records.loc[partial_labels]
partial_inputs = model_inputs.loc[partial_labels]
partial_probabilities = final_model.predict_proba(partial_inputs)
partial_codes = np.asarray(final_model.predict(partial_inputs)).ravel()
trained_codes = final_model.classes_
partial_prediction_records = []
for record, probabilities, predicted_code in zip(partial_records.itertuples(), partial_probabilities, partial_codes):
    original_code = getattr(record, TARGET_FIELD)
    ordered_classes = np.argsort(-probabilities, kind='stable')
    compatible_classes = np.array([all(original == 'X' or original == proposed
        for original, proposed in zip(original_code, code)) for code in trained_codes])
    compatible_order = ordered_classes[compatible_classes[ordered_classes]]
    partial_prediction_records.append({'ID': record.ID, 'original_partial_code': original_code,
        'predicted_code': predicted_code, 'top_three': ', '.join(trained_codes[ordered_classes[:3]]),
        'maximum_uncalibrated_probability': float(probabilities.max()),
        'digit_compatible_suggestion': trained_codes[compatible_order[0]] if len(compatible_order) else None,
        'compatible_training_classes': int(compatible_classes.sum()),
        'no_substantive_description': not bool(has_description.loc[record.Index]), 'action': 'human_review'})
partial_predictions = pd.DataFrame(partial_prediction_records)
display(partial_predictions)
assert len(partial_predictions) == 9 and set(trained_codes) == set(occupation_codes)
assert np.isfinite(partial_probabilities).all() and np.allclose(partial_probabilities.sum(axis=1), 1)
''')

markdown('''
### רשומה חדשה מדגימה שימוש באנסמבל שנבחר ב-CV
כדי להראות את הממשק עבור סקר חדש, בוחרים את מועמד האנסמבל הטוב ביותר בוולידציה ומאמנים את המפרט שלו על הקודים המלאים. מפיקים פעם אחת הצעה לרשומה חדשה שנכתבה לצורך ההדגמה. אין לה קוד אמת, ולכן אין מדד דיוק. אין שימוש בקוד ענף סופי, במזהה או בתווית בזמן החיזוי. שאר בדיקות הקצה בתא הבא בודקות תקינות קלט בלבד.
''')
code('''
best_ensemble_index = main_results.loc[main_results.family.eq('Soft voting (5)'), 'mean_test_macro_f1'].idxmax()
final_ensemble = clone(model_pipeline).set_params(**search_results.params.iloc[best_ensemble_index])
final_ensemble.set_params(memory=None).fit(labeled_inputs, occupation_codes)
new_record = pd.DataFrame([{field: None for field in INPUT_FIELDS}])
new_record.loc[0, ['YeshuvAvoda', 'ShemAvoda', 'SugAvoda', 'EzoAvoda', 'TeurPeula', 'TeurTafkid']] = [
    'חיפה', 'חברת תוכנה חדשה', 'פיתוח תוכנה', 'מפתחת תוכנה', 'כתיבת קוד ובדיקת תוכנה', 'מפתחת']
new_record.loc[0, ['MaamadAvoda', 'MakorSachar', 'TeudaGvoha', 'shnotlimud', 'Gil', 'TarichHathala']] = [
    1, 1, 5, 16, 30, '2024-01-01']
new_probabilities = final_ensemble.predict_proba(prepare_model_inputs(new_record))[0]
new_order = np.argsort(-new_probabilities, kind='stable')[:3]
new_instance_prediction = pd.DataFrame({'rank': [1, 2, 3],
    'suggested_code': final_ensemble.classes_[new_order], 'uncalibrated_probability': new_probabilities[new_order]})
display(new_record)
display(new_instance_prediction)
print('Five-model ensemble configuration:', candidate_results.iloc[best_ensemble_index].to_dict())
''')

markdown('''
## 15. בדיקות שימוש ותוצרים שניתן לשחזר
כדי לוודא שהפתרון מתמודד עם סוגי הקלט שהמטלה מתירה, בודקים חיזוי עם תשובות חסרות, קטגוריה חדשה, קוד לא תקין, תאריך לא ניתן לפענוח וטקסט שלא נצפה. זו בדיקת תקינות, לא הוכחת איכות חיזוי. פונקציית ההכנה זהה באימון ובשימוש.

לאחר מכן שומרים את כל הטבלאות, שתי מטריצות ההמחשה עם שמות המאפיינים ומזהי השורות, ואת מפרט ההרצה. המודל השמור משמש לשחזור בתוך סביבת המחברת שבה מוגדר המתאם; הוא אינו חבילת ייצור עצמאית. אין לטעון קובץ joblib ממקור לא מוכר. הפלט מאפשר לבודק להתחקות אחר כל מספר וכל תחזית, ללא קבצים היסטוריים או תוצאות מוטמעות מראש.
''')
code('''
probe_records = survey_records.head(3).copy()
probe_records.loc[probe_records.index[0], INPUT_FIELDS] = np.nan
probe_records.loc[probe_records.index[1], 'MenahelEtMi'] = 99
probe_records.loc[probe_records.index[1], 'YeshuvAvoda'] = 'יישוב שלא הופיע באימון'
probe_records.loc[probe_records.index[2], 'TarichHathala'] = 'not a date'
probe_records.loc[probe_records.index[2], TEXT_FIELDS] = 'unseenwordxyz'
for preparation in [build_preprocessor(), build_preprocessor('Cluster one-hot')]:
    preparation.fit(prepare_model_inputs(probe_records.iloc[[0]]))
    assert np.isfinite(preparation.transform(prepare_model_inputs(probe_records))).all()
probe_predictions = final_model.predict(prepare_model_inputs(probe_records))
assert len(probe_predictions) == 3
joblib.dump(final_model, OUTPUT_DIRECTORY / 'occupation_model.joblib')
restored_model = joblib.load(OUTPUT_DIRECTORY / 'occupation_model.joblib')
assert np.array_equal(np.asarray(restored_model.predict(partial_inputs)).ravel(), partial_codes)
assert hashlib.sha256(source_bytes).hexdigest() == SOURCE_SHA256

result_tables = {'column_overview': column_overview.reset_index(), 'source_issues': source_issues,
    'all_source_values': all_value_counts, 'data_quality_counts': data_quality_counts.reset_index(),
    'class_support': class_support.reset_index(), 'fold_overview': fold_overview,
    'representation_overview': representation_overview, 'all_cluster_counts': cluster_search_results,
    'cluster_memberships': pd.DataFrame(cluster_memberships).drop_duplicates(),
    'all_candidate_results': candidate_results, 'all_candidate_fold_scores': fold_scores,
    'all_test_results': test_results, 'all_test_predictions': all_test_predictions,
    'selected_test_predictions': selected_test_predictions, 'per_class_results': per_class_results.reset_index(),
    'two_path_comparison': path_comparison, 'split_comparison': split_comparison, 'partial_predictions': partial_predictions, 'new_instance_prediction': new_instance_prediction}
for name, table in result_tables.items():
    table.to_csv(OUTPUT_DIRECTORY / f'{name}.csv', index=False, encoding='utf-8-sig')
raw_tfidf_sample.to_csv(OUTPUT_DIRECTORY / 'raw_tfidf_displayed_terms.csv', index=False)
onehot_sample.to_csv(OUTPUT_DIRECTORY / 'cluster_onehot_text_features.csv', index=False)
from scipy.sparse import csr_matrix, save_npz
for name, matrix in [('direct_tfidf', direct_matrix), ('cluster_onehot', cluster_matrix)]:
    save_npz(OUTPUT_DIRECTORY / f'{name}_training_matrix.npz', csr_matrix(matrix))
pd.DataFrame({'ID': labeled_record_ids.iloc[training_positions].to_numpy()}).to_csv(
    OUTPUT_DIRECTORY / 'training_matrix_rows.csv', index=False)
matrix_columns = {
    'direct_tfidf': direct_preview.get_feature_names_out().tolist(),
    'cluster_onehot': [field + '__' + name for field in TEXT_FIELDS
        for name in cluster_preview.named_transformers_[field].named_steps['onehot'].get_feature_names_out(['group'])]
        + ['categories__' + name for name in cluster_preview.named_transformers_['categories'].get_feature_names_out(CATEGORY_FIELDS)]
        + ['numbers__' + name for name in cluster_preview.named_transformers_['numbers'].get_feature_names_out(NUMBER_FIELDS)]}
assert len(matrix_columns['cluster_onehot']) == cluster_matrix.shape[1]
(OUTPUT_DIRECTORY / 'training_matrix_columns.json').write_text(json.dumps(matrix_columns, ensure_ascii=False, indent=2))
run_manifest = {'source_sha256': SOURCE_SHA256, 'seed': RANDOM_SEED, 'python': sys.version.split()[0],
    'sklearn': sklearn.__version__, 'pandas': pd.__version__, 'numpy': np.__version__,
    'external_models': {package: importlib.metadata.version(package) for package in ['xgboost', 'lightgbm', 'catboost']},
    'survey_records': len(survey_records), 'complete_labels': len(occupation_codes), 'partial_labels': len(partial_predictions),
    'training_records': len(training_features), 'test_records': len(test_features), 'folds': len(validation_splits),
    'candidate_count': len(candidate_results), 'selected_candidate': selected_candidate,
    'selected_configuration': candidate_results.iloc[search.best_index_].to_dict(),
    'training_warnings': warning_summary.to_dict(), 'search_seconds': search_seconds,
    'total_seconds': time.perf_counter() - run_started, 'actual_colab_session_tested': False,
    'smoothing': False, 'kmeans_normalization': 'l2', 'kmeans_uses_target_labels': False,
    'description_groups_are_participant_ids': False, 'probabilities_are_calibrated': False,
    'test_is_independent_production_evidence': False}
(OUTPUT_DIRECTORY / 'run_manifest.json').write_text(json.dumps(run_manifest, ensure_ascii=False, indent=2))
print('Checks passed. Saved', len(result_tables), 'result tables, matrices, figures and model.')
print('Total execution seconds:', round(run_manifest['total_seconds'], 1))
''')

markdown('''
## 16. תובנות והמשך הטמעה
כדי לבחור צעד המשך שמבוסס על מה שנלמד, מפרידים בין תקינות התהליך, תוצאות המדגם והבטחת איכות תפעולית. התא הבא מסכם מספרים שחושבו בהרצה, כולל שני המסלולים והבחירה. הישג תפעולי יימדד בהפחתת זמן סימול ובשיעור טעויות מאומת, ולא בציון גבוה על הסימולציה.

מגבלות הנתונים מכוונות את סדר העבודה הבא: לתעד מזהה נסקר ושידור, חותמת זמן ומזהה סמלן; לאמת את ממשק השאלון ואת זמינות קוד הענף; להכין מדגם אמת בבדיקה כפולה ובהכרעת מומחה; להעריך לפי נסקר וזמן; ורק אז לכייל ציונים ולבחור יחס בין כיסוי אוטומטי לטעויות. בתחילת ההטמעה המודל יפעל לצד הסמלנים עם רישום תיקונים, סיבות אי־סימול וניטור חסרים, מקצועות חדשים ושינויי התפלגות.

ההשוואה בין המסלולים בודקת אם grouping שימושי למשימת הסיווג. ציון CH גבוה אינו מוכיח זאת, וייתכן שהאופטימיזציה תיצור כמעט קבוצה לכל ניסוח. באותו אופן, שיפור של מודל מורכב על המדגם אינו מוכיח שהוא מצדיק עלות או סיכון בהטמעה.
''')
code('''
chosen_result = test_results.loc[test_results.candidate.eq(selected_candidate)].iloc[0]
conclusions = pd.DataFrame([
    ['נתונים', f'{len(survey_records)} רשומות; {len(field_definitions)} שדות; {complete_labels.sum()} קודים מלאים ו-{partial_labels.sum()} חלקיים'],
    ['כיסוי מקצועות', f'{len(class_support)} מחלקות; {class_support.records.eq(1).sum()} מחלקות עם רשומה אחת; {class_support.groups.eq(1).sum()} עם קבוצת תיאור אחת'],
    ['בחירה לפי אימון', f'{selected_candidate}: {chosen_result["path"]}, {chosen_result["family"]}, normalization={chosen_result["normalization"]}'],
    ['בדיקה תיאורית', f'accuracy={chosen_result.accuracy:.3f}, macro-F1={chosen_result.macro_f1:.3f}; {len(test_features)} רשומות'],
    ['פעולה', 'כל תשע הרשומות החלקיות מקבלות הצעה לבדיקה אנושית; לא נקבע סף אוטומציה מהסימולציה.']
], columns=['נושא', 'מסקנה'])
display(conclusions)
display(path_comparison[['path', 'family', 'normalization', 'accuracy', 'macro_f1']].round(4))
''')

markdown('''
## מקורות והקשר העבודה
כדי לאפשר בדיקה של ההחלטות, הרשימה מחברת בין חומר המקור, תיעוד ה-API ועקרונות ההערכה. המטלה וה-Metadata מגדירים את המשמעות העסקית; התיעוד מגדיר את התנהגות הספריות. המחקרים מסבירים מדוע הפרדת נתונים ובחירת מודל דורשות זהירות, ואינם מקור לטענות על תוכן הקובץ הסינתטי.

- [תיקיית Assignment ב-Drive](https://drive.google.com/drive/folders/1XMeO2TSCBxGl2HXWhOMCbBH9XqVUOL5g): מסמך המטלה וקובץ `DUMMY_DATASET.xlsx`, שני הגיליונות. טביעת הקובץ מופיעה בתחילת המחברת.
- [scikit-learn: TF-IDF](https://scikit-learn.org/1.8/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html): smoothing, נרמול ואוצר מילים.
- [KMeans](https://scikit-learn.org/1.8/modules/generated/sklearn.cluster.KMeans.html) ו-[Calinski–Harabasz](https://scikit-learn.org/1.8/modules/generated/sklearn.metrics.calinski_harabasz_score.html): clustering וקריטריון יחס הפיזורים.
- [OneHotEncoder](https://scikit-learn.org/1.8/modules/generated/sklearn.preprocessing.OneHotEncoder.html), [Pipeline](https://scikit-learn.org/1.8/modules/generated/sklearn.pipeline.Pipeline.html), [GroupKFold](https://scikit-learn.org/1.8/modules/generated/sklearn.model_selection.GroupKFold.html): קידוד קטגוריות והתאמת עיבוד בתוך האימון.
- [GridSearchCV](https://scikit-learn.org/1.8/modules/generated/sklearn.model_selection.GridSearchCV.html), [VotingClassifier](https://scikit-learn.org/1.8/modules/generated/sklearn.ensemble.VotingClassifier.html), [MLPClassifier](https://scikit-learn.org/1.8/modules/generated/sklearn.neural_network.MLPClassifier.html): השוואה, הצבעה ורשת קטנה.
- [XGBoost parameters](https://xgboost.readthedocs.io/en/release_3.0.0/parameter.html), [LightGBM API](https://lightgbm.readthedocs.io/en/v4.6.0/pythonapi/lightgbm.LGBMClassifier.html), [CatBoost tuning](https://catboost.ai/docs/en/concepts/parameter-tuning): משמעות פרמטרי מורכבות ותנאי פיצול.
- [המאמר שסופק על בדיקת אשכולות](https://medium.com/@kavengik/internal-clustering-validation-with-scikit-learn-four-ways-part-1-5d94410be79b): הקשר לבחירת K. המימוש נבדק מול תיעוד scikit-learn.
- [Common pitfalls](https://scikit-learn.org/1.8/common_pitfalls.html) ו-[Nested versus non-nested CV](https://scikit-learn.org/1.8/auto_examples/model_selection/plot_nested_cross_validation_iris.html): מניעת זליגה והטיית בחירה.
- [Cawley & Talbot, JMLR 2010](https://jmlr.org/papers/v11/cawley10a.html): התאמת יתר בקריטריון בחירת מודל.
- [Kapoor & Narayanan, 2022](https://arxiv.org/abs/2207.07048): זליגת מידע ומגבלות שחזור במחקרי למידת מכונה.

כל קובצי ה-ipynb וה-py שהיו תחת `project_notebooks` בעת האיסוף נכללו במפת המקורות: תשע מחברות ושני קובצי Python, ששניהם עותקים של אותו קוד. הגרסאות שימשו להבנת היקף העבודה המצטבר; אין תלות בתוצאותיהן או הרצה של תאים ממחברת אחרת. המחברת בנושא arXiv נקראה כחלק מהאיסוף, ותוכנה אינו נתוני סקר. [Ensembles](https://github.com/OrShulrufer/Ensembles) נקרא להבנת רמת העבודה וההקשר, ולא כמקור להעתקת מימוש. רשימת הקבצים והטביעות נשמרת ב-`source_inventory.json` לצד ההגשה.
''')

revision = subprocess.check_output(['git', '-C', str(REPOSITORY), 'rev-parse', 'HEAD'], text=True).strip()
inventory = []
for source_path in sorted((REPOSITORY / 'project_notebooks').rglob('*')):
    if source_path.suffix not in {'.ipynb', '.py'} or source_path.name == 'survey_complete.ipynb':
        continue
    content = source_path.read_bytes()
    inventory.append({'path': str(source_path.relative_to(REPOSITORY)), 'bytes': len(content),
                      'sha256': hashlib.sha256(content).hexdigest()})
DESTINATION.mkdir(exist_ok=True)
(DESTINATION / 'source_inventory.json').write_text(json.dumps({'revision': revision, 'files': inventory}, indent=2))
for index, cell in enumerate(cells):
    cell['id'] = f'survey-{index:03d}'
    cell['source'] = cell['source'].splitlines(keepends=True)
notebook = dict(nbformat=4, nbformat_minor=5, cells=cells, metadata={
    'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'},
    'language_info': {'name': 'python', 'version': '3.11'},
    'colab': {'provenance': [], 'name': 'survey_complete.ipynb'}})
notebook_path = DESTINATION / 'survey_complete.ipynb'
notebook_path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1))
print(notebook_path)
print('Cells:', len(cells), '| Code lines:', sum(len(cell['source']) for cell in cells if cell['cell_type'] == 'code'))

from pathlib import Path
import os, json, hashlib, shutil
import nbformat,joblib,pandas as pd
from IPython.terminal.interactiveshell import TerminalInteractiveShell
from IPython.utils.capture import capture_output
root=Path('/workspace/scratch/14b0f58f673c')
notebook=nbformat.read(root/'repo/project_notebooks/survey/survey_complete.ipynb',4)
old_results=pd.read_csv(root/'repo/project_notebooks/survey/survey_results/all_candidate_results.csv',keep_default_na=False)
old_directory=max((root/'fit_checkpoints').iterdir(),key=lambda p:len(list(p.glob('*.json'))))
new_hash=hashlib.sha256('\n'.join(c.source for c in notebook.cells if c.cell_type=='code').encode()).hexdigest()[:16]
new_directory=root/'fit_checkpoints'/new_hash
new_directory.mkdir(exist_ok=True)
os.chdir(root/'repo/project_notebooks/survey')
shell=TerminalInteractiveShell.instance()
with capture_output():
 for index in (3,5,7,9,13,15,17,20):
  result=shell.run_cell(notebook.cells[index].source)
  assert not (result.error_before_exec or result.error_in_exec)
 grid_source=next(c.source for c in notebook.cells if c.cell_type=='code' and c.source.startswith('from sklearn.model_selection import ParameterGrid'))
 result=shell.run_cell(grid_source.split('temporary_cache =')[0])
 assert not (result.error_before_exec or result.error_in_exec)
new_descriptions=shell.user_ns['candidate_descriptions']
new_grids=list(shell.user_ns['ParameterGrid'](shell.user_ns['parameter_grids']))
old_search=joblib.load(root/'cv_checkpoint.joblib')
def canonical(value):
 if hasattr(value,'get_params'):return {'class':type(value).__module__+'.'+type(value).__qualname__,'parameters':canonical(value.get_params(deep=False))}
 if isinstance(value,dict):return {k:canonical(v) for k,v in value.items()}
 if isinstance(value,(tuple,list)):return [canonical(v) for v in value]
 if isinstance(value,(str,int,float,bool)) or value is None:return value
 return repr(value)
def key(record):return tuple(record[x] for x in ['path','family','normalization','parameters'])
new_indices={key(row):i for i,row in enumerate(new_descriptions)}
copied=0
for old_index,row in old_results.iterrows():
 if row.family=='Soft voting (5)':continue
 new_index=new_indices[key(row)]
 
 old_value=canonical(old_search.cv_results_['params'][old_index]);new_value=canonical(new_grids[new_index])
 if old_value!=new_value:
  (root/'canonical_old.json').write_text(json.dumps(old_value,ensure_ascii=False,indent=2))
  (root/'canonical_new.json').write_text(json.dumps(new_value,ensure_ascii=False,indent=2))
  raise AssertionError(row.family)
 for fold in range(10):
  shutil.copy2(old_directory/f'{old_index:03d}_{fold:02d}.json',new_directory/f'{new_index:03d}_{fold:02d}.json');copied+=1
if (old_directory/'preprocessing').exists():shutil.copytree(old_directory/'preprocessing',new_directory/'preprocessing',dirs_exist_ok=True)
(root/'new_candidate_descriptions.json').write_text(json.dumps(new_descriptions,ensure_ascii=False,indent=2))
assert len(new_descriptions)==172 and copied==1180
print('Retained',copied,'verified unchanged individual/baseline fits.')
print('Both ensembles will receive all',1720-copied,'fresh fits.')
print('Checkpoint directory:',new_directory)

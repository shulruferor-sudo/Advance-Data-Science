from pathlib import Path
import os, time, traceback, sys, hashlib
import nbformat
from IPython.terminal.interactiveshell import TerminalInteractiveShell
from IPython.utils.capture import capture_output
os.environ['MPLBACKEND'] = 'Agg'
notebook_path = Path('/workspace/scratch/14b0f58f673c/repo/project_notebooks/survey/survey_complete.ipynb')
notebook = nbformat.read(notebook_path, as_version=4)
nbformat.validate(notebook)
fingerprint = hashlib.sha256('\n'.join(cell.source for cell in notebook.cells if cell.cell_type == 'code').encode()).hexdigest()[:16]
checkpoint_directory = Path('/workspace/scratch/14b0f58f673c/fit_checkpoints') / fingerprint
checkpoint_directory.mkdir(parents=True, exist_ok=True)
os.environ['SURVEY_CHECKPOINT_DIRECTORY'] = str(checkpoint_directory)
from sklearn.model_selection import _search
from runtime_checkpoint import checkpoint_fit_and_score, initialize_worker
_search._fit_and_score = checkpoint_fit_and_score
print(f'Fit checkpoint directory: {checkpoint_directory}', flush=True)
os.chdir(notebook_path.parent)
shell = TerminalInteractiveShell.instance()
shell.user_ns['initialize_worker'] = initialize_worker
# matplotlib_inline registers the same rich figure formatter used by notebooks.
shell.run_cell("%matplotlib inline", store_history=False)
shell.display_formatter.active_types = ['text/plain', 'text/html', 'image/png']
shell.display_formatter.formatters['text/html'].enabled = True
class ProgressOutput:
    def __init__(self, output):
        self.output = output
    def write(self, value):
        if value.startswith('[CV]'):
            with open('/workspace/scratch/14b0f58f673c/cv_progress.log', 'a') as progress:
                progress.write(value + '\n')
        else:
            self.output.write(value)
        return len(value)
    def flush(self):
        self.output.flush()

started = time.perf_counter()
for index, cell in enumerate(notebook.cells):
    if cell.cell_type != 'code':
        continue
    print(f'Cell {index} started at {time.perf_counter()-started:.1f}s',flush=True)
    with capture_output() as captured:
        execution_source = cell.source.replace('joblib.Memory(temporary_cache.name, verbose=0)',
            f'joblib.Memory({str(checkpoint_directory / "preprocessing")!r}, verbose=0)')
        execution_source = execution_source.replace('with warnings.catch_warnings(record=True) as training_warnings:',
            "with joblib.parallel_backend('loky', inner_max_num_threads=1, initializer=initialize_worker, initargs=(TextGroups,)), warnings.catch_warnings(record=True) as training_warnings:")
        execution_source = execution_source.replace('    search.fit(training_features, training_codes)',
            '    search.n_jobs = 4\n'
            '    search.fit(training_features, training_codes)\n'
            f'    for saved_fit in Path({str(checkpoint_directory)!r}).glob("*.json"):\n'
            '        for warning_message in json.loads(saved_fit.read_text())["warnings"]:\n'
            '            warnings.warn(warning_message)')
        sys.stdout = ProgressOutput(sys.stdout)
        result = shell.run_cell(execution_source, store_history=True)
    cell.execution_count = shell.execution_count - 1
    cell.outputs = []
    if captured.stdout:
        cell.outputs.append(nbformat.v4.new_output('stream', name='stdout', text=captured.stdout))
    if captured.stderr:
        cell.outputs.append(nbformat.v4.new_output('stream', name='stderr', text=captured.stderr))
    for output in captured.outputs:
        cell.outputs.append(nbformat.v4.new_output('display_data', data=output.data, metadata=output.metadata))
    error = result.error_before_exec or result.error_in_exec
    if error:
        cell.outputs.append(nbformat.v4.new_output('error', ename=type(error).__name__, evalue=str(error), traceback=traceback.format_exception(error)))
    nbformat.write(notebook, notebook_path)
    if not error and 'search.fit(training_features, training_codes)' in cell.source:
        import joblib
        joblib.dump(shell.user_ns['search'], '/workspace/scratch/14b0f58f673c/cv_checkpoint.joblib')
        Path('/workspace/scratch/14b0f58f673c/cv_search_seconds.txt').write_text(str(shell.user_ns['search_seconds']))
    print(f'Cell {index} ended at {time.perf_counter()-started:.1f}s: {str(error) if error else "OK"}',flush=True)
    if error:
        print(captured.stdout[-10000:], captured.stderr[-5000:], flush=True)
        raise error
print(f'COMPLETE: {time.perf_counter()-started:.1f}s',flush=True)

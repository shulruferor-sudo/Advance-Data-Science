import {createRequire} from 'node:module';
const require=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/package.json');
const {Presentation,PresentationFile}=require('@oai/artifact-tool');
const {first}=await import('./build_deck.mjs');
const presentation=Presentation.create({slideSize:{width:1280,height:720}});
presentation.slides.add();
await first(presentation);
await (await PresentationFile.exportPptx(presentation)).save('/workspace/scratch/14b0f58f673c/deck_draft.pptx');
console.log('Exported four-slide draft');

from pathlib import Path
p=Path('assemble_submission.py');s=p.read_text()
s=s.replace('threadpool_limits(limits=2)','threadpool_limits(limits=1)')
s=s.replace("    records=('ID', 'size'), labels=(TARGET_FIELD, 'nunique'))\nconflicting_groups = group_summary.index[group_summary.labels.gt(1)]", "    records=('ID', 'size'))\ncomplete_code_counts = survey_records.loc[complete_labels].assign(\n    description_group=description_groups.loc[complete_labels]).groupby('description_group')[TARGET_FIELD].nunique()\ngroup_summary['distinct_complete_codes'] = complete_code_counts.reindex(group_summary.index, fill_value=0)\nconflicting_groups = group_summary.index[group_summary.distinct_complete_codes.gt(1)]")
s=s.replace('אין כאן הוכחה שהרשומות החוזרות הן שידורים של אותו אדם.', 'אין כאן הוכחה שהרשומות החוזרות הן שידורים של אותו אדם.')
s=s.replace('הקובץ אינו מוכיח איזו תווית נכונה.', 'הקובץ אינו מוכיח איזו תווית נכונה. לעומת זאת, `335X` ו-`3354` תואמים בספרות הידועות ואינם נספרים כסתירה בין קודים מלאים.')
start=s.index('candidate_parameters, candidate_descriptions = [], []')
end=s.index('temporary_cache =',start)
s=s[:start]+'''parameter_grids, candidate_descriptions = [], []
for path in ['Direct TF-IDF', 'Cluster one-hot']:
    for normalization in ([None, 'l2'] if path == 'Direct TF-IDF' else ['l2']):
        for family, (classifier, parameters) in model_families.items():
            parameter_grids.append({'features': [build_preprocessor(path, normalization)],
                                    'classifier': [classifier], **parameters})
            for combination in ParameterGrid(parameters):
                candidate_descriptions.append({'candidate': f'C{len(candidate_descriptions):03d}',
                    'path': path, 'family': family, 'normalization': normalization or 'None',
                    'experiment': 'Main comparison', 'parameters': json.dumps(combination)})
parameter_grids.append({'features': [build_preprocessor()], 'classifier': [DummyClassifier(strategy='most_frequent')]})
candidate_descriptions.append({'candidate': f'C{len(candidate_descriptions):03d}', 'path': 'Direct TF-IDF',
    'family': 'Most frequent', 'normalization': 'None', 'experiment': 'Main comparison', 'parameters': '{}'})
assert len(ParameterGrid(parameter_grids)) == len(candidate_descriptions)

'''+s[end:]
s=s.replace('GridSearchCV(model_pipeline, candidate_parameters','GridSearchCV(model_pipeline, parameter_grids')
s=s.replace("len(candidate_parameters), '| Folds:'", "len(ParameterGrid(parameter_grids)), '| Folds:'")
s=s.replace('אין early stopping על קבוצת הבדיקה.', 'אין early stopping על קבוצת הבדיקה. GridSearchCV מקבל את הרשתות עצמן ומחשב את המכפלה הקרטזית המלאה. ParameterGrid משמש רק לשמות ולתיעוד הצירופים באותו סדר.')
s=s.replace("pd.set_option('display.max_colwidth', 100)","pd.set_option('display.max_colwidth', 100)\npd.set_option('display.max_columns', None)")
s=s.replace("display(onehot_sample.head(8))", "display(onehot_sample.head(8))")
p.write_text(s)
p=Path('execute_inprocess.py');s=p.read_text()
s=s.replace("shell.run_cell(\"%matplotlib inline\", store_history=False)","shell.run_cell(\"%matplotlib inline\", store_history=False)\nshell.display_formatter.active_types = ['text/plain', 'text/html', 'image/png']\nshell.display_formatter.formatters['text/html'].enabled = True")
s=s.replace("    nbformat.write(notebook, notebook_path)","    nbformat.write(notebook, notebook_path)\n    if not error and 'search.fit(training_features, training_codes)' in cell.source:\n        import joblib\n        joblib.dump(shell.user_ns['search'], '/workspace/scratch/14b0f58f673c/cv_checkpoint.joblib')\n        Path('/workspace/scratch/14b0f58f673c/cv_search_seconds.txt').write_text(str(shell.user_ns['search_seconds']))")
p.write_text(s)

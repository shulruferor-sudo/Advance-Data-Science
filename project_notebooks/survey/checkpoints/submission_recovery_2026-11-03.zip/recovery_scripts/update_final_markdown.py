from pathlib import Path
import json
path=Path('repo/project_notebooks/survey/survey_complete.ipynb')
notebook=json.loads(path.read_text())
for cell in notebook['cells']:
 if cell['cell_type']!='markdown':continue
 source=''.join(cell['source'])
 source=source.replace('לפני K-means הנרמול תמיד מופעל.', 'לפני K-means הנרמול תמיד מופעל. נרמול אורך הווקטור אינו איזון של שכיחויות המקצועות.')
 source=source.replace('טקסט ללא מונח מוכר מקבל קטגוריית טקסט חדש, ולא קבוצה סמנטית מומצאת.', 'טקסט ללא מונח מוכר מקבל קטגוריית טקסט חדש, ולא קבוצה סמנטית מומצאת. מצב שלא הופיע באימון יקודד בווקטור אפסים על ידי OneHotEncoder עם handle_unknown="ignore".')
 source=source.replace('מסמך המטלה וקובץ `DUMMY_DATASET.xlsx`, שני הגיליונות.', '[מסמך המטלה](https://drive.google.com/file/d/1V1T1qcuGMP8FPj97RAq2XAXXK_uvY8DA/view) ו-[DUMMY_DATASET.xlsx](https://drive.google.com/file/d/1I2GQa7coT-ZPsSnLPNob0OizaBDiqN5r/view), שני הגיליונות.')
 cell['source']=source.splitlines(keepends=True)
path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1))

import fs from 'node:fs/promises';
import {base,text,table,chart,note,ink,teal,gold,paper,muted,source,notebook} from './build_deck.mjs';
export async function remaining(presentation) {
 const data=JSON.parse(await fs.readFile('/workspace/scratch/14b0f58f673c/slide_metrics.json','utf8'));
 let slide=base(presentation,4,'חזרות ומקצועות נדירים מגבילים את הבדיקה','כדי למדוד הכללה לתיאור חדש, אותו דפוס תיאור נשאר בצד אחד של כל חלוקה.');
 const supported=data.classes;const groupCounts=[1,2,3,4,5,6,7,8];
 chart(slide,groupCounts.map(n=>n===8?'8+':String(n)),[
 {name:'רשומות למקצוע',values:groupCounts.map(n=>supported.filter(x=>(n===8?x.records>=8:x.records===n)).length),fill:teal},
 {name:'קבוצות תיאור למקצוע',values:groupCounts.map(n=>supported.filter(x=>(n===8?x.groups>=8:x.groups===n)).length),fill:gold}
 ],{left:55,top:205,width:650,height:370},{direction:'column',format:'0',gap:60});
 text(slide,'support',`${supported.length} מקצועות\n${supported.filter(x=>x.records===1).length} עם רשומה אחת\n${supported.filter(x=>x.groups===1).length} עם קבוצת תיאור אחת`,745,219,475,150,29,ink,true);
 text(slide,'split','156 רשומות לאימון\n35 לבדיקה, מהן 7 בקוד שלא נצפה באימון\n10 קפלי GroupKFold בתוך האימון',745,405,475,140,27,muted);
 text(slide,'limits','בדיקה אבחונית: accuracy של 0.812 לפי שורה, 0.586 לפי קבוצת תיאור',60,617,1160,40,27,teal,true);
 note(slide,'התרשים מציג את מספר המקצועות לכל גודל תמיכה. מקצועות עם יותר משבע רשומות נכללים בקטגוריית 8+ בתרשים הסופי. החלוקה מבוססת על שישה שדות תיאור בלבד, ללא היעד או שם המעסיק. 11 חזרות מלאות מעבר לראשונה, ללא ID, אינן נמחקות. דוגמת מעבדה כוללת 3311 מול 3211 ללא דרך להכריע מי נכון. 335X ו-3354 מתאימים בספרות הידועות ואינם נספרים כסתירה מלאה. שבע הרשומות עם קוד שלא נצפה נשארות בהערכת הבדיקה. בהשוואה האבחונית לפי שורות accuracy היה 0.812 ובחלוקת קבוצות 0.586. בחלוקת השורות יש 115 רשומות עם חפיפת תיאורים. גם כיסוי המקצועות השתנה, ולכן ההפרש אינו השפעה סיבתית טהורה של החפיפה. קבוצת תיאור אינה מזהה נסקר וקוד מלא אינו אמת מאומתת.');
 slide=base(presentation,5,'שני מסלולי הכנה על אותם שדות','כדי לבדוק אם הקיבוץ שומר על הבחנות מקצועיות, משווים אותו ישירות למשקלי הטקסט.');
 table(slide,[['קבוצות ואז One-hot','TF-IDF ישיר','שיקול'],
 ['זהות קבוצה לכל שדה','משקל של כל מונח','מה נשמר'],
 ['ניסוחים חוזרים עם קרבה שימושית','מילים נדירות שמבדילות בין מקצועות','מתי עשוי להועיל'],
 ['מיזוג מקצועות או קבוצות רבות מדי','פיצול בגלל כתיב ומונחים חדשים','מגבלה אפשרית'],
 ['TF-IDF, נרמול L2, בחירת K וקידוד קבוצות','TF-IDF גולמי, וגם בדיקת L2','מה מבוצע'],
 ['חיפוש K מוגבל ושיוך באצוות','ייצוג דליל ומסווג שתומך בו','בתרחיש של נתונים רבים']
 ],205,396,[435,435,290],23);
 text(slide,'fit','כל העיבוד הנלמד מותאם מחדש בתוך קפל האימון',60,621,1160,40,28,teal,true);
 note(slide,'בשני המסלולים smooth_idf=False ו-TF רגיל. sklearn עדיין מוסיף 1 לאחר log(n/df). L2 מביא וקטורים לא אפסיים לנורמת יחידה ומאפשר קשר בין מכפלה פנימית לדמיון קוסינוס. במסלול הישיר נבדק אם אורך הטקסט מועיל. לפני KMeans L2 תמיד פעיל. חסר, אי-מסירה והפניה אינם משתתפים באשכולות התוכן ומקבלים קטגוריות נפרדות. גיל, שנות לימוד ושנת תחילת עבודה נשארים מספריים. שתי המטריצות מוצגות ונשמרות במחברת לפני השוואת המסווגים.',[source,notebook,'https://scikit-learn.org/1.8/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html']);
 slide=base(presentation,6,'בחירת קבוצות לפי יחס הפיזורים','כדי להעדיף קבוצות קומפקטיות ומופרדות, בוחרים את ציון Calinski-Harabasz הגבוה בין ערכי K שנבדקו.');
 const representations=data.representations;
 chart(slide,representations.map(x=>x.field).reverse(),[
 {name:'ממדי TF-IDF',values:representations.map(x=>x.raw_tfidf_dimensions).reverse(),fill:teal},
 {name:'קבוצות תוכן שנבחרו',values:representations.map(x=>x.content_clusters).reverse(),fill:gold},
 {name:'ממדי One-hot כולל מצבי חסר',values:representations.map(x=>x.onehot_dimensions).reverse(),fill:'#8666AC'}
 ],{left:50,top:204,width:1170,height:345},{format:'0',gap:70,labelSize:22});
 text(slide,'interpretation','המדד עשוי לבחור כמעט קבוצה לכל ניסוח.\nהתועלת לסיווג המקצוע נבחנת בנפרד, בוולידציה.',60,579,1160,76,27,ink,true);
 note(slide,'מוצגות קבוצות שנלמדו מ-156 רשומות אימון בלבד. CH הוא יחס פיזור בין קבוצות לפיזור בתוכן, עם תיקון למספר קבוצות ורשומות. לכל שדה נבדקים כל ערכי K בין 2 למספר הווקטורים השונים פחות 1, עם עשרה אתחולים של KMeans. לכל ניסוח שונה משקל אחד בבחירת הקבוצות כדי שחזרות סימולציה לא ישלטו בגאומטריה. IDF עצמו נלמד מכל שורות האימון. מקסימום CH הוא הטוב מבין המחיצות שנבדקו ואינו מבטיח אופטימום גלובלי או משמעות מקצועית. המטריצות המלאות הן 156x572 ו-156x359.',[notebook,'https://scikit-learn.org/1.8/modules/clustering.html#calinski-harabasz-index','https://scikit-learn.org/1.8/modules/generated/sklearn.cluster.KMeans.html']);
 slide=base(presentation,7,'השוואת כל המודלים בשני המסלולים','כדי לבדוק אילו הנחות מתאימות לנתונים, משווים את משפחות המודלים על אותם קפלים.');
 const families=[...new Set(data.candidates.filter(x=>x.family!=='Most frequent').map(x=>x.family))];
 const best=(path,family)=>Math.max(...data.candidates.filter(x=>x.path===path&&x.family===family).map(x=>x.mean_test_macro_f1));
 chart(slide,families.slice().reverse(),[
 {name:'Direct TF-IDF',values:families.map(f=>best('Direct TF-IDF',f)).reverse(),fill:teal},
 {name:'Cluster one-hot',values:families.map(f=>best('Cluster one-hot',f)).reverse(),fill:gold}
 ],{left:45,top:195,width:1175,height:390},{format:'0.00',max:1,labelSize:18,gap:70,labels:true});
 text(slide,'tuning',`${data.manifest.candidate_count} מועמדים כולל קו בסיס. בכל פרמטר: ברירת מחדל ושתי חלופות מנומקות.`,60,609,1160,38,23,ink);
 text(slide,'metric','CV macro-F1: שני מסלולי Complement NB כמעט זהים, 0.425 ו-0.424.',60,651,1160,28,19,muted);
 note(slide,'לכל מודל לכל היותר שני פרמטרי מסווג מכווננים, ולכל פרמטר שלושה ערכים, כולל ברירת המחדל. פירוט ערכים ונימוקים במחברת. במסלול הישיר None ו-L2 נבדקים בנוסף. ההצבעה הרכה כוללת LogisticRegression, RandomForest, XGBoost, SVC ו-MLP. מפרטי הרכיבים קבועים מראש והמשקלים נבחרים ב-CV. הרשת נבדקת ב-MLPClassifier; TensorFlow, PyTorch, H2O ו-Spark לא הורצו כי מדובר במימושים חוזרים של המשפחות לצורך המדגם הזה. משפחות שונות עשויות להשלים טעויות שונות, אך מספר הרכיבים אינו מבטיח שיפור. סטיות תקן ועלויות התאמה מופיעות בתרשים המאוחד במחברת. זמן ההתאמה נמדד בהרצה המקומית עם מקביליות ו-cache, ואינו benchmark מבודד או תחזית למיליון רשומות. הציון לאחר בחירה אינו אומדן נטול הטיית בחירה. שני המסלולים של Complement NB כמעט זהים ב-CV, לעומת סטיית תקן של כ-0.22 בין הקפלים. אין מכאן הוכחה לעדיפות יציבה. אנסמבל החמישה אינו המועמד המוביל בניסוי הזה.',[notebook,'https://scikit-learn.org/1.8/modules/generated/sklearn.model_selection.GridSearchCV.html']);
 slide=base(presentation,8,'בדיקה חד-פעמית והצעות לסמלן','כדי לראות את תוצאת הבחירה על רשומות שלא שימשו לכוונון, מפעילים את המפרטים שנבחרו ב-CV פעם אחת על הבדיקה.');
 chart(slide,data.test_paths.map(x=>x.path),[
 {name:'Accuracy / micro-recall',values:data.test_paths.map(x=>x.accuracy),fill:teal},
 {name:'Macro-F1',values:data.test_paths.map(x=>x.macro_f1),fill:gold}
 ],{left:55,top:218,width:635,height:325},{direction:'column',format:'0.00',max:1,labels:true,gap:120});
 const chosen=data.manifest.selected_configuration;
 text(slide,'chosen','בחירה לפי CV\n'+chosen.family+'\n'+chosen.path,745,222,475,123,27,ink,true);
 text(slide,'partial','9 רשומות עם X מקבלות הצעות לסמלן. אין עבורן אמת מלאה לחישוב ציון.\n\nהאנסמבל מציג גם חיזוי חד-פעמי לרשומה חדשה ללא קוד אמת.',745,392,475,185,26,muted);
 text(slide,'limit','בבדיקה: הקבוצות גבוהות יותר ב-macro-F1, והמסלול הישיר גבוה יותר ב-accuracy.',60,617,1160,39,23,teal,true);
 note(slide,'הבדיקה כוללת 35 רשומות, כולל שבע שמחלקתן אינה באימון. בסיווג חד-תוויתי על כלל המחלקות micro-recall שווה ל-accuracy. אין אלה מדדים עצמאיים. הזוכה הכולל והזוכה בכל מסלול נקבעו לפני תחזיות הבדיקה ואינם מוחלפים לפי הציון בה. כל תחזיות הבדיקה, top-3 וטבלת אי-ההתאמות נשמרים במחברת. לא משתמשים ב-X כיעד מלא. אחרי ההשוואה המפרט הנבחר מאומן מחדש על 191 הקודים המלאים. ספרות ידועות ביעד החלקי משמשות רק להצעה נוספת תואמת, ללא הכנסה למאפייני המודל. הרשומה החדשה היא הדגמה שנכתבה לצורך השימוש, ולא דוגמת אמת מאומתת.');
 slide=base(presentation,9,'הטמעה מדורגת עם מדידת טעויות אמיתית','כדי להפחית עבודת סימול בביטחון, מתחילים בסיוע לסמלן ומרחיבים סמכות רק לאחר אימות.');
 table(slide,[['תוצר שמאפשר להתקדם','הפעולה הבאה','הסיבה'],
 ['חלוקה אמיתית לפי נסקר וזמן','מזהה נסקר ושידור, מועד שידור ומזהה סמלן','שידורים חוזרים אינם מזוהים בקובץ'],
 ['מדגם אמת לבחירה, כיול והערכת טעויות','סימול כפול והכרעת מומחה במדגם','היעד הידני כולל שגיאות וקודים חלקיים'],
 ['מדידת איכות, זמן וזיכרון לפי נפח','מדגם מייצג, אצוות ובחינת ייצוג דליל','תרחיש של אלפים עד מיליון רשומות'],
 ['יחס מדוד בין חיסכון בזמן, כיסוי וטעויות','פיילוט הצעות, רישום תיקונים וניטור שינויי נתונים','הסימולציה אינה מבטיחה איכות תפעולית']
 ],205,400,[400,430,330],24);
 const link=text(slide,'notebook-link','המחברת המלאה והתחזיות ב-GitHub',60,622,1160,38,27,teal,true);link.text.get('המחברת המלאה והתחזיות ב-GitHub').link={uri:notebook,isExternal:true};

 note(slide,'להמשך: לאמת סוגי קלט בשאלון וזמינות קוד הענף בזמן חיזוי, לבדוק תרומה של גיל/מעסיק/יישוב על נתוני אמת, להעריך לפי זמן ונסקר, לכייל הסתברויות במדגם נפרד גדול דיו ולקבוע סף הפניה לסמלן. יש לנטר חסרים, מקצועות חדשים, שינויים בשפה ובשכיחות קודים. על נתונים גדולים נבחן מטריצות דלילות, חיפוש K בתקציב מוגדר, שיוך באצוות או MiniBatchKMeans, ומדידה נפרדת של עיבוד, אימון וחיזוי. בניסוי הנוכחי נעשה שימוש במערכים צפופים בגלל גודל המדגם. לא נמדדה ריצה במיליון רשומות. מקור: https://scikit-learn.org/1.8/computing/scaling_strategies.html המטרה העסקית תימדד בזמן טיפול ובטעויות מאומתות. Notebook source: '+notebook);
 return {slideCount:10};
}

from pathlib import Path
p=Path('execute_inprocess.py');s=p.read_text()
s=s.replace('import os, time, traceback','import os, time, traceback, sys')
s=s.replace('started = time.perf_counter()', '''class ProgressOutput:
    def __init__(self, output):
        self.output = output
    def write(self, value):
        if value.startswith('[CV]'):
            with open('/workspace/scratch/14b0f58f673c/cv_progress.log', 'a') as progress:
                progress.write(value + '\\n')
        else:
            self.output.write(value)
        return len(value)
    def flush(self):
        self.output.flush()

started = time.perf_counter()''')
s=s.replace('        result = shell.run_cell(cell.source, store_history=True)', '''        execution_source = cell.source.replace('    search.fit(training_features, training_codes)',
            '    search.verbose = 2\\n    search.fit(training_features, training_codes)')
        sys.stdout = ProgressOutput(sys.stdout)
        result = shell.run_cell(execution_source, store_history=True)''')
p.write_text(s)
